# Local chain: Arbitrum Nitro testnode (full chain simulation)

This repo deploys contracts to **Arbitrum Nitro local** using the network:
- `arbitrumLocal` → `http://127.0.0.1:8547`

To run the chain locally (Docker required):

```bash
git clone -b release --recurse-submodules https://github.com/OffchainLabs/nitro-testnode.git
cd nitro-testnode
./test-node.bash --init
./test-node.bash --blockscout
```

Explorer:
- http://localhost:4000

RPCs:
- L1 dev RPC: http://localhost:8545
- L2 Nitro RPC: http://localhost:8547
