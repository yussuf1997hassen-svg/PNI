# Kite alignment (used as a constraint system, not as governance)

The optional `SEEIssuerIntentController` is inspired by Kite’s standing intent / session key model:

- **Bounded loss** via mathematically enforced caps (daily mint/burn caps)
- **Least privilege**: session keys can do less than the admin
- **Automatic expiration**: session keys have `expiresAt`
- **Revocation**: the admin can disable a session key immediately

In this repo:
- DAT governance remains the root (`ADMIN_ADDRESS`).
- Kite-style delegation is only an *operational convenience* and can be disabled.
