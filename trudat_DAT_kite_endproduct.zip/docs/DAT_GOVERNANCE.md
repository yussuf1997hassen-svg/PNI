# DAT-first governance alignment (practical on-chain mapping)

This repo treats DAT governance as the *root of authority* and uses Kite concepts only where they help
enforce **bounded risk** and **least privilege**.

## DAT principles mapped into contract/governance mechanics

1) **Authority should not silently transfer**
- Use a single, explicit `ADMIN_ADDRESS` (ideally a Safe/multisig) as the governance root.
- Deployment scripts transfer ownership / admin privileges to `ADMIN_ADDRESS` at the end.

2) **Pause before reflex; choose**
- The sEE token supports `pause()` to halt transfers (panic brake).
- Mint/burn can remain available during pause for remediation (policy choice documented in code).

3) **Fidelity / traceability**
- Privileged actions should be observable and auditable:
  - sEE blacklist + pause now supports optional **reason codes** (bytes32) as an audit trail.
  - Treasury/router/MEV controls are owned by `ADMIN_ADDRESS` (no hidden operator keys).

4) **Least privilege**
- Optional Kite-style intent controller enables session keys with:
  - expiry
  - daily caps (bounded loss)
  - optional recipient allowlist

## What remains off-chain (by design)
A “stablecoin” claim requires reserves + redemption + attestations. The contracts provide scaffolding, not proof-of-reserves.
