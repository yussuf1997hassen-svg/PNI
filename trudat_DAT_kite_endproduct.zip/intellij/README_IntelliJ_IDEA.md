# IntelliJ IDEA (macOS / Windows / Linux) — clean setup for this repo

## 1) Open the project
Open the folder that contains:
- `package.json`
- `hardhat.config.js`
- `contracts/`

## 2) Point IntelliJ to Node.js
**Settings/Preferences → Languages & Frameworks → Node.js and NPM**

Set:
- **Node interpreter**: your installed Node (system Node or nvm Node)
- **Package manager**: npm

Verify in the IntelliJ Terminal:
```bash
node -v
npm -v
```

## 3) Install + test
In IntelliJ Terminal:
```bash
npm install
npx hardhat compile
npx hardhat test
```

## 4) Run configurations (recommended)
### A) Hardhat: Compile
**Run → Edit Configurations → + → npm**
- Package.json: this repo’s `package.json`
- Command: `run`
- Scripts: `compile`

### B) Hardhat: Test
Add another **npm** configuration:
- Script: `test`

### C) Deploy (local Arbitrum Nitro)
Add another **npm** configuration:
- Script: `deploy:all:arbitrumLocal`

**Important:** this requires the Nitro testnode running (Docker) and your `.env` populated.

## 5) Environment variables (.env)
Create `.env` from `.env.example`.

If you use `.env`, IntelliJ will not automatically load it into Run Configurations unless you:
- (Option 1) run commands from the **Terminal** (recommended), or
- (Option 2) install an EnvFile plugin and attach `.env` to each run config.

## 6) Local Arbitrum Nitro (Blockscout)
Run Nitro testnode in a separate terminal (outside or inside IntelliJ):
```bash
git clone -b release --recurse-submodules https://github.com/OffchainLabs/nitro-testnode.git
cd nitro-testnode
./test-node.bash --init
./test-node.bash --blockscout
```

Then deploy using:
```bash
npm run deploy:all:arbitrumLocal
```
