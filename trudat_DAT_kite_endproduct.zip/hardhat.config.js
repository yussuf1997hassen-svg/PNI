require("@nomiclabs/hardhat-ethers");
require("@nomicfoundation/hardhat-verify");
require("dotenv").config();

const DEPLOYER_PRIVATE_KEY = process.env.DEPLOYER_PRIVATE_KEY || process.env.PRIVATE_KEY || "";

function accounts() {
  if (!DEPLOYER_PRIVATE_KEY) return [];
  return [DEPLOYER_PRIVATE_KEY];
}

module.exports = {
  solidity: {
    compilers: [
      { version: "0.8.24", settings: { optimizer: { enabled: true, runs: 200 } } },
      { version: "0.8.17", settings: { optimizer: { enabled: true, runs: 200 } } }
    ]
  },
  networks: {
    localhost: { url: process.env.LOCALHOST_RPC_URL || "http://127.0.0.1:8545", accounts: accounts() },

    // Arbitrum Nitro local testnode (L2 RPC). Default port per nitro-testnode is 8547.
    arbitrumLocal: { url: process.env.ARBITRUM_LOCAL_RPC_URL || "http://127.0.0.1:8547", accounts: accounts() },

    // Optional: Your own TruDAT RPC endpoint (custom chain)
    trudat: { url: process.env.TRUDAT_RPC_URL || "", accounts: accounts() },

    // Public networks (only if you set RPC URLs + funded key)
    arbitrum: { url: process.env.ARBITRUM_RPC_URL || "", accounts: accounts() },
    base: { url: process.env.BASE_RPC_URL || "", accounts: accounts() },
  },
  etherscan: {
    apiKey: {
      arbitrumOne: process.env.ARBISCAN_API_KEY || "",
      base: process.env.BASESCAN_API_KEY || ""
    },
    customChains: [
      {
        network: "base",
        chainId: 8453,
        urls: {
          apiURL: "https://api.basescan.org/api",
          browserURL: "https://basescan.org"
        }
      },
      {
        network: "arbitrum",
        chainId: 42161,
        urls: {
          apiURL: "https://api.arbiscan.io/api",
          browserURL: "https://arbiscan.io"
        }
      }
    ]
  }
};
