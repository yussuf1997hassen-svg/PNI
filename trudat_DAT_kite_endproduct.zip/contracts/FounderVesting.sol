// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract FounderVesting is Ownable {
    IERC20 public token;
    address public beneficiary;
    uint256 public start;
    uint256 public duration;
    uint256 public totalAmount;
    uint256 public claimed;

    constructor(IERC20 _token, address _beneficiary, uint256 _start, uint256 _duration, uint256 _total) Ownable(msg.sender) {
        token = _token; beneficiary = _beneficiary; start = _start; duration = _duration; totalAmount = _total;
    }

    function claim() external {
        require(msg.sender == beneficiary || msg.sender == owner(), "not allowed");
        uint256 vested = vestedAmount();
        uint256 releasable = vested - claimed;
        require(releasable > 0, "none");
        claimed += releasable;
        token.transfer(beneficiary, releasable);
    }

    function vestedAmount() public view returns (uint256) {
        if (block.timestamp < start) return 0;
        if (block.timestamp >= start + duration) return totalAmount;
        uint256 elapsed = block.timestamp - start;
        return (totalAmount * elapsed) / duration;
    }
}
