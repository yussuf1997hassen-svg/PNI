// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "./Treasury.sol";
import "./Interfaces.sol";

contract MEVVault is Ownable {
    Treasury public treasury;
    address public constant ETERNAL_FLAME = address(0x00000000000000000000000000000000F1A7E);

    constructor(address _treasury) Ownable(msg.sender) { treasury = Treasury(_treasury); }
    receive() external payable {}

    function distributeETH(uint256 burnPct) external onlyOwner {
        uint256 bal = address(this).balance;
        require(bal > 0, "no bal");
        uint256 burnAmt = (bal * burnPct) / 10000;
        uint256 rest = bal - burnAmt;
        (bool ok,) = payable(ETERNAL_FLAME).call{value: burnAmt}("");
        require(ok, "burn fail");
        (bool ok2,) = payable(address(treasury)).call{value: rest}("");
        require(ok2, "tx fail");
    }

    function sweepERC20(IERC20Minimal token) external onlyOwner {
        uint256 bal = token.balanceOf(address(this));
        require(bal > 0, "no bal");
        token.transfer(address(treasury), bal);
    }
}
