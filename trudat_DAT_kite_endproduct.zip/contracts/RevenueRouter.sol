// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "./Interfaces.sol";
import "./Treasury.sol";

contract RevenueRouter is Ownable {
    Treasury public treasury;
    IERC20Minimal public tdat;

    uint16 public burnPct;    // per 10000
    uint16 public stakerPct;
    uint16 public treasuryPct;
    address public stakerRewardsAddress;

    event RevenueReceived(address indexed from, uint256 amount);
    event Split(uint256 burnAmt, uint256 stakerAmt, uint256 treasuryAmt);

    constructor(
        address _tdat,
        address _treasury,
        address _stakerRewards,
        uint16 _burn,
        uint16 _staker,
        uint16 _treasuryPct
    ) Ownable(msg.sender) {
        require(_burn + _staker + _treasuryPct == 10000, "sum 10000");
        tdat = IERC20Minimal(_tdat);
        treasury = Treasury(_treasury);
        stakerRewardsAddress = _stakerRewards;
        burnPct = _burn;
        stakerPct = _staker;
        treasuryPct = _treasuryPct;
    }

    function route(uint256 amount) external {
        require(amount > 0, "zero");
        require(tdat.transferFrom(msg.sender, address(this), amount), "pull fail");

        uint256 burnAmt = (amount * burnPct) / 10000;
        uint256 stakerAmt = (amount * stakerPct) / 10000;
        uint256 treasuryAmt = amount - burnAmt - stakerAmt;

        if (burnAmt > 0) tdat.transfer(treasury.ETERNAL_FLAME(), burnAmt);
        if (stakerAmt > 0) tdat.transfer(stakerRewardsAddress, stakerAmt);
        if (treasuryAmt > 0) tdat.transfer(address(treasury), treasuryAmt);

        emit RevenueReceived(msg.sender, amount);
        emit Split(burnAmt, stakerAmt, treasuryAmt);
    }

    function setPercents(uint16 _burn, uint16 _staker, uint16 _treasuryPct) external onlyOwner {
        require(_burn + _staker + _treasuryPct == 10000, "sum10000");
        burnPct = _burn; stakerPct = _staker; treasuryPct = _treasuryPct;
    }

    function setStakerRewardsAddress(address a) external onlyOwner { stakerRewardsAddress = a; }
    function setTreasury(address t) external onlyOwner { treasury = Treasury(t); }
}
