// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "./Interfaces.sol";

contract Treasury is Ownable {
    address public beneficiary;
    address public multisig;
    bool public guardianMode;

    address public constant ETERNAL_FLAME = address(0x00000000000000000000000000000000F1A7E);

    event Received(address indexed from, uint256 amount);
    event DistributedETH(address indexed to, uint256 amount);
    event DistributedToken(address indexed token, address indexed to, uint256 amount);
    event BeneficiaryChanged(address oldB, address newB);
    event MultisigChanged(address oldM, address newM);

    constructor(address _beneficiary, address _multisig) Ownable(msg.sender) {
        beneficiary = _beneficiary;
        multisig = _multisig;
    }

    receive() external payable { emit Received(msg.sender, msg.value); }

    function distributeETH() external onlyOwner {
        uint256 bal = address(this).balance;
        require(bal > 0, "0 balance");
        address pay = multisig == address(0) ? beneficiary : multisig;
        (bool ok,) = payable(pay).call{value: bal}("");
        require(ok, "send fail");
        emit DistributedETH(pay, bal);
    }

    function collectToken(IERC20Minimal token) external onlyOwner {
        uint256 bal = token.balanceOf(address(this));
        require(bal > 0, "no tokens");
        address pay = multisig == address(0) ? beneficiary : multisig;
        require(token.transfer(pay, bal), "transfer fail");
        emit DistributedToken(address(token), pay, bal);
    }

    function setBeneficiary(address _b) external {
        if (guardianMode) require(msg.sender == multisig, "guardian mode");
        else require(msg.sender == owner() || msg.sender == multisig, "not allowed");
        emit BeneficiaryChanged(beneficiary, _b);
        beneficiary = _b;
    }

    function setMultisig(address _m) external onlyOwner {
        emit MultisigChanged(multisig, _m);
        multisig = _m;
    }

    function enableGuardianMode() external {
        require(msg.sender == multisig, "only multisig");
        guardianMode = true;
    }

    function burnERC20(IERC20Minimal token) external onlyOwner {
        uint256 bal = token.balanceOf(address(this));
        require(bal > 0, "no bal");
        token.transfer(ETERNAL_FLAME, bal);
    }
}
