const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("TruDAT RevenueRouter", function () {
  it("splits TDAT revenue into burn/stakers/treasury", async function () {
    const [owner, user, staker] = await ethers.getSigners();

    const initialSupply = ethers.utils.parseUnits("1000000", 18);
    const TruDATToken = await ethers.getContractFactory("TruDATToken");
    const tdat = await TruDATToken.deploy(initialSupply);
    await tdat.deployed();

    const Treasury = await ethers.getContractFactory("Treasury");
    const treasury = await Treasury.deploy(owner.address, ethers.constants.AddressZero);
    await treasury.deployed();

    const RevenueRouter = await ethers.getContractFactory("RevenueRouter");
    const router = await RevenueRouter.deploy(tdat.address, treasury.address, staker.address, 5000, 3000, 2000);
    await router.deployed();

    await tdat.transfer(user.address, ethers.utils.parseUnits("1000", 18));
    await tdat.connect(user).approve(router.address, ethers.utils.parseUnits("1000", 18));

    await router.connect(user).route(ethers.utils.parseUnits("100", 18));

    const stakerBal = await tdat.balanceOf(staker.address);
    const treasuryBal = await tdat.balanceOf(treasury.address);

    expect(stakerBal).to.equal(ethers.utils.parseUnits("30", 18));
    expect(treasuryBal).to.equal(ethers.utils.parseUnits("20", 18));
  });
});
