const hre = require("hardhat");

function env(name, fallback="") { return process.env[name] || fallback; }
function envBool(name, fallback=false) {
  const v = (process.env[name] ?? "").toString().trim().toLowerCase();
  if (!v) return fallback;
  return ["1","true","yes","y","on"].includes(v);
}
function mustAddress(name, value) {
  if (!value || !hre.ethers.utils.isAddress(value)) throw new Error(`${name} is missing or not an address: ${value || ""}`);
  return value;
}

async function deployTruDAT(ADMIN_ADDRESS) {
  const [deployer] = await hre.ethers.getSigners();
  const BENEFICIARY = mustAddress("BENEFICIARY_ADDRESS", env("BENEFICIARY_ADDRESS", ADMIN_ADDRESS));
  const STAKER_REWARDS = mustAddress("STAKER_REWARDS_ADDRESS", env("STAKER_REWARDS_ADDRESS", BENEFICIARY));

  console.log("Deployer:", deployer.address);
  console.log("ADMIN_ADDRESS:", ADMIN_ADDRESS);
  console.log("BENEFICIARY_ADDRESS:", BENEFICIARY);
  console.log("STAKER_REWARDS_ADDRESS:", STAKER_REWARDS);

  const initialSupply = hre.ethers.utils.parseUnits(env("TDAT_INITIAL_SUPPLY", "1000000000"), 18);

  const TruDATToken = await hre.ethers.getContractFactory("TruDATToken");
  const tdat = await TruDATToken.deploy(initialSupply);
  await tdat.deployed();
  console.log("TruDATToken:", tdat.address);

  const Treasury = await hre.ethers.getContractFactory("Treasury");
  const treasury = await Treasury.deploy(BENEFICIARY, ADMIN_ADDRESS);
  await treasury.deployed();
  console.log("Treasury:", treasury.address);

  const RevenueRouter = await hre.ethers.getContractFactory("RevenueRouter");
  const router = await RevenueRouter.deploy(tdat.address, treasury.address, STAKER_REWARDS, 5000, 3000, 2000);
  await router.deployed();
  console.log("RevenueRouter:", router.address);

  const MEVVault = await hre.ethers.getContractFactory("MEVVault");
  const mev = await MEVVault.deploy(treasury.address);
  await mev.deployed();
  console.log("MEVVault:", mev.address);

  const FounderVesting = await hre.ethers.getContractFactory("FounderVesting");
  const vestAmount = hre.ethers.utils.parseUnits(env("TDAT_FOUNDER_VEST_AMOUNT", "100000000"), 18);
  const now = Math.floor(Date.now() / 1000);
  const vestStart = now + parseInt(env("TDAT_FOUNDER_VEST_START_DELAY_SEC", "60"), 10);
  const vestDuration = parseInt(env("TDAT_FOUNDER_VEST_DURATION_SEC", String(60*60*24*365)), 10);

  const vest = await FounderVesting.deploy(tdat.address, BENEFICIARY, vestStart, vestDuration, vestAmount);
  await vest.deployed();
  console.log("FounderVesting:", vest.address);

  await (await tdat.transfer(vest.address, vestAmount)).wait();
  console.log("Transferred vest amount to vesting contract:", vestAmount.toString());

  const balAfter = await tdat.balanceOf(deployer.address);
  if (balAfter.gt(0)) {
    await (await tdat.transfer(treasury.address, balAfter)).wait();
    console.log("Transferred remaining supply to Treasury:", balAfter.toString());
  }

  await (await tdat.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await treasury.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await router.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await mev.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await vest.transferOwnership(ADMIN_ADDRESS)).wait();

  console.log("Ownership transferred to ADMIN_ADDRESS for all TruDAT contracts.");
  return { tdat: tdat.address, treasury: treasury.address, router: router.address, mev: mev.address, vest: vest.address };
}

async function deploySEE(ADMIN_ADDRESS) {
  const BLACKLIST_ENABLED = envBool("BLACKLIST_ENABLED", true);
  const ENABLE_INTENT_CONTROLLER = envBool("ENABLE_INTENT_CONTROLLER", true);
  const REVOKE_SETUP_MINTER = envBool("REVOKE_SETUP_MINTER", false);

  const capWei = env("SEE_CAP_WEI")
    ? hre.ethers.BigNumber.from(env("SEE_CAP_WEI"))
    : hre.ethers.utils.parseUnits("1000000000", 18);

  const SEEStablecoin = await hre.ethers.getContractFactory("SEEStablecoin");
  const see = await SEEStablecoin.deploy(ADMIN_ADDRESS, capWei, BLACKLIST_ENABLED);
  await see.deployed();
  console.log("SEEStablecoin:", see.address);

  const SEEReserveVault = await hre.ethers.getContractFactory("SEEReserveVault");
  const vault = await SEEReserveVault.deploy(ADMIN_ADDRESS, see.address);
  await vault.deployed();
  console.log("SEEReserveVault:", vault.address);

  const MINTER_ROLE = await see.MINTER_ROLE();
  await (await see.grantRole(MINTER_ROLE, vault.address)).wait();
  console.log("Granted MINTER_ROLE to vault.");

  let controller = null;
  if (ENABLE_INTENT_CONTROLLER) {
    const SEEIssuerIntentController = await hre.ethers.getContractFactory("SEEIssuerIntentController");
    controller = await SEEIssuerIntentController.deploy(ADMIN_ADDRESS, vault.address);
    await controller.deployed();
    console.log("SEEIssuerIntentController:", controller.address);

    const ISSUER_ROLE = await vault.ISSUER_ROLE();
    await (await vault.grantRole(ISSUER_ROLE, controller.address)).wait();
    console.log("Granted ISSUER_ROLE to intent controller.");
  }

  if (REVOKE_SETUP_MINTER) {
    await (await see.revokeRole(MINTER_ROLE, ADMIN_ADDRESS)).wait();
    console.log("Revoked MINTER_ROLE from ADMIN_ADDRESS (REVOKE_SETUP_MINTER=true).");
  }

  return { see: see.address, vault: vault.address, controller: controller ? controller.address : null };
}

async function main() {
  const ADMIN_ADDRESS = mustAddress("ADMIN_ADDRESS", env("ADMIN_ADDRESS"));
  console.log("=== Deploying TruDAT suite ===");
  const trudat = await deployTruDAT(ADMIN_ADDRESS);

  console.log("\n=== Deploying sEE stablecoin suite ===");
  const see = await deploySEE(ADMIN_ADDRESS);

  console.log("\n=== Deployment Summary ===");
  console.log({ ...trudat, ...see });
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
