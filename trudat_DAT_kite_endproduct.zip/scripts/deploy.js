// Legacy entrypoint kept for compatibility.
// Prefer: scripts/deploy_all.js, scripts/deploy_trudat.js, scripts/deploy_see.js
require("./deploy_all");
