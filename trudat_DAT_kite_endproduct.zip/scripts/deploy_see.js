const hre = require("hardhat");

function env(name, fallback="") { return process.env[name] || fallback; }

function envBool(name, fallback=false) {
  const v = (process.env[name] ?? "").toString().trim().toLowerCase();
  if (!v) return fallback;
  return ["1","true","yes","y","on"].includes(v);
}

function mustAddress(name, value) {
  if (!value || !hre.ethers.utils.isAddress(value)) {
    throw new Error(`${name} is missing or not an address: ${value || ""}`);
  }
  return value;
}

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const ADMIN_ADDRESS = mustAddress("ADMIN_ADDRESS", env("ADMIN_ADDRESS"));

  const BLACKLIST_ENABLED = envBool("BLACKLIST_ENABLED", true); // per your env requirement default
  const ENABLE_INTENT_CONTROLLER = envBool("ENABLE_INTENT_CONTROLLER", true);
  const REVOKE_SETUP_MINTER = envBool("REVOKE_SETUP_MINTER", false);

  console.log("Deployer:", deployer.address);
  console.log("ADMIN_ADDRESS:", ADMIN_ADDRESS);
  console.log("BLACKLIST_ENABLED:", BLACKLIST_ENABLED);
  console.log("ENABLE_INTENT_CONTROLLER:", ENABLE_INTENT_CONTROLLER);
  console.log("REVOKE_SETUP_MINTER:", REVOKE_SETUP_MINTER);

  const capWei = env("SEE_CAP_WEI")
    ? hre.ethers.BigNumber.from(env("SEE_CAP_WEI"))
    : hre.ethers.utils.parseUnits("1000000000", 18); // default 1B sEE, adjust as needed

  const SEEStablecoin = await hre.ethers.getContractFactory("SEEStablecoin");
  const see = await SEEStablecoin.deploy(ADMIN_ADDRESS, capWei, BLACKLIST_ENABLED);
  await see.deployed();
  console.log("SEEStablecoin:", see.address);

  const SEEReserveVault = await hre.ethers.getContractFactory("SEEReserveVault");
  const vault = await SEEReserveVault.deploy(ADMIN_ADDRESS, see.address);
  await vault.deployed();
  console.log("SEEReserveVault:", vault.address);

  // Grant vault mint authority on sEE
  const MINTER_ROLE = await see.MINTER_ROLE();
  await (await see.grantRole(MINTER_ROLE, vault.address)).wait();
  console.log("Granted MINTER_ROLE to vault.");

  let controllerAddr = null;
  if (ENABLE_INTENT_CONTROLLER) {
    const SEEIssuerIntentController = await hre.ethers.getContractFactory("SEEIssuerIntentController");
    const controller = await SEEIssuerIntentController.deploy(ADMIN_ADDRESS, vault.address);
    await controller.deployed();
    controllerAddr = controller.address;
    console.log("SEEIssuerIntentController:", controllerAddr);

    const ISSUER_ROLE = await vault.ISSUER_ROLE();
    await (await vault.grantRole(ISSUER_ROLE, controllerAddr)).wait();
    console.log("Granted ISSUER_ROLE to intent controller.");
  }

  if (REVOKE_SETUP_MINTER) {
    // Optional hardening: remove direct mint power from ADMIN, leaving only vault (and controller via vault)
    await (await see.revokeRole(MINTER_ROLE, ADMIN_ADDRESS)).wait();
    console.log("Revoked MINTER_ROLE from ADMIN_ADDRESS (REVOKE_SETUP_MINTER=true).");
  }

  console.log("sEE deployment complete.");
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
