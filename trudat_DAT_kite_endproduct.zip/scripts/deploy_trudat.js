const hre = require("hardhat");

function mustAddress(name, value) {
  if (!value || !hre.ethers.utils.isAddress(value)) {
    throw new Error(`${name} is missing or not an address: ${value || ""}`);
  }
  return value;
}

function env(name, fallback="") { return process.env[name] || fallback; }

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const ADMIN_ADDRESS = mustAddress("ADMIN_ADDRESS", env("ADMIN_ADDRESS"));

  const BENEFICIARY = mustAddress("BENEFICIARY_ADDRESS", env("BENEFICIARY_ADDRESS", ADMIN_ADDRESS));
  const STAKER_REWARDS = mustAddress("STAKER_REWARDS_ADDRESS", env("STAKER_REWARDS_ADDRESS", BENEFICIARY));

  console.log("Deployer:", deployer.address);
  console.log("ADMIN_ADDRESS:", ADMIN_ADDRESS);
  console.log("BENEFICIARY_ADDRESS:", BENEFICIARY);
  console.log("STAKER_REWARDS_ADDRESS:", STAKER_REWARDS);

  const initialSupply = hre.ethers.utils.parseUnits(env("TDAT_INITIAL_SUPPLY", "1000000000"), 18);

  const TruDATToken = await hre.ethers.getContractFactory("TruDATToken");
  const tdat = await TruDATToken.deploy(initialSupply);
  await tdat.deployed();
  console.log("TruDATToken:", tdat.address);

  const Treasury = await hre.ethers.getContractFactory("Treasury");
  const treasury = await Treasury.deploy(BENEFICIARY, ADMIN_ADDRESS);
  await treasury.deployed();
  console.log("Treasury:", treasury.address);

  const RevenueRouter = await hre.ethers.getContractFactory("RevenueRouter");
  const router = await RevenueRouter.deploy(tdat.address, treasury.address, STAKER_REWARDS, 5000, 3000, 2000);
  await router.deployed();
  console.log("RevenueRouter:", router.address);

  const MEVVault = await hre.ethers.getContractFactory("MEVVault");
  const mev = await MEVVault.deploy(treasury.address);
  await mev.deployed();
  console.log("MEVVault:", mev.address);

  const FounderVesting = await hre.ethers.getContractFactory("FounderVesting");
  const vestAmount = hre.ethers.utils.parseUnits(env("TDAT_FOUNDER_VEST_AMOUNT", "100000000"), 18);
  const now = Math.floor(Date.now() / 1000);
  const vestStart = now + parseInt(env("TDAT_FOUNDER_VEST_START_DELAY_SEC", "60"), 10);
  const vestDuration = parseInt(env("TDAT_FOUNDER_VEST_DURATION_SEC", String(60*60*24*365)), 10);

  const vest = await FounderVesting.deploy(tdat.address, BENEFICIARY, vestStart, vestDuration, vestAmount);
  await vest.deployed();
  console.log("FounderVesting:", vest.address);

  // Fund vesting
  const bal = await tdat.balanceOf(deployer.address);
  if (bal.lt(vestAmount)) throw new Error("Deployer balance < vest amount");
  const tx1 = await tdat.transfer(vest.address, vestAmount);
  await tx1.wait();
  console.log("Transferred vest amount to vesting contract:", vestAmount.toString());

  // Send remaining supply to Treasury for governance-controlled distribution
  const balAfter = await tdat.balanceOf(deployer.address);
  if (balAfter.gt(0)) {
    const tx2 = await tdat.transfer(treasury.address, balAfter);
    await tx2.wait();
    console.log("Transferred remaining supply to Treasury:", balAfter.toString());
  }

  // DAT governance: move control keys away from deployer
  await (await tdat.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await treasury.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await router.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await mev.transferOwnership(ADMIN_ADDRESS)).wait();
  await (await vest.transferOwnership(ADMIN_ADDRESS)).wait();

  console.log("Ownership transferred to ADMIN_ADDRESS for all TruDAT contracts.");
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
