const { ethers } = require("ethers");

// Generates a fresh EOA wallet for dev/testing.
// IMPORTANT: Keep private keys out of git, and do not reuse dev keys on mainnet.
const w = ethers.Wallet.createRandom();

console.log("address =", w.address);
console.log("privateKey =", w.privateKey);
console.log("mnemonic =", w.mnemonic && w.mnemonic.phrase ? w.mnemonic.phrase : "");
