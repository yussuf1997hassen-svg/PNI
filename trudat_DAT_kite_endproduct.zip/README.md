# TruDAT + sEE (DAT Governance + Kite-aligned)

This repo contains:
- **TruDAT suite**: `TruDATToken`, `Treasury`, `RevenueRouter`, `MEVVault`, `FounderVesting`
- **sEE stablecoin suite**: `SEEStablecoin`, `SEEReserveVault`, optional `SEEIssuerIntentController` (Kite-inspired)
- **DAT-first governance wiring**: deployment scripts move control to `ADMIN_ADDRESS` (typically a Safe/multisig)

## Wallet / address status (from the uploaded zip)
- The original zip contained **one** hard-coded address (used as `BENEFICIARY`): `0xe4ab7f68F92195FC779EF282bEEf17D6b3A0F0Bf`
- The repo did **not** include any wallet generator or stored wallet. A safe generator script is now included:
  - `npm run wallet:new`

## Requirements
- Node.js (v18+ recommended; you can use Node 22+ too)
- npm
- (For Arbitrum “full chain simulation”) Docker

## Install + test
```bash
npm install
npx hardhat compile
npx hardhat test
```

## Local Arbitrum Nitro environment (Blockscout at http://localhost:4000)
From your terminal (Docker required):

```bash
git clone -b release --recurse-submodules https://github.com/OffchainLabs/nitro-testnode.git
cd nitro-testnode
./test-node.bash --init
./test-node.bash --blockscout
```

Explorer:
- http://localhost:4000

RPCs:
- L1 dev RPC: http://localhost:8545
- L2 Nitro RPC: http://localhost:8547  (use this for deploying locally “on Arbitrum”)

## Deploy (Hardhat)
1) Copy env template and fill values:
```bash
cp .env.example .env
```

2) Deploy to local Arbitrum Nitro:
```bash
# must have ADMIN_ADDRESS and DEPLOYER_PRIVATE_KEY set in .env
npm run deploy:all:arbitrumLocal
```

3) Deploy to local Hardhat node (optional):
```bash
npx hardhat node
# in another terminal
npm run deploy:all:local
```

## IntelliJ IDEA setup (clean path)
See: `intellij/README_IntelliJ_IDEA.md`
