\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_ll_common.sh
need zip
need python3

OUT="dist/listing_packet"
mkdir -p "$OUT"

python3 - <<'PY'
import json,glob,os,datetime
out="dist/listing_packet"
os.makedirs(out,exist_ok=True)

# Inputs (optional)
receipts=sorted(glob.glob("dist/mainnet_receipt_*.json"))
liq=sorted(glob.glob("dist/liquidity_receipt_*.json"))

def load(p):
    return json.load(open(p))

contracts=[]
for r in receipts:
    d=load(r)
    contracts.append({
        "network": d.get("network"),
        "chainId": d.get("chainId"),
        "contract": d.get("contract"),
        "symbol": d.get("symbol","TDAT"),
        "decimals": d.get("decimals",18)
    })

pools=[]
for r in liq:
    d=load(r)
    pools.append({
        "chainId": d.get("chainId"),
        "pool": d.get("pool"),
        "positionManager": d.get("positionManager"),
        "token0": d.get("token0"),
        "token1": d.get("token1"),
        "fee": d.get("fee"),
        "positionTokenId": d.get("positionTokenId"),
        "owner": d.get("owner")
    })

packet={
  "name":"TruDAT Listing Packet",
  "generated": datetime.datetime.utcnow().isoformat()+"Z",
  "contracts": contracts,
  "pools": pools,
  "notes":[
    "No private keys included.",
    "Receipts are machine-verifiable proofs of deploy+mint and LP creation."
  ]
}

with open(os.path.join(out,"listing_packet.json"),"w") as f:
    json.dump(packet,f,indent=2)

md=[]
md.append("# TDAT Listing Packet")
md.append("")
md.append("This folder is meant to be shared publicly (no secrets).")
md.append("")
md.append("## Contracts")
for c in contracts:
    md.append(f"- chainId {c['chainId']}: `{c['contract']}`")
md.append("")
md.append("## Pools / Liquidity Positions")
if pools:
    for p in pools:
        md.append(f"- chainId {p['chainId']}: pool `{p['pool']}` fee {p['fee']} positionTokenId {p['positionTokenId']} owner `{p['owner']}`")
else:
    md.append("- (none yet) Run liquidity script first.")
md.append("")
with open(os.path.join(out,"README.md"),"w") as f:
    f.write("\n".join(md)+"\n")
print("OK: dist/listing_packet/listing_packet.json")
PY

TS="$(date +%Y%m%d_%H%M%S)"
ZIP="dist/TDAT_LISTING_PACKET_${TS}.zip"
rm -f "$ZIP"
zip -r "$ZIP" "$OUT" dist/mainnet_receipt_*.json dist/liquidity_receipt_*.json docs/NEXT_SMART_GOAL_LIQUIDITY.md >/dev/null 2>&1 || true
echo "OK: $ZIP"
