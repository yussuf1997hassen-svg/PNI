\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/liquidity-cli" "$REPO_DIR/dist"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
cp -R "$SRC_DIR/liquidity-cli/"* "$REPO_DIR/liquidity-cli/"
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo "Installed LIQUIDITY + LISTING bundle into: $REPO_DIR"
echo "NEXT:"
echo "  cd ~/Downloads/pni"
echo "  cp -n liquidity-cli/.env.example .env.liquidity"
echo "  # edit .env.liquidity (NO KEYS IN CHAT)"
echo "  set -a; source .env.liquidity; set +a"
echo "  bash tools/LIQUIDITY_AND_LISTING_ONE_GO.sh"
