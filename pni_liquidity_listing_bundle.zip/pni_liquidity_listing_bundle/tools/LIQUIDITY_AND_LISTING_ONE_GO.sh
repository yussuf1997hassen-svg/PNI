\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_ll_common.sh

need docker
need python3

say "0) Verify mainnet receipts exist"
python3 - <<'PY'
import glob,sys
files=glob.glob("dist/mainnet_receipt_*.json")
if not files:
    raise SystemExit("ERROR: missing dist/mainnet_receipt_*.json. Run mainnet deploy first.")
print("OK:", len(files), "receipt(s) found")
PY

say "1) Validate env"
: "${LP_PRIVATE_KEY:?Set LP_PRIVATE_KEY (0x... DO NOT PASTE INTO CHAT)}"
: "${TDAT_ARBITRUM:?Set TDAT_ARBITRUM token address (0x...)}"
: "${TDAT_BASE:?Set TDAT_BASE token address (0x...)}"

# Price settings (token1 per token0). Default: WETH per TDAT = 1 / 1,000,000 (very small)
PRICE_NUM="${PRICE_NUM:-1}"
PRICE_DEN="${PRICE_DEN:-1000000}"

# Liquidity amounts (human units)
TDAT_AMOUNT="${TDAT_AMOUNT:-100000}"
WETH_AMOUNT="${WETH_AMOUNT:-0.05}"

# Network RPCs
: "${ARBITRUM_ONE_RPC_URL:?Set ARBITRUM_ONE_RPC_URL}"
: "${BASE_MAINNET_RPC_URL:?Set BASE_MAINNET_RPC_URL}"

# Uniswap deployment addresses (from Uniswap docs)
# Arbitrum One
UNIV3_PM_ARBITRUM="${UNIV3_PM_ARBITRUM:-0xC36442b4a4522E871399CD717aBDD847Ab11FE88}"
WETH_ARBITRUM="${WETH_ARBITRUM:-0x82aF49447D8a07e3bd95BD0d56f35241523fBab1}"
# Base
UNIV3_PM_BASE="${UNIV3_PM_BASE:-0x03a520b32C04BF3bEEf7BEb72E919cf822Ed34f1}"
WETH_BASE="${WETH_BASE:-0x4200000000000000000000000000000000000006}"

FEE="${FEE:-3000}"            # 500, 3000, 10000
SLIPPAGE_BPS="${SLIPPAGE_BPS:-300}" # 3.00%
RENOUNCED="${RENOUNCED:-unknown}"   # informational

say "2) Install deps inside Docker (Node 20)"
docker run --rm -v "$ROOT/liquidity-cli:/app" -w /app node:20-bullseye bash -lc 'npm -s install >/dev/null'

say "3) Add liquidity on Arbitrum (Uniswap V3 full-range)"
docker run --rm \
  -e RPC_URL="$ARBITRUM_ONE_RPC_URL" \
  -e CHAIN_NAME="arbitrumOne" -e CHAIN_ID="42161" \
  -e POSITION_MANAGER="$UNIV3_PM_ARBITRUM" \
  -e TOKEN_A="$TDAT_ARBITRUM" -e TOKEN_B="$WETH_ARBITRUM" \
  -e TOKEN_A_AMOUNT="$TDAT_AMOUNT" -e TOKEN_B_AMOUNT="$WETH_AMOUNT" \
  -e PRICE_NUM="$PRICE_NUM" -e PRICE_DEN="$PRICE_DEN" \
  -e FEE="$FEE" -e SLIPPAGE_BPS="$SLIPPAGE_BPS" \
  -e PRIVATE_KEY="$LP_PRIVATE_KEY" \
  -v "$ROOT/liquidity-cli:/app" -v "$ROOT/dist:/dist" \
  -w /app node:20-bullseye bash -lc 'node scripts/univ3_fullrange_lp.js /dist'

say "4) Add liquidity on Base (Uniswap V3 full-range)"
docker run --rm \
  -e RPC_URL="$BASE_MAINNET_RPC_URL" \
  -e CHAIN_NAME="base" -e CHAIN_ID="8453" \
  -e POSITION_MANAGER="$UNIV3_PM_BASE" \
  -e TOKEN_A="$TDAT_BASE" -e TOKEN_B="$WETH_BASE" \
  -e TOKEN_A_AMOUNT="$TDAT_AMOUNT" -e TOKEN_B_AMOUNT="$WETH_AMOUNT" \
  -e PRICE_NUM="$PRICE_NUM" -e PRICE_DEN="$PRICE_DEN" \
  -e FEE="$FEE" -e SLIPPAGE_BPS="$SLIPPAGE_BPS" \
  -e PRIVATE_KEY="$LP_PRIVATE_KEY" \
  -v "$ROOT/liquidity-cli:/app" -v "$ROOT/dist:/dist" \
  -w /app node:20-bullseye bash -lc 'node scripts/univ3_fullrange_lp.js /dist'

say "5) Generate listing packet (no secrets)"
bash tools/MAKE_LISTING_PACKET.sh

say "DONE ✅"
echo "Artifacts:"
echo "  dist/liquidity_receipt_arbitrumOne.json"
echo "  dist/liquidity_receipt_base.json"
echo "  dist/TDAT_LISTING_PACKET_*.zip"
