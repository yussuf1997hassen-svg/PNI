\
import { ethers } from "ethers";
import fs from "fs";
import path from "path";

// Minimal ABIs
const ERC20_ABI = [
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function approve(address spender, uint256 value) returns (bool)",
  "function balanceOf(address owner) view returns (uint256)"
];

const PM_ABI = [
  "function createAndInitializePoolIfNecessary(address token0, address token1, uint24 fee, uint160 sqrtPriceX96) payable returns (address pool)",
  "function mint((address token0,address token1,uint24 fee,int24 tickLower,int24 tickUpper,uint256 amount0Desired,uint256 amount1Desired,uint256 amount0Min,uint256 amount1Min,address recipient,uint256 deadline)) payable returns (uint256 tokenId, uint128 liquidity, uint256 amount0, uint256 amount1)"
];

function die(msg){ console.error("ERROR:", msg); process.exit(1); }
function needEnv(k){ const v=process.env[k]; if(!v) die(`Missing env ${k}`); return v; }

function isHexAddress(a){ return /^0x[0-9a-fA-F]{40}$/.test(a); }

function pow10(n){ let r=1n; for(let i=0;i<n;i++) r*=10n; return r; }

// integer sqrt for BigInt
function isqrt(n){
  if(n < 0n) throw new Error("sqrt negative");
  if(n < 2n) return n;
  let x0 = n;
  let x1 = (x0 + n / x0) >> 1n;
  while (x1 < x0){
    x0 = x1;
    x1 = (x0 + n / x0) >> 1n;
  }
  return x0;
}

// Compute sqrtPriceX96 from PRICE_NUM/PRICE_DEN in human token1 per token0
function sqrtPriceX96FromPrice(priceNum, priceDen, dec0, dec1){
  // sqrtPriceX96 = floor( sqrt( (priceNum * 10^dec1 / (priceDen * 10^dec0)) * 2^192 ) )
  const num = BigInt(priceNum) * pow10(dec1) * (1n << 192n);
  const den = BigInt(priceDen) * pow10(dec0);
  const q = num / den;
  return isqrt(q);
}

async function main(outDir){
  const rpc = needEnv("RPC_URL");
  const pmAddr = needEnv("POSITION_MANAGER");
  const priv = needEnv("PRIVATE_KEY");
  const fee = parseInt(process.env.FEE || "3000", 10);
  const slippageBps = BigInt(process.env.SLIPPAGE_BPS || "300");
  const priceNum = BigInt(process.env.PRICE_NUM || "1");
  const priceDen = BigInt(process.env.PRICE_DEN || "1000000");

  const tokenA = needEnv("TOKEN_A");
  const tokenB = needEnv("TOKEN_B");
  if(!isHexAddress(tokenA) || !isHexAddress(tokenB)) die("TOKEN_A/TOKEN_B must be 0x addresses");
  if(!isHexAddress(pmAddr)) die("POSITION_MANAGER must be 0x address");

  const provider = new ethers.JsonRpcProvider(rpc);
  const wallet = new ethers.Wallet(priv, provider);

  const ercA = new ethers.Contract(tokenA, ERC20_ABI, wallet);
  const ercB = new ethers.Contract(tokenB, ERC20_ABI, wallet);
  const pm = new ethers.Contract(pmAddr, PM_ABI, wallet);

  const [decA, decB, symA, symB] = await Promise.all([ercA.decimals(), ercB.decimals(), ercA.symbol(), ercB.symbol()]);

  // Sort token0/token1 by address per Uniswap
  const aLower = tokenA.toLowerCase();
  const bLower = tokenB.toLowerCase();
  const token0 = (aLower < bLower) ? tokenA : tokenB;
  const token1 = (aLower < bLower) ? tokenB : tokenA;
  const sym0 = (aLower < bLower) ? symA : symB;
  const sym1 = (aLower < bLower) ? symB : symA;
  const dec0 = (aLower < bLower) ? decA : decB;
  const dec1 = (aLower < bLower) ? decB : decA;

  const amtA = process.env.TOKEN_A_AMOUNT || "100000";
  const amtB = process.env.TOKEN_B_AMOUNT || "0.05";

  // Parse human amounts using token decimals
  const amountA = ethers.parseUnits(amtA, decA);
  const amountB = ethers.parseUnits(amtB, decB);

  // Map to amount0Desired/amount1Desired based on sorting
  const amount0Desired = (aLower < bLower) ? amountA : amountB;
  const amount1Desired = (aLower < bLower) ? amountB : amountA;

  const balA = await ercA.balanceOf(wallet.address);
  const balB = await ercB.balanceOf(wallet.address);
  if(balA < amountA) die(`Insufficient ${symA}. Have ${balA.toString()} need ${amountA.toString()}`);
  if(balB < amountB) die(`Insufficient ${symB}. Have ${balB.toString()} need ${amountB.toString()}`);

  // Approve position manager
  await (await ercA.approve(pmAddr, amountA)).wait();
  await (await ercB.approve(pmAddr, amountB)).wait();

  // Full-range ticks for fee 3000 (tickSpacing=60): -887220 to 887220
  const tickLower = -887220;
  const tickUpper =  887220;

  // sqrtPriceX96 computed from price token1 per token0 (human ratio)
  const sqrtPriceX96 = sqrtPriceX96FromPrice(priceNum, priceDen, Number(dec0), Number(dec1));

  // Create pool if needed + initialize
  const pool = await pm.createAndInitializePoolIfNecessary(token0, token1, fee, sqrtPriceX96);

  const amount0Min = amount0Desired - (amount0Desired * slippageBps / 10000n);
  const amount1Min = amount1Desired - (amount1Desired * slippageBps / 10000n);

  const deadline = Math.floor(Date.now()/1000) + 60*20;

  const params = {
    token0, token1, fee,
    tickLower, tickUpper,
    amount0Desired, amount1Desired,
    amount0Min, amount1Min,
    recipient: wallet.address,
    deadline
  };

  const tx = await pm.mint(params);
  const rc = await tx.wait();
  // Decode returns from logs is hard; ethers v6 returns array-like from tx call not from receipt.
  // Instead call static by estimating? We'll do a callStatic-like by using pm.mint.staticCall first.
  const [tokenId, liquidity, used0, used1] = await pm.mint.staticCall(params);

  const chainId = parseInt(process.env.CHAIN_ID || "0", 10);
  const chainName = process.env.CHAIN_NAME || "unknown";

  const out = {
    chainId,
    chainName,
    positionManager: pmAddr,
    pool,
    token0, token1,
    symbol0: sym0,
    symbol1: sym1,
    fee,
    owner: wallet.address,
    positionTokenId: tokenId.toString(),
    liquidity: liquidity.toString(),
    amount0Used: used0.toString(),
    amount1Used: used1.toString(),
    amount0Desired: amount0Desired.toString(),
    amount1Desired: amount1Desired.toString(),
    priceNum: priceNum.toString(),
    priceDen: priceDen.toString(),
    sqrtPriceX96: sqrtPriceX96.toString(),
    txHash: rc.hash
  };

  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, `liquidity_receipt_${chainName}.json`);
  fs.writeFileSync(outPath, JSON.stringify(out, null, 2));
  console.log("OK:", outPath);
  console.log("Pool:", pool);
  console.log("Position tokenId:", tokenId.toString());
  console.log("Tx:", rc.hash);
}

const outDir = process.argv[2] || "./dist";
main(outDir).catch((e)=>{ console.error(e); process.exit(1); });
