# Liquidity + Listing Bundle

This bundle adds:
- one-go script to create a Uniswap V3 full-range LP position for TDAT/WETH on Base + Arbitrum
- receipts for liquidity positions
- a shareable listing packet zip

NO private keys are embedded; you provide them via `.env.liquidity` locally.
