# Liquidity + listing: what “complete” means

This is the step where TDAT becomes *discoverable* and *tradable* (in principle):
- a live Uniswap V3 pool exists on each chain
- your contracts + pools are packaged into a listing packet

After this, the next “completion” is utility: integrations that create real demand.
