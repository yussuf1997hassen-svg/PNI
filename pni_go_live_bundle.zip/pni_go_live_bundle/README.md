# PNI GO-LIVE Bundle

Install + run to generate a **verifiable GO_LIVE_BUNDLE zip** in `dist/`.

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_go_live_bundle
unzip -o ~/Downloads/pni_go_live_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_go_live_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO
```bash
cd ~/Downloads/pni && WALLET1=0x... WALLET2=0x... MINT_TOKENS=1000000 bash tools/GO_LIVE_ONE_GO.sh
```
