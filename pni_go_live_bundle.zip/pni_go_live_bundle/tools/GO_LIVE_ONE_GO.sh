\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_gl_common.sh

: "${WALLET1:?Set WALLET1=0x... (PUBLIC address)}"
: "${WALLET2:?Set WALLET2=0x... (PUBLIC address)}"
: "${MINT_TOKENS:?Set MINT_TOKENS (human units), e.g. 1000000}"

say "0) Hard rules"
echo " - DO NOT paste private keys in terminal."
echo " - This script only consumes PUBLIC wallet addresses."
echo " - Market price/value cannot be guaranteed by code."

say "1) PNI end-to-end (truDat publishes -> edge applies)"
if [ -x tools/LAST_MILE_ONE_GO.sh ]; then
  WALLET1="$WALLET1" WALLET2="$WALLET2" MINT_TOKENS="$MINT_TOKENS" \
  bash tools/LAST_MILE_ONE_GO.sh
else
  warn "tools/LAST_MILE_ONE_GO.sh not found; trying tools/TRUDAT_COMPLETE_ONE_GO.sh"
  if [ -x tools/TRUDAT_COMPLETE_ONE_GO.sh ]; then
    WALLET1="$WALLET1" WALLET2="$WALLET2" MINT_TOKENS="$MINT_TOKENS" \
    bash tools/TRUDAT_COMPLETE_ONE_GO.sh
  else
    die "Neither LAST_MILE_ONE_GO.sh nor TRUDAT_COMPLETE_ONE_GO.sh found. Install prior bundles."
  fi
fi

say "2) Lock down repo secrets hygiene"
# Add/ensure .gitignore entries (non-destructive)
touch .gitignore
grep -q '^secrets/$' .gitignore 2>/dev/null || printf "\nsecrets/\n" >> .gitignore
grep -q '^\.env$' .gitignore 2>/dev/null || printf ".env\n" >> .gitignore
grep -q '^\.env\..*$' .gitignore 2>/dev/null || printf ".env.*\n" >> .gitignore

mkdir -p secrets
chmod 700 secrets || true

say "3) Create a Go-Live Report (proof artifacts)"
mkdir -p dist logs
STAMP="$(date +%Y%m%d_%H%M%S)"
REPORT="dist/GO_LIVE_REPORT_${STAMP}.md"

{
  echo "# GO-LIVE REPORT"
  echo
  echo "- timestamp: ${STAMP}"
  echo "- wallet1: ${WALLET1}"
  echo "- wallet2: ${WALLET2}"
  echo "- mint_tokens_each: ${MINT_TOKENS}"
  echo
  echo "## Required proof files"
  echo "- dist/mint_receipt.json"
  echo "- dist/pni_DONE_<timestamp>.zip (optional)"
  echo
  echo "## Quick checks"
  echo "### Docker containers"
  docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}' || true
  echo
  echo "### Last 80 edge-agent lines (filtered)"
  (docker logs --tail=200 pni-edge-agent 2>/dev/null || true) | grep -Ei 'apply|applied|command|signature|policy' | tail -n 80 || true
  echo
  echo "### Last 80 hub-ingest lines (filtered)"
  (docker logs --tail=200 pni-hub-ingest 2>/dev/null || true) | grep -Ei 'telemetry|ingest|accepted|ok' | tail -n 80 || true
  echo
  echo "### Receipt (if present)"
  if [ -f dist/mint_receipt.json ]; then
    cat dist/mint_receipt.json
  else
    echo "mint_receipt.json missing"
  fi
} > "$REPORT"

say "4) Create a single shareable Go-Live bundle zip (report + receipts + DONE zip if exists)"
OUTDIR="dist/.go_live_${STAMP}"
rm -rf "$OUTDIR"
mkdir -p "$OUTDIR"
cp -f "$REPORT" "$OUTDIR/"

[ -f dist/mint_receipt.json ] && cp -f dist/mint_receipt.json "$OUTDIR/" || true
if ls -1t dist/pni_DONE_*.zip >/dev/null 2>&1; then
  cp -f "$(ls -1t dist/pni_DONE_*.zip | head -n 1)" "$OUTDIR/" || true
fi

ZIP="dist/GO_LIVE_BUNDLE_${STAMP}.zip"
( cd "$OUTDIR" && zip -r "$ROOT/$ZIP" . >/dev/null )
rm -rf "$OUTDIR"

echo "OK: $ZIP"
echo "SHA256:"
shasum -a 256 "$ZIP" || true

say "DONE ✅"
echo "Next objective after this: deploy to a real environment (k8s) + testnet/mainnet strategy for token."
