# sEE dApp Frontend (Scaffold)

This is a minimal Next.js scaffold intended to:
- Connect wallet
- Read sEE balance
- (Optional) issuer/admin pages if you add them

Implementation notes:
- Use wagmi + viem for wallet connect.
- Use BigInt for all on-chain amounts.
- Avoid any language suggesting yield guarantees.
