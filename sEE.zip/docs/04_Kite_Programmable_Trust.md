# 04 — Programmable Trust Patterns (Kite-inspired)

Kite emphasizes intent-based authorization and session-key delegation:
- Caps that cannot be exceeded
- Rolling windows (e.g., per-day limits)
- Allowlisted recipients (merchants/providers)
- Intents that expire

In this repo, those patterns are implemented as OPTIONAL infrastructure via:
- `SEEIssuerIntentController.sol` (delegated vault execution with hard constraints)

Use this only if you need to delegate operations (e.g., to an ops team or automation agent)
without giving away full issuer authority.
