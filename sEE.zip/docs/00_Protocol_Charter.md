# sEE — Neutral Stablecoin Charter (Scaffold)

## Core
- Token: **sEE**
- Cap (max supply): **1000000000000000000000000000000000000000000000000000000000000** (smallest units)
- Ledger: on-chain events + deterministic state transitions
- Design intent: “unit of account” token **if** you implement a verifiable reserve + redemption mechanism

## Non-claims
- Not a promise of profit
- Not a yield guarantee
- Not a guarantee of peg or liquidity

## Reserve model (choose one)
1) **Fiat-backed issuer model** (simplest mechanically)
   - Mint only when off-chain reserves increase
   - Burn only when off-chain reserves redeem/withdraw
   - Publish attestations/audits

2) **Crypto-collateralized model**
   - Overcollateralized vaults + liquidations

3) **Algorithmic model**
   - High risk; do not claim stability without robust proofs + market resilience

This package includes a minimal issuer-style vault ledger (`SEEReserveVault.sol`) as a starting point.
