# Choose Your Track: Token vs New Chain

## Track A — Token (Fastest)
Use existing chains (Arbitrum, Base, etc.). You get:
- existing security assumptions (Ethereum ecosystem)
- wallet/DEX tooling
- much lower build time

## Track B — New Chain (Most Work)
You are building:
- nodes, networking, consensus
- wallets, explorer, indexers
- ops/monitoring, testnets, upgrades

This package includes BOTH:
- A working scaffold for Track A (stablecoin token + issuer vault)
- A blueprint + placeholders for Track B
