# Stablecoin Model Notes (Practical)

Calling a token “stable” is *branding* unless you implement one of:

## A) Fiat-backed issuer (most common)
- You (issuer) mint when money is deposited to reserves.
- You burn when money is redeemed from reserves.
- Stability depends on redeemability, transparency, and trust/audits.

This package’s `SEEReserveVault` supports:
- `mintOnDeposit(depositId, to, amount)`
- `burnOnRedeem(redeemId, from, amount)` (requires user approval)

## B) Crypto-collateralized
- Users lock collateral, mint stablecoins, face liquidation.
- More code + complexity + oracle + risk management.

## C) Algorithmic
- Extreme risk. If you want this, treat it as research with extensive testing.

## Reality check
“Spendable cash” requires *either*:
- redemption into real assets, or
- market liquidity where others trade for stable assets.

A token contract alone does not create external liquidity.
