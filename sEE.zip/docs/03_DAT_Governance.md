# 03 — DAT Cognitive Sovereignty Governance (for sEE)

This document expresses governance as a *sovereignty protocol* (DAT style):
- Authority is explicit (no “mystery controllers”)
- Every high-impact action has a return-path
- Panic is treated as a signal, not a ruler
- “Security” tools (pause/blacklist) are last-resort instruments, not identity

## Non-negotiable sovereignty rule
The issuer’s ultimate authority must remain in the owner’s possession.
Delegation is allowed only inside constraints and is revocable.

## Governance classes
### Class A — System Integrity (Emergency)
Actions: pause transfers, revoke delegation, rotate operational keys.
Rule: do not expand power; restore return-path first.

### Class B — Monetary Integrity
Actions: mint/burn via the issuer ledger, adjust issuance policy off-chain, publish attestations.
Rule: issuance must be legible, bounded, and auditable.

### Class C — Compliance / Containment (Optional)
Actions: enable blacklist; mark addresses.
Rule: if enabled, must include reason logging, periodic review, and clear un-blacklist criteria.

## How code maps to governance
- `SEEStablecoin`:
  - `pause/unpause` (panic brake for transfers)
  - `setBlacklistEnabled`, `setBlacklisted` (optional containment)
  - `mint` (monetary integrity, role-gated)

- `SEEReserveVault`:
  - deposit/redeem IDs prevent double-mint/double-redeem
  - issuer actions live here (single ledger surface)

- Optional: `SEEIssuerIntentController`
  - session keys (ephemeral) with expiry
  - daily caps + allowlist constraints
  - enables safe delegation without surrendering authority

## Operational discipline
- Always publish: supply, reserves model, redemption terms, and attestations.
- Keep admin keys cold; use short-lived session keys for operations when possible.
