# sEE — Stablecoin Engineering Package (Scaffold)

This package mirrors the structure of your iEye / Efreet engineering packages, but the token is a **stablecoin-style ERC‑20 scaffold**.

## Important reality check (non-negotiable)
A contract can mint an ERC‑20 called “stablecoin”, but **price stability is not automatic**.
Stability comes from **a redeemable reserve model** (fiat-backed, crypto-collateralized, or another audited mechanism),
plus operational discipline (attestations/audits, redemption processing, controls).

This package includes:
- `SEEStablecoin.sol`: ERC‑20 with **cap**, **pause**, **permit**, and optional **blacklist**
- `SEEReserveVault.sol`: issuer ledger mint/burn workflow with **deposit/redeem IDs**
- Hardhat scripts: deploy + mint-on-deposit + burn-on-redeem
- Minimal dApp scaffold and chain blueprint placeholders
- DAT-aligned governance docs + optional Kite-style “intent/session key” delegation controller

## Cap (max supply)
`1000000000000000000000000000000000000000000000000000000000000` (smallest units)

## Governance stance (DAT-aligned)
- Sovereignty and authority must be explicit and recoverable.
- Panic controls exist (pause), but do not become “identity” (blacklist is optional and last-resort).
- Delegation is allowed only inside hard constraints (session keys + caps + allowlists), and can be revoked instantly.

## Quickstart
```bash
cd token-evm
npm i
npx hardhat compile
npx hardhat test
```

### Deploy (local)
Terminal 1:
```bash
cd token-evm
npx hardhat node
```

Terminal 2:
```bash
cd token-evm
export BLACKLIST_ENABLED="true"                 # or "false"
export ENABLE_INTENT_CONTROLLER="true"          # optional delegation controller
npx hardhat run scripts/deploy.ts --network localhost
```

### Mint on deposit (issuer ledger)
```bash
cd token-evm
export VAULT_ADDRESS="0x..."
export TO_ADDRESS="0x..."
export AMOUNT_WEI="1000000000000000000"
export DEPOSIT_REF="bank_tx_123_or_any_unique_ref"
npx hardhat run scripts/mintOnDeposit.ts --network localhost
```

### Burn on redeem (issuer ledger)
**Important:** the user must first approve the vault to burn their tokens (`approve(vault, amount)`).
```bash
cd token-evm
export VAULT_ADDRESS="0x..."
export FROM_ADDRESS="0x..."
export AMOUNT_WEI="1000000000000000000"
export REDEEM_REF="redeem_case_456_or_any_unique_ref"
npx hardhat run scripts/burnOnRedeem.ts --network localhost
```

## Kite integration (derived from docs.gokite.ai)
See `kite-integration/` for:
- “Intent-based authorization” concepts (caps, rolling windows, allowlists)
- Session-key delegation model (ephemeral operational keys)
- Account abstraction notes + example skeleton using GoKite AA SDK (optional)

## Security checklist
See `SECURITY_CHECKLIST.md` and `new-chain-blueprint/threat-model.md`.
