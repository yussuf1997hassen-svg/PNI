// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/AccessControl.sol";

interface ISEEStablecoin {
    function mint(address to, uint256 amount) external;
    function burnFrom(address account, uint256 amount) external;
}

/**
 * SEEReserveVault (issuer-ledger scaffold)
 *
 * Purpose:
 * - Track deposit/redeem references on-chain (anti-double-mint/double-redeem)
 * - Provide a single place to run issuer-controlled mint/burn operations
 *
 * Typical issuer workflow (fiat-backed style):
 * - Off-chain reserve increases -> mintOnDeposit(depositId, user, amount)
 * - Off-chain redemption requested -> user approves vault -> burnOnRedeem(redeemId, user, amount)
 *
 * NOTE:
 * This is NOT a proof of reserves system by itself.
 * You must maintain real reserves + publish attestations/audits if you claim “stable”.
 */
contract SEEReserveVault is AccessControl {
    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");

    ISEEStablecoin public immutable see;

    mapping(bytes32 => bool) public depositUsed;
    mapping(bytes32 => bool) public redeemUsed;

    event MintOnDeposit(bytes32 indexed depositId, address indexed to, uint256 amount);
    event BurnOnRedeem(bytes32 indexed redeemId, address indexed from, uint256 amount);

    constructor(address admin, address stablecoin) {
        require(admin != address(0), "admin=0");
        require(stablecoin != address(0), "see=0");

        see = ISEEStablecoin(stablecoin);

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(ISSUER_ROLE, admin);
    }

    function mintOnDeposit(bytes32 depositId, address to, uint256 amount) external onlyRole(ISSUER_ROLE) {
        require(depositId != bytes32(0), "depositId=0");
        require(to != address(0), "to=0");
        require(amount > 0, "amount=0");

        require(!depositUsed[depositId], "deposit used");
        depositUsed[depositId] = true;

        see.mint(to, amount);
        emit MintOnDeposit(depositId, to, amount);
    }

    // User must approve this vault to burn their tokens (standard ERC20Burnable behavior)
    function burnOnRedeem(bytes32 redeemId, address from, uint256 amount) external onlyRole(ISSUER_ROLE) {
        require(redeemId != bytes32(0), "redeemId=0");
        require(from != address(0), "from=0");
        require(amount > 0, "amount=0");

        require(!redeemUsed[redeemId], "redeem used");
        redeemUsed[redeemId] = true;

        see.burnFrom(from, amount);
        emit BurnOnRedeem(redeemId, from, amount);
    }
}
