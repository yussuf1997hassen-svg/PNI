// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/AccessControl.sol";

interface ISEEReserveVault {
    function mintOnDeposit(bytes32 depositId, address to, uint256 amount) external;
    function burnOnRedeem(bytes32 redeemId, address from, uint256 amount) external;
}

/**
 * SEEIssuerIntentController
 *
 * Kite-inspired "intent-based authorization" for issuer operations:
 * - Session keys (ephemeral delegates) can execute mint/burn through the vault,
 *   but only within mathematically enforced constraints:
 *     - expiry time
 *     - per-day mint/burn caps (rolling by UTC day)
 *     - optional recipient allowlist (mint targets)
 *
 * This lets the issuer (admin) delegate operational execution without giving away full authority.
 *
 * NOTE:
 * This contract is OPTIONAL. You can ignore it and keep issuer actions fully manual.
 */
contract SEEIssuerIntentController is AccessControl {
    bytes32 public constant POLICY_ADMIN_ROLE = keccak256("POLICY_ADMIN_ROLE");

    ISEEReserveVault public immutable vault;

    struct SessionKey {
        bool enabled;
        uint64 expiresAt;        // unix seconds
        uint256 dailyMintCap;    // max mint per UTC day
        uint256 dailyBurnCap;    // max burn per UTC day
        bool enforceRecipientAllowlist;
    }

    mapping(address => SessionKey) public sessionKeys;

    // delegate => dayIndex => used
    mapping(address => mapping(uint256 => uint256)) public mintedToday;
    mapping(address => mapping(uint256 => uint256)) public burnedToday;

    // delegate => recipient => allowed
    mapping(address => mapping(address => bool)) public allowedRecipients;

    event SessionKeySet(
        address indexed key,
        bool enabled,
        uint64 expiresAt,
        uint256 dailyMintCap,
        uint256 dailyBurnCap,
        bool enforceRecipientAllowlist
    );
    event RecipientAllowed(address indexed key, address indexed recipient, bool allowed);
    event DelegatedMint(address indexed key, bytes32 indexed depositId, address indexed to, uint256 amount);
    event DelegatedBurn(address indexed key, bytes32 indexed redeemId, address indexed from, uint256 amount);

    constructor(address admin, address vaultAddr) {
        require(admin != address(0), "admin=0");
        require(vaultAddr != address(0), "vault=0");

        vault = ISEEReserveVault(vaultAddr);

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ADMIN_ROLE, admin);
    }

    function setSessionKey(
        address key,
        bool enabled,
        uint64 expiresAt,
        uint256 dailyMintCap,
        uint256 dailyBurnCap,
        bool enforceRecipientAllowlist
    ) external onlyRole(POLICY_ADMIN_ROLE) {
        require(key != address(0), "key=0");
        require(expiresAt == 0 || expiresAt > block.timestamp, "expiresAt");

        sessionKeys[key] = SessionKey({
            enabled: enabled,
            expiresAt: expiresAt,
            dailyMintCap: dailyMintCap,
            dailyBurnCap: dailyBurnCap,
            enforceRecipientAllowlist: enforceRecipientAllowlist
        });

        emit SessionKeySet(key, enabled, expiresAt, dailyMintCap, dailyBurnCap, enforceRecipientAllowlist);
    }

    function setRecipientAllowed(address key, address recipient, bool allowed) external onlyRole(POLICY_ADMIN_ROLE) {
        require(key != address(0), "key=0");
        require(recipient != address(0), "recipient=0");
        allowedRecipients[key][recipient] = allowed;
        emit RecipientAllowed(key, recipient, allowed);
    }

    function mintOnDeposit(bytes32 depositId, address to, uint256 amount) external {
        _checkSessionKey(msg.sender);
        require(amount > 0, "amount=0");
        if (sessionKeys[msg.sender].enforceRecipientAllowlist) {
            require(allowedRecipients[msg.sender][to], "recipient not allowed");
        }

        uint256 dayIndex = block.timestamp / 1 days;
        uint256 used = mintedToday[msg.sender][dayIndex];
        uint256 cap = sessionKeys[msg.sender].dailyMintCap;
        if (cap > 0) {
            require(used + amount <= cap, "mint cap exceeded");
        }
        mintedToday[msg.sender][dayIndex] = used + amount;

        vault.mintOnDeposit(depositId, to, amount);
        emit DelegatedMint(msg.sender, depositId, to, amount);
    }

    function burnOnRedeem(bytes32 redeemId, address from, uint256 amount) external {
        _checkSessionKey(msg.sender);
        require(amount > 0, "amount=0");

        uint256 dayIndex = block.timestamp / 1 days;
        uint256 used = burnedToday[msg.sender][dayIndex];
        uint256 cap = sessionKeys[msg.sender].dailyBurnCap;
        if (cap > 0) {
            require(used + amount <= cap, "burn cap exceeded");
        }
        burnedToday[msg.sender][dayIndex] = used + amount;

        vault.burnOnRedeem(redeemId, from, amount);
        emit DelegatedBurn(msg.sender, redeemId, from, amount);
    }

    function _checkSessionKey(address key) internal view {
        SessionKey memory sk = sessionKeys[key];
        require(sk.enabled, "session disabled");
        if (sk.expiresAt != 0) {
            require(block.timestamp <= sk.expiresAt, "session expired");
        }
    }
}
