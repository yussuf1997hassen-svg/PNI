// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * sEE — Stablecoin-style ERC20 scaffold with:
 * - Cap (max supply)
 * - Role-gated mint
 * - Burnable (allowance-based burnFrom)
 * - Permit (EIP-2612) for gasless approvals
 * - Pause (role-gated)
 * - Optional blacklist (role-gated toggle)
 *
 * NOTE:
 * This contract by itself does NOT guarantee “stability”.
 * “Stable” requires a real reserve + redemption mechanism and/or deep market liquidity.
 *
 * Governance (DAT-aligned intent):
 * - Pause is designed to halt *transfers* (panic brake), while still allowing mint/burn for remediation if needed.
 *   If you want “pause means everything stops”, change the paused-logic in `_update`.
 */
contract SEEStablecoin is ERC20, ERC20Burnable, ERC20Permit, Pausable, AccessControl {
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BLACKLIST_ROLE = keccak256("BLACKLIST_ROLE");

    uint256 public immutable cap;

    bool public blacklistEnabled;
    mapping(address => bool) public blacklisted;

    event BlacklistEnabledSet(bool enabled);
    event BlacklistedSet(address indexed user, bool isBlacklisted);

    constructor(
        address admin,
        uint256 capWei,
        bool _blacklistEnabled
    ) ERC20("sEE", "sEE") ERC20Permit("sEE") {
        require(admin != address(0), "admin=0");
        require(capWei > 0, "cap=0");

        cap = capWei;

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(PAUSER_ROLE, admin);
        _grantRole(MINTER_ROLE, admin);
        _grantRole(BLACKLIST_ROLE, admin);

        blacklistEnabled = _blacklistEnabled;
        emit BlacklistEnabledSet(_blacklistEnabled);
    }

    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }

    function setBlacklistEnabled(bool enabled) external onlyRole(DEFAULT_ADMIN_ROLE) {
        blacklistEnabled = enabled;
        emit BlacklistEnabledSet(enabled);
    }

    function setBlacklisted(address user, bool isBlacklisted) external onlyRole(BLACKLIST_ROLE) {
        blacklisted[user] = isBlacklisted;
        emit BlacklistedSet(user, isBlacklisted);
    }

    function mint(address to, uint256 amount) external onlyRole(MINTER_ROLE) {
        require(to != address(0), "to=0");
        require(amount > 0, "amount=0");

        uint256 supply = totalSupply();
        require(amount <= cap - supply, "cap exceeded");
        _mint(to, amount);
    }

    /**
     * OZ v5 transfer/mint/burn hook.
     *
     * Pause policy (recommended):
     * - Block transfers when paused
     * - Allow mint (from==0) and burn (to==0) even when paused
     */
    function _update(address from, address to, uint256 value) internal override {
        if (paused()) {
            // allow mint/burn while paused; block regular transfers
            if (from != address(0) && to != address(0)) {
                revert("paused");
            }
        }

        if (blacklistEnabled) {
            // Transfer: block either side if blacklisted
            if (from != address(0) && to != address(0)) {
                require(!blacklisted[from], "from blacklisted");
                require(!blacklisted[to], "to blacklisted");
            }
            // Mint: block minting to blacklisted
            if (from == address(0) && to != address(0)) {
                require(!blacklisted[to], "to blacklisted");
            }
            // Burn: allow burn even if `from` is blacklisted (policy choice)
        }

        super._update(from, to, value);
    }
}
