import { ethers } from "hardhat";

// User-requested max supply (cap) in smallest units.
const CAP_WEI = BigInt("1000000000000000000000000000000000000000000000000000000000000");

async function main() {
  const [deployer] = await ethers.getSigners();

  const admin = process.env.ADMIN_ADDRESS && process.env.ADMIN_ADDRESS !== ""
    ? process.env.ADMIN_ADDRESS
    : deployer.address;

  console.log("Deployer:", deployer.address);
  console.log("Admin:", admin);

  const blacklistEnabled = (process.env.BLACKLIST_ENABLED || "true") === "true";
  const enableIntentController = (process.env.ENABLE_INTENT_CONTROLLER || "false") === "true";

  // Deploy stablecoin
  const Stable = await ethers.getContractFactory("SEEStablecoin");
  const stable = await Stable.deploy(admin, CAP_WEI, blacklistEnabled);
  await stable.waitForDeployment();
  const stableAddr = await stable.getAddress();
  console.log("SEEStablecoin deployed to:", stableAddr);

  // Deploy issuer vault
  const Vault = await ethers.getContractFactory("SEEReserveVault");
  const vault = await Vault.deploy(admin, stableAddr);
  await vault.waitForDeployment();
  const vaultAddr = await vault.getAddress();
  console.log("SEEReserveVault deployed to:", vaultAddr);

  // Grant MINTER_ROLE to vault so issuer can mint via vault ledger.
  const MINTER_ROLE = ethers.keccak256(ethers.toUtf8Bytes("MINTER_ROLE"));
  await (await stable.grantRole(MINTER_ROLE, vaultAddr)).wait();
  console.log("Granted MINTER_ROLE to vault");

  if (enableIntentController) {
    const Controller = await ethers.getContractFactory("SEEIssuerIntentController");
    const controller = await Controller.deploy(admin, vaultAddr);
    await controller.waitForDeployment();
    const controllerAddr = await controller.getAddress();
    console.log("SEEIssuerIntentController deployed to:", controllerAddr);

    const ISSUER_ROLE = ethers.keccak256(ethers.toUtf8Bytes("ISSUER_ROLE"));
    await (await vault.grantRole(ISSUER_ROLE, controllerAddr)).wait();
    console.log("Granted ISSUER_ROLE to controller (delegated issuer execution)");
  }

  console.log("\nNext steps:");
  console.log("1) Mint via vault (issuer ledger): scripts/mintOnDeposit.ts");
  console.log("2) Burn via vault (issuer ledger): scripts/burnOnRedeem.ts (user must approve vault first)");
  console.log("3) Optional: enable intent controller (delegated ops): set ENABLE_INTENT_CONTROLLER=true at deploy");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
