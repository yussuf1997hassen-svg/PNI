import { ethers } from "hardhat";

async function main() {
  const vaultAddr = process.env.VAULT_ADDRESS;
  const to = process.env.TO_ADDRESS;
  const amountWei = process.env.AMOUNT_WEI;
  const depositRef = process.env.DEPOSIT_REF;

  if (!vaultAddr) throw new Error("Set VAULT_ADDRESS");
  if (!to) throw new Error("Set TO_ADDRESS");
  if (!amountWei) throw new Error("Set AMOUNT_WEI");
  if (!depositRef) throw new Error("Set DEPOSIT_REF (unique)");

  const vault = await ethers.getContractAt("SEEReserveVault", vaultAddr);

  // Deposit ID = keccak256(utf8(depositRef))
  const depositId = ethers.keccak256(ethers.toUtf8Bytes(depositRef));

  const tx = await vault.mintOnDeposit(depositId, to, BigInt(amountWei));
  await tx.wait();

  console.log("Minted on depositId:", depositId);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
