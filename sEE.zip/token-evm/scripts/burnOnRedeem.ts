import { ethers } from "hardhat";

async function main() {
  const vaultAddr = process.env.VAULT_ADDRESS;
  const from = process.env.FROM_ADDRESS;
  const amountWei = process.env.AMOUNT_WEI;
  const redeemRef = process.env.REDEEM_REF;

  if (!vaultAddr) throw new Error("Set VAULT_ADDRESS");
  if (!from) throw new Error("Set FROM_ADDRESS");
  if (!amountWei) throw new Error("Set AMOUNT_WEI");
  if (!redeemRef) throw new Error("Set REDEEM_REF (unique)");

  const vault = await ethers.getContractAt("SEEReserveVault", vaultAddr);

  // Redeem ID = keccak256(utf8(redeemRef))
  const redeemId = ethers.keccak256(ethers.toUtf8Bytes(redeemRef));

  const tx = await vault.burnOnRedeem(redeemId, from, BigInt(amountWei));
  await tx.wait();

  console.log("Burned on redeemId:", redeemId);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
