# Contract Verification Notes

- Use the appropriate explorer (Arbiscan, Basescan)
- Prefer hardhat-verify plugin (add if needed)
- Ensure constructor args match deploy output

Constructors:
SEEStablecoin(admin, capWei, blacklistEnabled)
SEEReserveVault(admin, stablecoinAddress)
