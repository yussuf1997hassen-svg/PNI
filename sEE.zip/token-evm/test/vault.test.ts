import { expect } from "chai";
import { ethers } from "hardhat";

describe("SEEReserveVault + delegation controller", function () {
  const CAP = BigInt("1000000000000000000000000000000000000000000000000000000000000");

  async function deployAll(blacklistEnabled = false) {
    const [admin, user, delegate, recipient] = await ethers.getSigners();

    const Stable = await ethers.getContractFactory("SEEStablecoin");
    const stable = await Stable.deploy(admin.address, CAP, blacklistEnabled);
    await stable.waitForDeployment();

    const Vault = await ethers.getContractFactory("SEEReserveVault");
    const vault = await Vault.deploy(admin.address, await stable.getAddress());
    await vault.waitForDeployment();

    const MINTER_ROLE = ethers.keccak256(ethers.toUtf8Bytes("MINTER_ROLE"));
    await (await stable.grantRole(MINTER_ROLE, await vault.getAddress())).wait();

    return { admin, user, delegate, recipient, stable, vault };
  }

  it("prevents double-mint (depositId reuse)", async function () {
    const { stable, vault, user } = await deployAll();
    const depositId = ethers.keccak256(ethers.toUtf8Bytes("dep-1"));

    await (await vault.mintOnDeposit(depositId, user.address, 5n)).wait();
    expect(await stable.balanceOf(user.address)).to.equal(5n);

    await expect(vault.mintOnDeposit(depositId, user.address, 1n)).to.be.revertedWith("deposit used");
  });

  it("burnOnRedeem requires allowance", async function () {
    const { stable, vault, user } = await deployAll();

    const depositId = ethers.keccak256(ethers.toUtf8Bytes("dep-1"));
    await (await vault.mintOnDeposit(depositId, user.address, 5n)).wait();
    expect(await stable.balanceOf(user.address)).to.equal(5n);

    const redeemId = ethers.keccak256(ethers.toUtf8Bytes("red-1"));

    // no allowance => should revert
    await expect(vault.burnOnRedeem(redeemId, user.address, 1n)).to.be.reverted;

    // approve then burn
    await (await stable.connect(user).approve(await vault.getAddress(), 2n)).wait();
    await (await vault.burnOnRedeem(redeemId, user.address, 2n)).wait();
    expect(await stable.balanceOf(user.address)).to.equal(3n);

    // redeem reuse blocked
    await expect(vault.burnOnRedeem(redeemId, user.address, 1n)).to.be.revertedWith("redeem used");
  });

  it("delegation controller enforces expiry and daily caps", async function () {
    const { admin, stable, vault, delegate, recipient, user } = await deployAll();

    const Controller = await ethers.getContractFactory("SEEIssuerIntentController");
    const controller = await Controller.deploy(admin.address, await vault.getAddress());
    await controller.waitForDeployment();

    const ISSUER_ROLE = ethers.keccak256(ethers.toUtf8Bytes("ISSUER_ROLE"));
    await (await vault.grantRole(ISSUER_ROLE, await controller.getAddress())).wait();

    // set session key: cap 3 per day, allowlist recipient only
    const now = (await ethers.provider.getBlock("latest"))!.timestamp;
    await (await controller.setSessionKey(delegate.address, true, BigInt(now + 3600), 3n, 0n, true)).wait();
    await (await controller.setRecipientAllowed(delegate.address, recipient.address, true)).wait();

    // mint 2 ok
    const dep1 = ethers.keccak256(ethers.toUtf8Bytes("dep-a"));
    await (await controller.connect(delegate).mintOnDeposit(dep1, recipient.address, 2n)).wait();
    expect(await stable.balanceOf(recipient.address)).to.equal(2n);

    // mint 2 more fails (cap 3)
    const dep2 = ethers.keccak256(ethers.toUtf8Bytes("dep-b"));
    await expect(controller.connect(delegate).mintOnDeposit(dep2, recipient.address, 2n)).to.be.revertedWith("mint cap exceeded");

    // disallowed recipient fails
    const dep3 = ethers.keccak256(ethers.toUtf8Bytes("dep-c"));
    await expect(controller.connect(delegate).mintOnDeposit(dep3, user.address, 1n)).to.be.revertedWith("recipient not allowed");
  });
});
