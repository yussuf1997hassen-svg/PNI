import { expect } from "chai";
import { ethers } from "hardhat";

describe("SEEStablecoin", function () {
  const CAP = BigInt("1000000000000000000000000000000000000000000000000000000000000");

  it("enforces cap on mint (defensive cap math)", async function () {
    const [admin] = await ethers.getSigners();
    const Stable = await ethers.getContractFactory("SEEStablecoin");
    const stable = await Stable.deploy(admin.address, CAP, false);
    await stable.waitForDeployment();

    await stable.mint(admin.address, CAP);
    expect(await stable.totalSupply()).to.equal(CAP);

    await expect(stable.mint(admin.address, 1n)).to.be.revertedWith("cap exceeded");
  });

  it("pause blocks transfers but allows mint/burn (policy choice)", async function () {
    const [admin, bob] = await ethers.getSigners();
    const Stable = await ethers.getContractFactory("SEEStablecoin");
    const stable = await Stable.deploy(admin.address, CAP, false);
    await stable.waitForDeployment();

    await stable.mint(admin.address, 10n);

    await stable.pause();
    await expect(stable.transfer(bob.address, 1n)).to.be.revertedWith("paused");

    // mint allowed while paused
    await stable.mint(admin.address, 1n);
    expect(await stable.totalSupply()).to.equal(11n);

    // burn allowed while paused
    await stable.burn(1n);
    expect(await stable.totalSupply()).to.equal(10n);
  });

  it("blacklist (when enabled) blocks transfers and mint-to", async function () {
    const [admin, alice, bob] = await ethers.getSigners();
    const Stable = await ethers.getContractFactory("SEEStablecoin");
    const stable = await Stable.deploy(admin.address, CAP, true);
    await stable.waitForDeployment();

    await stable.mint(alice.address, 10n);

    await stable.setBlacklisted(alice.address, true);

    // transfer blocked
    await expect(stable.connect(alice).transfer(bob.address, 1n)).to.be.revertedWith("from blacklisted");

    // mint-to blocked
    await expect(stable.mint(alice.address, 1n)).to.be.revertedWith("to blacklisted");
  });

  it("only minter can mint", async function () {
    const [admin, alice] = await ethers.getSigners();
    const Stable = await ethers.getContractFactory("SEEStablecoin");
    const stable = await Stable.deploy(admin.address, CAP, false);
    await stable.waitForDeployment();

    await expect(stable.connect(alice).mint(alice.address, 1n)).to.be.reverted;
  });
});
