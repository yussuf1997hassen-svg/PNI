# Backend (Optional) — Indexer / Analytics Blueprint

If you need:
- faster transaction history
- receipts / invoices
- dashboards
- reserve attestation publishing pipeline

Recommended approach:
- Use a hosted indexer (The Graph / Subsquid) OR
- Build a lightweight event indexer that tracks:
  - Transfer events
  - MintOnDeposit / BurnOnRedeem events (from SEEReserveVault)

Do NOT store private keys. Do NOT store sensitive user data unless necessary.
