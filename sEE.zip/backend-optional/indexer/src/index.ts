import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { createPublicClient, http, parseEventLogs } from "viem";

const RPC_URL = process.env.RPC_URL || "http://127.0.0.1:8545";
const TOKEN = (process.env.SEE_TOKEN_ADDRESS || "") as `0x${string}`;
const VAULT = (process.env.SEE_VAULT_ADDRESS || "") as `0x${string}`;

const STATE_FILE = process.env.STATE_FILE || "./state.json";
const OUT_FILE = process.env.OUT_FILE || "./events.ndjson";
const BATCH_SIZE = BigInt(process.env.BATCH_SIZE || "2000");

if (!TOKEN.startsWith("0x") || TOKEN.length !== 42) throw new Error("Set SEE_TOKEN_ADDRESS");
if (!VAULT.startsWith("0x") || VAULT.length !== 42) throw new Error("Set SEE_VAULT_ADDRESS");

const seeAbi = [
  { type: "event", name: "Transfer", inputs: [{ indexed: true, name: "from", type: "address" }, { indexed: true, name: "to", type: "address" }, { indexed: false, name: "value", type: "uint256" }], anonymous: false },
] as const;

const vaultAbi = [
  { type: "event", name: "MintOnDeposit", inputs: [{ indexed: true, name: "depositId", type: "bytes32" }, { indexed: true, name: "to", type: "address" }, { indexed: false, name: "amount", type: "uint256" }], anonymous: false },
  { type: "event", name: "BurnOnRedeem", inputs: [{ indexed: true, name: "redeemId", type: "bytes32" }, { indexed: true, name: "from", type: "address" }, { indexed: false, name: "amount", type: "uint256" }], anonymous: false },
] as const;

type State = { lastScannedBlock: string };

function readState(): bigint {
  try {
    const s = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")) as State;
    return BigInt(s.lastScannedBlock);
  } catch {
    return 0n;
  }
}

function writeState(block: bigint) {
  fs.writeFileSync(STATE_FILE, JSON.stringify({ lastScannedBlock: block.toString() }, null, 2));
}

function append(line: unknown) {
  fs.appendFileSync(OUT_FILE, JSON.stringify(line) + "\n");
}

const client = createPublicClient({ transport: http(RPC_URL) });

async function main() {
  const latest = await client.getBlockNumber();
  let from = readState();
  if (from === 0n) from = latest > 10_000n ? latest - 10_000n : 0n; // first run: last ~10k blocks

  console.log("RPC:", RPC_URL);
  console.log("Token:", TOKEN);
  console.log("Vault:", VAULT);
  console.log("From:", from.toString(), "Latest:", latest.toString());

  let cursor = from;
  while (cursor <= latest) {
    const to = cursor + BATCH_SIZE > latest ? latest : cursor + BATCH_SIZE;

    const [tokenLogs, vaultLogs] = await Promise.all([
      client.getLogs({ address: TOKEN, fromBlock: cursor, toBlock: to }),
      client.getLogs({ address: VAULT, fromBlock: cursor, toBlock: to }),
    ]);

    const parsedToken = parseEventLogs({ abi: seeAbi, logs: tokenLogs, strict: false });
    const parsedVault = parseEventLogs({ abi: vaultAbi, logs: vaultLogs, strict: false });

    for (const l of parsedToken) {
      if (l.eventName === "Transfer") {
        const { from, to, value } = l.args as any;
        append({ chain: "see", kind: "Transfer", from, to, value: value.toString(), blockNumber: l.blockNumber?.toString(), txHash: l.transactionHash });
      }
    }
    for (const l of parsedVault) {
      if (l.eventName === "MintOnDeposit") {
        const { depositId, to, amount } = l.args as any;
        append({ chain: "see", kind: "MintOnDeposit", depositId, to, amount: amount.toString(), blockNumber: l.blockNumber?.toString(), txHash: l.transactionHash });
      }
      if (l.eventName === "BurnOnRedeem") {
        const { redeemId, from, amount } = l.args as any;
        append({ chain: "see", kind: "BurnOnRedeem", redeemId, from, amount: amount.toString(), blockNumber: l.blockNumber?.toString(), txHash: l.transactionHash });
      }
    }

    writeState(to + 1n);
    console.log("Scanned", cursor.toString(), "→", to.toString(), "| events:", parsedToken.length + parsedVault.length);
    cursor = to + 1n;
  }

  console.log("Done. Output:", path.resolve(OUT_FILE));
  console.log("State:", path.resolve(STATE_FILE));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
