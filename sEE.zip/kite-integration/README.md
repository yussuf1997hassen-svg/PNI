# Kite Integration Notes (derived from docs.gokite.ai)

This folder provides OPTIONAL patterns you can adopt for sEE governance and operations, inspired by Kite's agent-native infrastructure:

## Concepts applied
- **User remains the root of authority** (master wallet / ultimate control).
- **Delegation via session keys** (ephemeral keys with narrow scope + expiry).
- **Intent-based authorization** enforced by math (caps, rolling windows, allowlists).
- **Defense in depth** and least privilege.

## What is included
- `contracts/SEEIssuerIntentController.sol` (in token-evm/contracts):
  An optional on-chain controller that lets you delegate vault mint/burn execution to session keys
  while enforcing daily caps and optional recipient allowlists.

- `aa-sdk-example/`:
  A minimal TypeScript skeleton showing how you *could* use the GoKite AA SDK to create a smart account
  and manage rule-based spending, if you choose to deploy on (or integrate with) Kite Chain.

## What is NOT included
- Any requirement to use Kite Chain.
- Any custodial system or third-party governance. All authority can remain solely in your possession.

