#!/bin/sh
set -e

echo "[PNI] Edge Agent starting"
echo "[PNI] Governance mode: $GOVERNANCE_MODE"
echo "[PNI] Device ID: $DEVICE_ID"

python /app/edge_agent.py
