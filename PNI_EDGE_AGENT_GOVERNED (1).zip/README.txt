PNI EDGE AGENT — GOVERNED BUILD

This edge-agent enforces:
- Single-authority command execution (truDat)
- Policy-gated operation
- Deterministic runtime behavior

BUILD:
docker build -t pni/edge-agent:v1.0.0 .

RUN (standalone):
docker run --rm pni/edge-agent:v1.0.0

INTENDED USE:
Run under docker-compose with MQTT + policy-svc.
