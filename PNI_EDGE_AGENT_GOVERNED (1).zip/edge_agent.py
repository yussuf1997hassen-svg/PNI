import os
import time

DEVICE_ID = os.getenv("DEVICE_ID")
GOVERNANCE_MODE = os.getenv("GOVERNANCE_MODE", "strict")

def main():
    print(f"[PNI] Edge Agent ACTIVE")
    print(f"[PNI] Device: {DEVICE_ID}")
    print(f"[PNI] Governance: {GOVERNANCE_MODE}")
    while True:
        time.sleep(5)
        print("[PNI] Heartbeat OK — policy enforced")

if __name__ == "__main__":
    main()
