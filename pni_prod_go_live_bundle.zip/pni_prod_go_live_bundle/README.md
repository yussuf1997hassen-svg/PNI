# PNI Production Go-Live Bundle

This is the next SMART goal after staging: deploy to a stable “prod VM” and optionally enable TLS via Caddy.

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_prod_go_live_bundle
unzip -o ~/Downloads/pni_prod_go_live_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_prod_go_live_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO (from your Mac)
```bash
cd ~/Downloads/pni
PROD_HOST=YOUR_VM_IP_OR_DNS PROD_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 REMOTE_DIR=/home/ubuntu/pni DOMAIN=example.com ISSUER_PUBKEY_B64='mMnyXVv3w1sodDq7xskHzoOHZ3KCSUqxb1NewwdFkKQ=' bash tools/PROD_GO_LIVE_ONE_GO.sh
```

If you don't have a domain yet, omit DOMAIN to run base compose only.

## Check
```bash
PROD_HOST=... PROD_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 bash tools/PROD_STATUS.sh
PROD_HOST=... PROD_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 bash tools/PROD_TAIL_LOGS.sh
```

## Minimal monitoring (optional)
```bash
PROD_HOST=... PROD_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 REMOTE_DIR=/home/ubuntu/pni bash tools/PROD_INSTALL_SNAPSHOT_CRON.sh
```
