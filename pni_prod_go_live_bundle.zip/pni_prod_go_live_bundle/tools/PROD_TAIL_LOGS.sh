\
#!/usr/bin/env bash
set -euo pipefail
source tools/_pg_common.sh
: "${PROD_HOST:?Set PROD_HOST}"
PROD_USER="${PROD_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new"
need ssh

for c in pni-edge-agent edge-agent pni-hub-ingest hub-ingest pni-policy policy-svc pni-mosquitto mosquitto caddy; do
  if ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "docker ps --format '{{.Names}}' | grep -qx '$c'"; then
    echo "---- $c ----"
    ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "docker logs --tail=200 '$c' | grep -Ei 'telemetry|accepted|ok|apply|applied|command|policy|issuer|truDat' || docker logs --tail=80 '$c'"
    echo
  fi
done
