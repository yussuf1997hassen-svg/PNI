\
#!/usr/bin/env bash
set -euo pipefail
source tools/_pg_common.sh
: "${PROD_HOST:?Set PROD_HOST}"
PROD_USER="${PROD_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new"
need ssh
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'"
