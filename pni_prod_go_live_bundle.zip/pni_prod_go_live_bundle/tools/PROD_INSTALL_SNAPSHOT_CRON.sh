\
#!/usr/bin/env bash
set -euo pipefail
# Minimal "monitoring": create a cron job on the server that snapshots docker ps + filtered logs every 5 minutes.
source tools/_pg_common.sh
: "${PROD_HOST:?Set PROD_HOST}"
PROD_USER="${PROD_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
REMOTE_DIR="${REMOTE_DIR:-/home/${PROD_USER}/pni}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new"
need ssh

say "Install snapshot cron (every 5 minutes)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "bash -lc '
set -e
CRON=\"*/5 * * * * cd ${REMOTE_DIR} && mkdir -p dist && TS=\\\$(date +\\\%Y\\\%m\\\%d_\\\%H\\\%M\\\%S) && docker ps --format \\\"{{.Names}}\\t{{.Status}}\\t{{.Ports}}\\\" > dist/prod_ps_\\\${TS}.txt && for c in pni-hub-ingest hub-ingest pni-edge-agent edge-agent pni-policy policy-svc; do if docker ps --format \\\"{{.Names}}\\\" | grep -qx \\\"\\\${c}\\\"; then docker logs --tail=200 \\\"\\\${c}\\\" 2>&1 | grep -Ei \\\"telemetry|accepted|apply|applied|error|fail\\\" >> dist/prod_logs_\\\${TS}.txt || true; fi; done\"
( crontab -l 2>/dev/null | grep -v \"pni snapshot\"; echo \"# pni snapshot\"; echo \"${CRON}\" ) | crontab -
echo OK: cron installed
'"
