\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pg_common.sh

: "${PROD_HOST:?Set PROD_HOST (IP/DNS)}"
PROD_USER="${PROD_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
REMOTE_DIR="${REMOTE_DIR:-/home/${PROD_USER}/pni}"
ISSUER_PUBKEY_B64="${ISSUER_PUBKEY_B64:-mMnyXVv3w1sodDq7xskHzoOHZ3KCSUqxb1NewwdFkKQ=}"
DOMAIN="${DOMAIN:-}"

SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=15 -o ServerAliveCountMax=3"

say "0) Preflight"
need ssh
need rsync
[ -f "$SSH_KEY" ] || die "SSH key not found: $SSH_KEY"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "echo OK: connected; uname -a" >/dev/null

say "1) Ensure Docker on server (best-effort)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "command -v docker >/dev/null 2>&1 && echo OK: docker installed || (curl -fsSL https://get.docker.com | sh && sudo usermod -aG docker ${PROD_USER} && echo OK: docker installed)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "docker --version && (docker compose version || true)" || warn "If compose missing, install docker compose plugin and re-login."

say "2) Create remote dirs"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "mkdir -p '${REMOTE_DIR}' '${REMOTE_DIR}/dist' '${REMOTE_DIR}/logs' '${REMOTE_DIR}/secrets' '${REMOTE_DIR}/config' && chmod 700 '${REMOTE_DIR}/secrets' || true"

say "3) Upload repo (no secrets)"
rsync -az --delete \
  --exclude '.git/' \
  --exclude 'node_modules/' \
  --exclude 'secrets/' \
  --exclude '.env*' \
  --exclude 'dist/' \
  --exclude 'logs/' \
  ./ "${PROD_USER}@${PROD_HOST}:${REMOTE_DIR}/"

say "4) Upload prod overlay + caddy config"
rsync -az ./config/ "${PROD_USER}@${PROD_HOST}:${REMOTE_DIR}/config/"
rsync -az ./docker-compose.prod.yml "${PROD_USER}@${PROD_HOST}:${REMOTE_DIR}/docker-compose.prod.yml" 2>/dev/null || true

say "5) Install truDat public key on server (public only)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "printf '%s\n' '${ISSUER_PUBKEY_B64}' > '${REMOTE_DIR}/secrets/trudat_issuer_pubkey.b64' && chmod 600 '${REMOTE_DIR}/secrets/trudat_issuer_pubkey.b64' || true"

say "6) Start stack (with optional TLS proxy if DOMAIN set)"
if [ -n "${DOMAIN}" ]; then
  say "DOMAIN set -> enabling Caddy TLS proxy for https://${DOMAIN}"
  ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "cd '${REMOTE_DIR}' && export DOMAIN='${DOMAIN}' && (docker compose -f docker-compose.yml -f docker-compose.prod.yml down --remove-orphans || true) && docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build"
else
  say "DOMAIN not set -> running base compose only"
  ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "cd '${REMOTE_DIR}' && (docker compose down --remove-orphans || true) && docker compose up -d --build"
fi

say "7) Checks"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' | (head -n 1; grep -Ei 'mosquit|hub|ingest|edge|policy|caddy' || true)"

say "DONE ✅"
echo "Next:"
echo "  PROD_HOST=${PROD_HOST} PROD_USER=${PROD_USER} SSH_KEY=${SSH_KEY} bash tools/PROD_STATUS.sh"
echo "  PROD_HOST=${PROD_HOST} PROD_USER=${PROD_USER} SSH_KEY=${SSH_KEY} bash tools/PROD_TAIL_LOGS.sh"
