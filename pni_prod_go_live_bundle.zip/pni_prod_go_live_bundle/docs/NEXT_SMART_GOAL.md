# Next SMART goal: PRODUCTION GO-LIVE (minimal)

You are “production complete” when:
1) Stack runs on a **stable host** (not your laptop) AND is restart-safe.
2) Keys are handled safely:
   - VM/server has only **public** truDat key (verification).
   - issuer **private** key stays off the server (publish from your Mac) OR is stored in a real secret manager.
3) Monitoring exists:
   - you can prove telemetry continues
   - you get an alert when publish/apply fails
4) You can rebuild and redeploy from a single command.

This bundle deploys to a “prod VM” and optionally adds TLS via Caddy.
