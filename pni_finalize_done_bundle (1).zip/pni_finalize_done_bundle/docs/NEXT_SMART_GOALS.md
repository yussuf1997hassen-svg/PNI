# Next SMART goals after DONE proof

Now that you have a local “DONE deliverable”, the next real completion milestone is deployment-grade hardening:

1) **Security hardening**: move issuer key to hardware-backed storage; rotate test keys; enforce least-privilege ACL.
2) **Reproducible builds**: pin docker image digests + lockfiles; add CI pipeline to build & run the proof test.
3) **External environment**: choose where this runs (cloud VM / k8s / on-prem) and create an ops runbook.
4) **Token reality**: “higher value than existing currencies” is market-driven; what you can ship is utility, scarcity policy, and provable governance.
