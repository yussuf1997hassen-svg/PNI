# Finalize DONE bundle

Install + run tools/FINALIZE_DONE.sh to produce a final deliverable ZIP.
