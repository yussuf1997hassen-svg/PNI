\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_fd_common.sh

DIST="$ROOT/dist"
LOGS="$ROOT/logs"
mkdir -p "$DIST" "$LOGS"

say "1) Verify token equalization receipt exists"
REC="$DIST/mint_receipt.json"
[ -f "$REC" ] || die "Missing $REC. Run ENDGAME_ONE_GO.sh first."

say "2) Verify balances are equal (no private keys needed)"
python3 - <<'PY' "$REC"
import json,sys
p=sys.argv[1]
d=json.load(open(p,'r'))
b1=int(d.get("balance1Wei","0"))
b2=int(d.get("balance2Wei","0"))
if b1<=0 or b2<=0:
    raise SystemExit("ERROR: balances not present/zero in mint_receipt.json")
if b1!=b2:
    raise SystemExit(f"ERROR: balances differ: {b1} vs {b2}")
print("OK: balances equal")
print("contract:", d.get("contract"))
print("wallet1:", d.get("wallet1"))
print("wallet2:", d.get("wallet2"))
print("amountEach:", d.get("amountEach"))
PY

say "3) Capture PNI service status + logs snapshot (best-effort)"
need docker
TS="$(date +%Y%m%d_%H%M%S)"
STATUS="$DIST/pni_status_${TS}.txt"
LOGFILE="$DIST/pni_logs_${TS}.txt"

docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' > "$STATUS" || true
{
  echo "==== docker ps (filtered) ===="
  cat "$STATUS" | (head -n 1; grep -Ei 'mosquit|hub|ingest|edge|policy' || true)
  echo
  for c in pni-edge-agent edge-agent pni-hub-ingest hub-ingest pni-policy policy-svc pni-mosquitto mosquitto trudat-mosquitto; do
    if docker ps --format '{{.Names}}' | grep -qx "$c"; then
      echo "---- $c (last 200 lines) ----"
      docker logs --tail=200 "$c" 2>&1 | grep -Ei 'telemetry|accepted|ok|apply|applied|command|policy|issuer|truDat' || docker logs --tail=80 "$c" 2>&1 || true
      echo
    fi
  done
} > "$LOGFILE" || true

say "4) Create DONE report + final deliverable zip"
REPORT="$DIST/DONE_REPORT_${TS}.md"
OUTZIP="$DIST/DONE_DELIVERABLE_${TS}.zip"

python3 - <<'PY' "$REC" "$REPORT" "$STATUS" "$LOGFILE" "$TS"
import json,sys,os,hashlib,datetime
rec, report, status, logf, ts = sys.argv[1:]
d=json.load(open(rec,'r'))
def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for ch in iter(lambda: f.read(1024*1024), b''):
            h.update(ch)
    return h.hexdigest()
lines=[]
lines.append(f"# PNI + TruDAT — DONE REPORT ({ts})")
lines.append("")
lines.append("## Token equalization (local devnet proof)")
lines.append(f"- Contract: `{d.get('contract')}`")
lines.append(f"- Symbol/Decimals: `{d.get('symbol','TDAT')}` / `{d.get('decimals',18)}`")
lines.append(f"- Wallet1: `{d.get('wallet1')}`")
lines.append(f"- Wallet2: `{d.get('wallet2')}`")
lines.append(f"- Amount each: `{d.get('amountEach')}` (wei: `{d.get('amountEachWei')}`)")
lines.append(f"- Balance1Wei: `{d.get('balance1Wei')}`")
lines.append(f"- Balance2Wei: `{d.get('balance2Wei')}`")
lines.append("")
lines.append("## PNI stack snapshot (best-effort)")
lines.append(f"- Status file: `{os.path.basename(status)}`")
lines.append(f"- Logs file: `{os.path.basename(logf)}`")
lines.append("")
lines.append("## Integrity")
lines.append(f"- mint_receipt.json sha256: `{sha256(rec)}`")
lines.append("")
open(report,'w',encoding='utf-8').write("\n".join(lines)+ "\n")
print("OK: wrote", report)
PY

# assemble zip (include latest proof zips if present)
TMP="$DIST/.done_tmp_${TS}"
rm -rf "$TMP"
mkdir -p "$TMP"
cp -f "$REC" "$REPORT" "$STATUS" "$LOGFILE" "$TMP/" 2>/dev/null || true
ls -1t "$DIST"/ENDGAME_PROOF_*.zip 2>/dev/null | head -n 2 | xargs -I{} cp -f {} "$TMP/" 2>/dev/null || true
ls -1t "$DIST"/GO_LIVE_BUNDLE_*.zip 2>/dev/null | head -n 2 | xargs -I{} cp -f {} "$TMP/" 2>/dev/null || true

( cd "$TMP" && zip -r "$OUTZIP" . >/dev/null )
rm -rf "$TMP"

echo "OK: $OUTZIP"
echo "SHA256:"
shasum -a 256 "$OUTZIP" || true

say "DONE ✅"
echo "Deliverable: $OUTZIP"
