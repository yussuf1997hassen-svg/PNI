# Next SMART goal (final completion)

**Goal:** Single-run proof that the system is complete end-to-end.

**Definition of DONE (measurable):**
1) PNI: truDat publishes a signed command → policy approves → edge-agent applies (log evidence).
2) Token: deploy on local devnet → mint the exact same amount to two wallets → receipt saved to `dist/mint_receipt.json`.
3) Packaging: produce one final `dist/pni_DONE_<timestamp>.zip` for portability/audit.

**Note:** Token units can be equalized by code. Market price/value cannot be guaranteed by code.
