# PNI LAST MILE Bundle

This is the **final “one-go”** wrapper:
- Runs the PNI verification loop
- Mints equal balances to two wallets (local devnet)
- Produces the final DONE zip (if your factory script exists)

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_last_mile_bundle
unzip -o ~/Downloads/pni_last_mile_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_last_mile_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO
```bash
cd ~/Downloads/pni && WALLET1=0x... WALLET2=0x... MINT_TOKENS=1000000 bash tools/LAST_MILE_ONE_GO.sh
```
