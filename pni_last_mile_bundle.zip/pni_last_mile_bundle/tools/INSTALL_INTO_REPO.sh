\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo "Installed LAST MILE bundle into: $REPO_DIR"
echo "Run (ONE GO):"
echo "  cd ~/Downloads/pni && WALLET1=0x... WALLET2=0x... MINT_TOKENS=1000000 bash tools/LAST_MILE_ONE_GO.sh"
