\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_lm_common.sh

: "${WALLET1:?Set WALLET1=0x... (PUBLIC address)}"
: "${WALLET2:?Set WALLET2=0x... (PUBLIC address)}"
: "${MINT_TOKENS:?Set MINT_TOKENS e.g. 1000000}"

say "0) Safety: confirm you are NOT pasting private keys"
echo "OK: This run uses only PUBLIC addresses (WALLET1/WALLET2)."

say "1) Run PNI end-to-end verification (truDat publishes → edge applies)"
if [ -x tools/TRUDAT_COMPLETE_ONE_GO.sh ]; then
  DEVICE_ID="${DEVICE_ID:-truDat}" \
  WALLET1="$WALLET1" WALLET2="$WALLET2" MINT_TOKENS="$MINT_TOKENS" \
  bash tools/TRUDAT_COMPLETE_ONE_GO.sh
else
  die "tools/TRUDAT_COMPLETE_ONE_GO.sh not found. Re-install the completion bundle."
fi

say "2) Produce the single final DONE zip (entirety-of-entirety)"
if [ -x tools/FINAL_FACTORY_ONE_GO.sh ]; then
  bash tools/FINAL_FACTORY_ONE_GO.sh
else
  warn "tools/FINAL_FACTORY_ONE_GO.sh not found; skipping DONE zip. (Install pni_final_factory_bundle if you want it.)"
fi

say "3) Print the latest DONE zip path + sha256"
if ls -1t "$ROOT"/dist/pni_DONE_*.zip >/dev/null 2>&1; then
  Z="$(ls -1t "$ROOT"/dist/pni_DONE_*.zip | head -n 1)"
  echo "DONE ZIP: $Z"
  echo "SHA256:"
  shasum -a 256 "$Z" || true
  echo "Copied copy (if present):"
  ls -1t "$HOME/Downloads"/pni_DONE_*.zip 2>/dev/null | head -n 1 || true
else
  warn "No dist/pni_DONE_*.zip found."
fi

say "DONE ✅"
echo "Completion criteria:"
echo " - PNI: hub-ingest shows telemetry accepted/ok lines"
echo " - PNI: edge-agent shows apply/applied lines after publish"
echo " - Token: dist/mint_receipt.json exists with both wallets and equal amountEach"
echo " - Optional: dist/pni_DONE_<timestamp>.zip exists"
