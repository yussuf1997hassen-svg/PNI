# PNI Public Launch Bundle

This creates a **shareable public launch zip** from your mainnet receipts.

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_public_launch_bundle
unzip -o ~/Downloads/pni_public_launch_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_public_launch_bundle/tools/INSTALL_INTO_REPO.sh
```

## One go
```bash
cd ~/Downloads/pni
bash tools/PUBLIC_LAUNCH_ONE_GO.sh
```

Output:
- dist/TDAT_PUBLIC_LAUNCH_<timestamp>.zip
