\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pl_common.sh
need docker

# Optional: verify contracts on explorers using Hardhat.
# Requires:
#   ARBISCAN_API_KEY
#   BASESCAN_API_KEY
# and token-mainnet project present.
#
# This script will NOT run unless those env vars are set.

: "${ARBISCAN_API_KEY:?Set ARBISCAN_API_KEY to verify on Arbiscan}"
: "${BASESCAN_API_KEY:?Set BASESCAN_API_KEY to verify on Basescan}"

say "Verify on Arbitrum + Base (requires receipts and hardhat project)"
test -d token-mainnet || die "Missing token-mainnet folder"
test -f dist/mainnet_receipt_arbitrumOne.json || die "Missing arbitrum receipt"
test -f dist/mainnet_receipt_base.json || die "Missing base receipt"

ARB_ADDR="$(python3 -c 'import json;print(json.load(open("dist/mainnet_receipt_arbitrumOne.json"))["contract"])')"
BASE_ADDR="$(python3 -c 'import json;print(json.load(open("dist/mainnet_receipt_base.json"))["contract"])')"

docker run --rm \
  -e ARBISCAN_API_KEY="$ARBISCAN_API_KEY" -e BASESCAN_API_KEY="$BASESCAN_API_KEY" \
  -e ARBITRUM_ONE_RPC_URL="${ARBITRUM_ONE_RPC_URL:-}" -e BASE_MAINNET_RPC_URL="${BASE_MAINNET_RPC_URL:-}" \
  -v "$ROOT/token-mainnet:/app" -w /app node:20-bullseye bash -lc \
  "npm -s install >/dev/null && npx hardhat verify --network arbitrumOne $ARB_ADDR && npx hardhat verify --network base $BASE_ADDR"
