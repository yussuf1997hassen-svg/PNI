\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pl_common.sh
need zip

OUT_DIR="${OUT_DIR:-dist/public_launch}"
mkdir -p "$OUT_DIR"

TS="$(date +%Y%m%d_%H%M%S)"
ZIP="dist/TDAT_PUBLIC_LAUNCH_${TS}.zip"

say "Create public launch zip (tokenlist + report + receipts; no secrets)"
rm -f "$ZIP"
zip -r "$ZIP" \
  "$OUT_DIR/tokenlist.json" \
  "$OUT_DIR/PUBLIC_REPORT.md" \
  dist/mainnet_receipt_*.json \
  docs/LAUNCH_SMART_GOALS.md \
  >/dev/null

echo "OK: $ZIP"
shasum -a 256 "$ZIP" || true
