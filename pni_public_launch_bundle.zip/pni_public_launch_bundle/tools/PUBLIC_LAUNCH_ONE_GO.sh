\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pl_common.sh

say "0) Public launch artifact generation (no secrets)"
bash tools/VERIFY_MAINNET_RECEIPTS.sh

say "1) Build public artifacts"
OUT_DIR="dist/public_launch"
INCLUDE_WALLETS="${INCLUDE_WALLETS:-false}" \
OUT_DIR="$OUT_DIR" bash tools/GENERATE_PUBLIC_REPORT.sh
OUT_DIR="$OUT_DIR" bash tools/GENERATE_TOKENLIST.sh

say "2) Package public launch zip"
OUT_DIR="$OUT_DIR" bash tools/MAKE_PUBLIC_LAUNCH_ZIP.sh

say "DONE ✅"
echo "Your shareable artifact is in dist/TDAT_PUBLIC_LAUNCH_*.zip"
echo "Next: publish that zip + contract addresses on your website/repo, and set up liquidity + listing."
