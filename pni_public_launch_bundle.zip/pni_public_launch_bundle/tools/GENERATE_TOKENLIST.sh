\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pl_common.sh

OUT_DIR="${OUT_DIR:-dist/public_launch}"
mkdir -p "$OUT_DIR"

say "Generate tokenlist JSON from receipts (no private keys)"
python3 - <<'PY'
import json,glob,os,datetime
out_dir=os.environ.get("OUT_DIR","dist/public_launch")
files=sorted(glob.glob("dist/mainnet_receipt_*.json"))
if not files:
    raise SystemExit("ERROR: missing dist/mainnet_receipt_*.json")
tokens=[]
for f in files:
    d=json.load(open(f))
    chainId=int(d["chainId"])
    tokens.append({
        "chainId": chainId,
        "address": d["contract"],
        "name": "TruDAT",
        "symbol": "TDAT",
        "decimals": 18,
        "logoURI": "https://example.com/tokens/TDAT.png"
    })
tokenlist={
  "name":"TruDAT Token List",
  "timestamp": datetime.datetime.utcnow().isoformat()+"Z",
  "version":{"major":1,"minor":0,"patch":0},
  "tokens": tokens
}
path=os.path.join(out_dir,"tokenlist.json")
with open(path,"w") as w: json.dump(tokenlist,w,indent=2)
print("OK:", path)
PY
