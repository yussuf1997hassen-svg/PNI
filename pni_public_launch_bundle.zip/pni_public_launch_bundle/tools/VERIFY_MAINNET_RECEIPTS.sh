\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pl_common.sh

say "Verify mainnet receipts exist and are internally consistent"
python3 - <<'PY'
import json,glob,sys,os
files=sorted(glob.glob("dist/mainnet_receipt_*.json"))
if not files:
    raise SystemExit("ERROR: Missing dist/mainnet_receipt_*.json. Run the mainnet deploy step first.")
ok=True
for f in files:
    d=json.load(open(f))
    chain=d.get("chainId"); net=d.get("network"); c=d.get("contract")
    b1=int(d["balance1Wei"]); b2=int(d["balance2Wei"]); ts=int(d["totalSupplyWei"]); a=int(d["amountEachWei"])
    if b1!=b2 or b1!=a or ts!=(2*a):
        ok=False
        print("FAIL", os.path.basename(f), "chainId", chain, "contract", c)
        print("  b1", b1, "b2", b2, "a", a, "ts", ts)
    else:
        print("OK ", os.path.basename(f), "chainId", chain, "contract", c, "renounced", d.get("renounced"))
if not ok:
    sys.exit(1)
PY
say "OK: receipts validated ✅"
