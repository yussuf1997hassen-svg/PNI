\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pl_common.sh

OUT_DIR="${OUT_DIR:-dist/public_launch}"
INCLUDE_WALLETS="${INCLUDE_WALLETS:-false}"
mkdir -p "$OUT_DIR"

say "Generate PUBLIC_REPORT.md (wallets redacted by default)"
python3 - <<'PY'
import json,glob,os,datetime
out_dir=os.environ.get("OUT_DIR","dist/public_launch")
include=(os.environ.get("INCLUDE_WALLETS","false").lower()=="true")
files=sorted(glob.glob("dist/mainnet_receipt_*.json"))
if not files: raise SystemExit("ERROR: missing dist/mainnet_receipt_*.json")
lines=[]
lines.append("# TruDAT (TDAT) — Public Deployment Report")
lines.append("")
lines.append(f"Generated: {datetime.datetime.utcnow().isoformat()}Z")
lines.append("")
lines.append("## Summary")
lines.append("- Token: TruDAT (TDAT), 18 decimals")
lines.append("- Deployed on: Arbitrum One (42161) and Base (8453)")
lines.append("- Proof: receipts below show equal mint to two wallets and total supply = 2×mint")
lines.append("")
for f in files:
    d=json.load(open(f))
    chain=int(d["chainId"]); contract=d["contract"]; dep=d["deployer"]
    mint_each=d["amountEach"]; ren=d.get("renounced"); rtx=d.get("renounceTxHash")
    b1=d["balance1Wei"]; b2=d["balance2Wei"]; ts=d["totalSupplyWei"]
    lines.append(f"## {d.get('network')} (chainId {chain})")
    lines.append(f"- Contract: `{contract}`")
    lines.append(f"- Deployer: `{dep}`")
    lines.append(f"- Mint each: `{mint_each}` TDAT")
    if include:
        lines.append(f"- Wallet1: `{d['wallet1']}`")
        lines.append(f"- Wallet2: `{d['wallet2']}`")
    else:
        lines.append(f"- Wallet1: (redacted)")
        lines.append(f"- Wallet2: (redacted)")
    lines.append(f"- balance1Wei: `{b1}`")
    lines.append(f"- balance2Wei: `{b2}`")
    lines.append(f"- totalSupplyWei: `{ts}`")
    lines.append(f"- ownershipRenounced: `{bool(ren)}`")
    if ren and rtx:
        lines.append(f"- renounceTxHash: `{rtx}`")
    lines.append("")
path=os.path.join(out_dir,"PUBLIC_REPORT.md")
with open(path,"w") as w: w.write("\n".join(lines)+"\n")
print("OK:", path)
PY
