# TruDAT Final Publish Bundle

This bundle wires your **truDat issuer pubkey** into the repo (best-effort) and runs a **final publish + verification**.

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_trudat_final_publish_bundle
unzip -o ~/Downloads/pni_trudat_final_publish_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_trudat_final_publish_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO
```bash
cd ~/Downloads/pni && ISSUER_PUBKEY_B64='mMnyXVv3w1sodDq7xskHzoOHZ3KCSUqxb1NewwdFkKQ=' DEVICE_ID=truDat bash tools/TRUDAT_FINAL_ONE_GO.sh
```

## Final publish command (single line)
If your `bin/command-cli` matches the flags shown, this is the **single** publish command:
```bash
cd ~/Downloads/pni && ./bin/command-cli -issuer truDat -device truDat -cmd set_publish_interval_ms -params '{"value":1000}'
```
