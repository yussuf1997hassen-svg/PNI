\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_tp_common.sh

: "${ISSUER_PUBKEY_B64:?Set ISSUER_PUBKEY_B64='base64...'}"
DEVICE_ID="${DEVICE_ID:-truDat}"
CMD_NAME="${CMD_NAME:-set_publish_interval_ms}"
CMD_VALUE="${CMD_VALUE:-1000}"

say "0) Fix common zsh running-jobs friction (safe)"
# Don’t kill anything; just show
jobs -l || true

say "1) Persist truDat issuer pubkey (public only)"
mkdir -p secrets
chmod 700 secrets || true
printf "%s\n" "$ISSUER_PUBKEY_B64" > secrets/trudat_issuer_pubkey.b64
chmod 600 secrets/trudat_issuer_pubkey.b64 || true
echo "OK: secrets/trudat_issuer_pubkey.b64 written"

say "2) Best-effort: patch registry.json to include truDat pubkey (if file exists)"
REG_CANDIDATES=(
  "$ROOT/registry.json"
  "$ROOT/cmd/policy-svc/registry.json"
  "$ROOT/config/registry.json"
  "$ROOT/config/registry.local.json"
)
REG=""
for f in "${REG_CANDIDATES[@]}"; do
  if [ -f "$f" ]; then REG="$f"; break; fi
done

if [ -n "$REG" ]; then
  echo "Found registry: $REG"
  python3 - <<'PY' "$REG" "$ISSUER_PUBKEY_B64"
import json, sys
path, pub = sys.argv[1], sys.argv[2]
with open(path,'r',encoding='utf-8') as f:
    data=json.load(f)

# The structure may vary; we try a few common shapes.
changed=False

def ensure_in_list(obj, key):
    global changed
    lst=obj.get(key)
    if lst is None:
        obj[key]=[pub]; changed=True; return
    if isinstance(lst,list) and pub not in lst:
        lst.append(pub); changed=True

# Shape A: {"allowed_publishers": {"truDat": ["..."]}}
ap=data.get("allowed_publishers")
if isinstance(ap, dict):
    cur=ap.get("truDat")
    if cur is None:
        ap["truDat"]=[pub]; changed=True
    elif isinstance(cur, list) and pub not in cur:
        cur.append(pub); changed=True

# Shape B: {"issuers": {"truDat": {"pubkeys_b64":[...]}}}
issuers=data.get("issuers")
if isinstance(issuers, dict):
    it=issuers.get("truDat")
    if it is None:
        issuers["truDat"]={"pubkeys_b64":[pub]}; changed=True
    elif isinstance(it, dict):
        ensure_in_list(it, "pubkeys_b64")
        ensure_in_list(it, "pubkeys")

# Shape C: {"publishers":[{"id":"truDat","pubkey_b64":"..."}]}
pubs=data.get("publishers")
if isinstance(pubs, list):
    found=False
    for p in pubs:
        if isinstance(p, dict) and p.get("id")== "truDat":
            found=True
            if p.get("pubkey_b64") != pub:
                p["pubkey_b64"]=pub; changed=True
    if not found:
        pubs.append({"id":"truDat","pubkey_b64":pub}); changed=True

# If nothing matched, add a conservative top-level key
if not changed and "allowed_publishers" not in data and "issuers" not in data and "publishers" not in data:
    data["allowed_publishers"]={"truDat":[pub]}; changed=True

if changed:
    with open(path,'w',encoding='utf-8') as f:
        json.dump(data,f,indent=2,sort_keys=True)
    print("OK: registry updated")
else:
    print("OK: registry already contained pubkey (or no change needed)")
PY
else
  warn "No registry.json found in common locations; skipping patch."
fi

say "3) Bring up Docker stack (compose)"
need docker
if [ -f "$ROOT/docker-compose.yml" ] || [ -f "$ROOT/docker-compose.yaml" ] || [ -f "$ROOT/compose.yaml" ] || [ -f "$ROOT/compose.yml" ]; then
  docker compose down --remove-orphans || true
  docker compose up -d --build
else
  warn "No compose file found in repo root; skipping compose up."
fi

say "4) Quick health check (containers + ports)"
docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' | (head -n 1; grep -Ei 'mosquit|hub|ingest|edge|policy' || true)

say "5) Publish one command as truDat"
if [ -x "$ROOT/bin/command-cli" ]; then
  "$ROOT/bin/command-cli" -issuer truDat -device "$DEVICE_ID" -cmd "$CMD_NAME" -params "{\"value\":$CMD_VALUE}"
  echo "OK: command-cli invoked"
else
  warn "bin/command-cli missing. Try running publish via mosquitto_pub if your repo provides the topic/payload."
fi

say "6) Verify apply + telemetry lines (tail logs)"
# best-effort container names
for c in pni-edge-agent edge-agent pni_hub_ingest pni-hub-ingest hub-ingest pni-policy policy-svc; do
  if docker ps --format '{{.Names}}' | grep -qx "$c"; then
    echo "-- $c (last 120) --"
    docker logs --tail=120 "$c" | grep -Ei 'telemetry|accepted|ok|apply|applied|command|policy|issuer|truDat' || true
  fi
done

say "DONE ✅"
echo "If you still see Docker 'mount source path' 500 errors:"
echo " - ensure the host paths referenced in docker-compose volumes actually exist"
echo " - ensure ~/Downloads is shared in Docker Desktop > Settings > Resources > File Sharing"
