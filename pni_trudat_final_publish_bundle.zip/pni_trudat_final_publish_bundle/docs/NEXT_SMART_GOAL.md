# Next SMART goal (completion)

You’re done when you can produce **evidence**, not just “it runs”.

## DONE checklist
- Docker: mosquitto + hub-ingest + edge-agent running (no mount errors)
- Publish: truDat issues a command
- Policy: command is accepted (ACL match)
- Edge: command is applied (log shows apply/applied)
- Proof artifact: save logs/receipt into dist/

## Note on “higher value than existing currencies”
That’s not programmable. What you can complete is:
- governance / ACL / signature enforcement
- distribution rules
- auditable receipts & proof bundle
