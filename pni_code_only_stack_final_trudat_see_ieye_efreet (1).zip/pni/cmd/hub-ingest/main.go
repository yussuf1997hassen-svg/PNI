package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"

	"pni/internal/pni"
	policypb "pni/proto/policy"
)

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func main() {
	mqttBroker := getenv("MQTT_BROKER", "ssl://127.0.0.1:8883")
	sub := getenv("MQTT_SUB", "pni/telemetry/#")

	// Hub MQTT mTLS
	mqttCA := getenv("MQTT_TLS_CA", "./certs/ca/ca.crt")
	mqttCert := getenv("MQTT_TLS_CERT", "./certs/clients/hub.crt")
	mqttKey := getenv("MQTT_TLS_KEY", "./certs/clients/hub.key")
	mqttServerName := getenv("MQTT_TLS_SERVER_NAME", "localhost")

	mqttTLS, err := pni.LoadTLSConfig(mqttCA, mqttCert, mqttKey, mqttServerName)
	if err != nil {
		panic(err)
	}

	// Policy gRPC mTLS (hub as client)
	policyAddr := getenv("POLICY_ADDR", "127.0.0.1:9443")
	policyCA := getenv("POLICY_TLS_CA", "./certs/ca/ca.crt")
	policyCert := getenv("POLICY_TLS_CERT", "./certs/clients/hub.crt")
	policyKey := getenv("POLICY_TLS_KEY", "./certs/clients/hub.key")
	policyServerName := getenv("POLICY_TLS_SERVER_NAME", "localhost")

	grpcTLSCfg, err := pni.LoadMTLSClientConfig(policyCA, policyCert, policyKey, policyServerName)
	if err != nil {
		panic(err)
	}

	conn, err := grpc.Dial(
		policyAddr,
		grpc.WithTransportCredentials(credentials.NewTLS(grpcTLSCfg)),
		grpc.WithDefaultCallOptions(grpc.CallContentSubtype("json")),
	)
	if err != nil {
		panic(err)
	}
	defer conn.Close()

	policyClient := policypb.NewPolicyCheckClient(conn)

	opts := mqtt.NewClientOptions().
		AddBroker(mqttBroker).
		SetClientID("hub-ingest-1").
		SetTLSConfig(mqttTLS).
		SetAutoReconnect(true)

	client := mqtt.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	defer client.Disconnect(250)

	fmt.Println("hub-ingest started", "broker=", mqttBroker, "sub=", sub)

	handler := func(_ mqtt.Client, msg mqtt.Message) {
		var env pni.Envelope
		if err := json.Unmarshal(msg.Payload(), &env); err != nil {
			fmt.Println("bad envelope:", err)
			return
		}

		pubBytes, err := pni.FromB64(env.PubKeyB64)
		if err != nil {
			fmt.Println("bad pubkey b64:", err)
			return
		}
		sigBytes, err := pni.FromB64(env.SignatureB64)
		if err != nil {
			fmt.Println("bad sig b64:", err)
			return
		}

		// Verify signature over raw payload bytes
		if !pni.Verify(pubBytes, []byte(env.Payload), sigBytes) {
			fmt.Println("SIGNATURE FAIL", "topic=", msg.Topic(), "device=", env.DeviceID)
			return
		}

		// Decode telemetry
		var t pni.TelemetryUnsigned
		if err := json.Unmarshal(env.Payload, &t); err != nil {
			fmt.Println("bad payload:", err)
			return
		}

		// Policy check (defense-in-depth)
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()

		resp, err := policyClient.Check(ctx, &policypb.CheckRequest{
			Topic:            msg.Topic(),
			EnvelopeDeviceID: env.DeviceID,
			ContentType:      env.ContentType,
			SchemaVersion:    env.SchemaVersion,
			PayloadJSON:      []byte(env.Payload),
			PubKey:           pubBytes,
			Signature:        sigBytes,
			ReceivedUnixMs:   time.Now().UnixMilli(),
		})
		if err != nil {
			fmt.Println("POLICY ERROR (fail-closed):", err)
			return
		}
		if !resp.Allow {
			fmt.Println("POLICY DENY", "action=", resp.Action, "reason=", resp.Reason, "device=", env.DeviceID)
			return
		}
		if resp.Action == "QUARANTINE" {
			fmt.Println("POLICY QUARANTINE", "reason=", resp.Reason, "device=", env.DeviceID)
			return
		}
		if resp.Action == "ALERT" {
			fmt.Println("POLICY ALERT", "reason=", resp.Reason, "device=", env.DeviceID)
		}

		fmt.Printf("OK device=%s event=%s score=%.3f ac=%.3f vib=%.3f emi=%.3f ts=%d\n",
			t.DeviceID, t.EventType, t.AnomalyScore, t.AcousticRMS, t.VibrationRMS, t.EMIPower, t.TsUnixMs)
	}

	if token := client.Subscribe(sub, 1, handler); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}

	select {}
}
