package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"

	"pni/internal/pni"
	policypb "pni/proto/policy"
)

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

type server struct {
	policypb.UnimplementedPolicyCheckServer

	rm *pni.RegistryManager
	rl *pni.RateLimiter
	qs *pni.QuarantineSink

	maxSkew time.Duration
}

func resolvePatterns(deviceID string, patterns []string) []string {
	out := make([]string, 0, len(patterns))
	for _, p := range patterns {
		p = strings.ReplaceAll(p, "%u", deviceID)
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func modelAllowed(allow []string, model string) bool {
	if len(allow) == 0 {
		return false
	}
	for _, v := range allow {
		if v == model {
			return true
		}
	}
	return false
}

func (s *server) Health(ctx context.Context, _ *policypb.HealthRequest) (*policypb.HealthResponse, error) {
	return &policypb.HealthResponse{Status: "ok"}, nil
}

func (s *server) Check(ctx context.Context, req *policypb.CheckRequest) (*policypb.CheckResponse, error) {
	reg, ok := s.rm.Get()
	if !ok {
		return &policypb.CheckResponse{Allow: false, Reason: "registry not loaded", Action: "DROP", PolicyVersion: 0}, nil
	}
	pv := reg.Version

	deny := func(reason, action string) *policypb.CheckResponse {
		if action == "QUARANTINE" && s.qs != nil {
			s.qs.Emit(pni.QuarantineRecord{
				DeviceID:       req.EnvelopeDeviceID,
				Topic:          req.Topic,
				Reason:         reason,
				Action:         action,
				ReceivedUnixMs: req.ReceivedUnixMs,
				PolicyVersion:  pv,
				ContentType:    req.ContentType,
				SchemaVersion:  req.SchemaVersion,
				PayloadSize:    len(req.PayloadJSON),
			})
		}
		return &policypb.CheckResponse{Allow: false, Reason: reason, Action: action, PolicyVersion: pv}
	}
	allow := func(reason, action string) *policypb.CheckResponse {
		return &policypb.CheckResponse{Allow: true, Reason: reason, Action: action, PolicyVersion: pv}
	}

	if req.EnvelopeDeviceID == "" {
		return deny("missing envelope_device_id", "DROP"), nil
	}
	if len(req.PayloadJSON) == 0 {
		return deny("missing payload_json", "DROP"), nil
	}

	dp, exists := reg.Devices[req.EnvelopeDeviceID]
	if !exists {
		return deny("unknown device", "DROP"), nil
	}

	// Topic policy (exact + patterns) with %u + MQTT wildcards
	if !pni.TopicAllowed(req.EnvelopeDeviceID, req.Topic, dp.AllowTopics, dp.AllowTopicPatterns) {
		return deny("topic not allowed", "DROP"), nil
	}

	// Timestamp skew check
	now := time.Now()
	recv := time.UnixMilli(req.ReceivedUnixMs)
	if req.ReceivedUnixMs == 0 {
		recv = now
	}
	if now.Sub(recv) > s.maxSkew || recv.Sub(now) > s.maxSkew {
		return deny("received time skew too large", "QUARANTINE"), nil
	}

	// Verify signature (defense-in-depth)
	if len(req.PubKey) != 32 || len(req.Signature) != 64 {
		return deny("bad pubkey/signature length", "DROP"), nil
	}
	if !pni.Verify(req.PubKey, req.PayloadJSON, req.Signature) {
		return deny("signature verify failed", "DROP"), nil
	}

	var t pni.TelemetryUnsigned
	if err := json.Unmarshal(req.PayloadJSON, &t); err != nil {
		return deny("payload json decode failed", "DROP"), nil
	}

	if t.DeviceID != req.EnvelopeDeviceID {
		return deny("payload.device_id mismatch", "DROP"), nil
	}
	if t.AnomalyScore < 0 || t.AnomalyScore > 1 {
		return deny("anomaly_score out of range", "DROP"), nil
	}
	if t.EventType != "normal" && t.EventType != "anomaly" {
		return deny("invalid event_type", "DROP"), nil
	}

	if !modelAllowed(dp.AllowModelVers, t.ModelVer) {
		return deny("model version not allowed", "DROP"), nil
	}

	if s.rl != nil {
		ok, cnt := s.rl.AllowNPerMinute(req.EnvelopeDeviceID, dp.MaxMsgsPerMin)
		if !ok {
			return deny(fmt.Sprintf("rate limit exceeded (%d/min), count=%d", dp.MaxMsgsPerMin, cnt), "QUARANTINE"), nil
		}
	}

	if req.ContentType != "" && req.ContentType != "pni.telemetry.v1" {
		return deny("unexpected content_type", "DROP"), nil
	}
	if req.SchemaVersion != "" && req.SchemaVersion != "1" {
		return deny("unexpected schema_version", "DROP"), nil
	}

	if t.EventType == "anomaly" && t.AnomalyScore > 0.90 {
		return allow("high anomaly", "ALERT"), nil
	}

	return allow("ok", "ACCEPT"), nil
}

func (s *server) buildRuntimePolicy(deviceID string) (*policypb.GetDeviceRuntimePolicyResponse, error) {
	reg, ok := s.rm.Get()
	if !ok {
		return &policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "registry not loaded"}, nil
	}
	dp, exists := reg.Devices[deviceID]
	if !exists {
		return &policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "unknown device", RegistryVersion: reg.Version}, nil
	}

	cmdTopics := resolvePatterns(deviceID, dp.CommandTopicPatterns)

	skew := s.maxSkew
	if dp.CommandMaxSkewSec > 0 {
		skew = time.Duration(dp.CommandMaxSkewSec) * time.Second
	}
	replayTTL := skew
	if dp.ReplayTTLSec > 0 {
		replayTTL = time.Duration(dp.ReplayTTLSec) * time.Second
	}

	return &policypb.GetDeviceRuntimePolicyResponse{
		Allow:                    true,
		Reason:                   "ok",
		RegistryVersion:          reg.Version,
		CommandTopics:            cmdTopics,
		AllowedCommandSignersB64: dp.AllowedCommandSignersB64,
		CommandMaxSkewMs:         int64(skew / time.Millisecond),
		ReplayTtlMs:              int64(replayTTL / time.Millisecond),
	}, nil
}

func (s *server) GetDeviceRuntimePolicy(ctx context.Context, req *policypb.GetDeviceRuntimePolicyRequest) (*policypb.GetDeviceRuntimePolicyResponse, error) {
	if req.DeviceId == "" {
		return &policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "missing device_id"}, nil
	}
	cn, err := pni.PeerCommonNameFromContext(ctx)
	if err != nil {
		return &policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "cannot read peer identity"}, nil
	}
	if cn != req.DeviceId {
		return &policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "caller CN does not match device_id"}, nil
	}
	return s.buildRuntimePolicy(req.DeviceId)
}

func (s *server) WatchDeviceRuntimePolicy(req *policypb.GetDeviceRuntimePolicyRequest, stream policypb.PolicyCheck_WatchDeviceRuntimePolicyServer) error {
	if req.DeviceId == "" {
		_ = stream.Send(&policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "missing device_id"})
		return nil
	}
	cn, err := pni.PeerCommonNameFromContext(stream.Context())
	if err != nil {
		_ = stream.Send(&policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "cannot read peer identity"})
		return nil
	}
	if cn != req.DeviceId {
		_ = stream.Send(&policypb.GetDeviceRuntimePolicyResponse{Allow: false, Reason: "caller CN does not match device_id"})
		return nil
	}

	resp, _ := s.buildRuntimePolicy(req.DeviceId)
	if err := stream.Send(resp); err != nil {
		return err
	}
	lastVer := resp.RegistryVersion

	pollMs, _ := strconv.Atoi(getenv("WATCH_POLL_MS", "1000"))
	if pollMs < 250 {
		pollMs = 250
	}
	t := time.NewTicker(time.Duration(pollMs) * time.Millisecond)
	defer t.Stop()

	for {
		select {
		case <-stream.Context().Done():
			return nil
		case <-t.C:
			r, ok := s.rm.Get()
			if !ok {
				continue
			}
			if r.Version == lastVer {
				continue
			}
			resp, _ := s.buildRuntimePolicy(req.DeviceId)
			if err := stream.Send(resp); err != nil {
				return err
			}
			lastVer = resp.RegistryVersion
		}
	}
}

func main() {
	addr := getenv("POLICY_ADDR", "127.0.0.1:9443")

	ca := getenv("POLICY_TLS_CA", "./certs/ca/ca.crt")
	serverCrt := getenv("POLICY_TLS_CERT", "./certs/policy/policy.crt")
	serverKey := getenv("POLICY_TLS_KEY", "./certs/policy/policy.key")

	regPath := getenv("REGISTRY_PATH", "./registry.json")
	pollMs := getenv("REGISTRY_POLL_MS", "2000")
	pollEvery := 2 * time.Second
	if n, err := time.ParseDuration(pollMs + "ms"); err == nil {
		pollEvery = n
	}

	maxSkewSec := getenv("POLICY_MAX_SKEW_SEC", "600")
	skew, _ := time.ParseDuration(maxSkewSec + "s")
	if skew == 0 {
		skew = 10 * time.Minute
	}

	// Quarantine sink
	qMode := getenv("QUARANTINE_MODE", "file")
	qFile := getenv("QUARANTINE_FILE", "./quarantine.log.jsonl")
	qMqttBroker := getenv("QUARANTINE_MQTT_BROKER", "ssl://127.0.0.1:8883")
	qBaseTopic := getenv("QUARANTINE_MQTT_BASE_TOPIC", "pni/quarantine")
	qClientID := getenv("QUARANTINE_MQTT_CLIENT_ID", "policy-svc-quarantine")

	mqttCA := getenv("MQTT_TLS_CA", "./certs/ca/ca.crt")
	mqttCert := getenv("MQTT_TLS_CERT", "./certs/policy/policy.crt")
	mqttKey := getenv("MQTT_TLS_KEY", "./certs/policy/policy.key")
	mqttServerName := getenv("MQTT_TLS_SERVER_NAME", "localhost")

	rm := pni.NewRegistryManager(regPath, pollEvery)
	if err := rm.LoadOnce(); err != nil {
		panic(err)
	}
	rm.StartAutoReload(func(f string, args ...any) { fmt.Printf((f + "\n"), args...) })

	var qs *pni.QuarantineSink
	if qMode != "off" {
		qs = pni.NewQuarantineSink(qMode)
		if qMode == "file" || qMode == "both" {
			if err := qs.InitFile(qFile); err != nil {
				panic(err)
			}
		}
		if qMode == "mqtt" || qMode == "both" {
			tlsCfg, err := pni.LoadTLSConfig(mqttCA, mqttCert, mqttKey, mqttServerName)
			if err != nil {
				panic(err)
			}
			if err := qs.InitMQTT(qMqttBroker, qClientID, qBaseTopic, tlsCfg); err != nil {
				panic(err)
			}
		}
		defer qs.Close()
	}

	tlsCfg, err := pni.LoadMTLSServerConfig(ca, serverCrt, serverKey)
	if err != nil {
		panic(err)
	}

	lis, err := net.Listen("tcp", addr)
	if err != nil {
		panic(err)
	}

	grpcServer := grpc.NewServer(grpc.Creds(credentials.NewTLS(tlsCfg)))

	policypb.RegisterPolicyCheckServer(grpcServer, &server{
		rm:      rm,
		rl:      pni.NewRateLimiter(),
		qs:      qs,
		maxSkew: skew,
	})

	fmt.Println("policy-svc started", "addr=", addr, "registry=", regPath, "quarantine_mode=", qMode)
	if err := grpcServer.Serve(lis); err != nil {
		panic(err)
	}
}
