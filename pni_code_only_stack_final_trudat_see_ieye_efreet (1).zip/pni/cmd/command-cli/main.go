package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"

	"pni/internal/pni"
)

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func main() {
	var (
		target  = flag.String("device", "dre-001", "target device id")
		cmdName = flag.String("cmd", "set_publish_interval_ms", "command name")
		params  = flag.String("params", `{"value":1000}`, "json object params")
		issuer  = flag.String("issuer", "hub", "issuer label")
	)
	flag.Parse()

	broker := getenv("MQTT_BROKER", "ssl://127.0.0.1:8883")
	topic := getenv("COMMAND_TOPIC", fmt.Sprintf("pni/commands/%s", *target))

	// MQTT mTLS (hub client cert for broker auth)
	tlsCfg, err := pni.LoadTLSConfig(
		getenv("MQTT_TLS_CA", "./certs/ca/ca.crt"),
		getenv("MQTT_TLS_CERT", "./certs/clients/hub.crt"),
		getenv("MQTT_TLS_KEY", "./certs/clients/hub.key"),
		getenv("MQTT_TLS_SERVER_NAME", "localhost"),
	)
	if err != nil {
		panic(err)
	}

	seedHex := os.Getenv("ISSUER_SEED_HEX") // set for deterministic pubkey across runs
	id, err := pni.NewIdentity(*issuer, seedHex)
	if err != nil {
		panic(err)
	}

	var p map[string]any
	if err := json.Unmarshal([]byte(*params), &p); err != nil {
		panic("bad -params JSON")
	}

	unsigned := pni.CommandUnsigned{
		TargetDeviceID: *target,
		TsUnixMs:       time.Now().UnixMilli(),
		CommandID:      fmt.Sprintf("%s-%d", *target, time.Now().UnixNano()),
		Command:        *cmdName,
		Params:         p,
		Issuer:         *issuer,
		Schema:         "pni.command.v1",
	}

	payload, err := json.Marshal(unsigned)
	if err != nil {
		panic(err)
	}

	sig := pni.Sign(id.Priv, payload)

	env := pni.CommandEnvelope{
		TargetDeviceID:  *target,
		Payload:         json.RawMessage(payload),
		IssuerPubKeyB64: pni.B64(id.Pub),
		SignatureB64:    pni.B64(sig),
		SchemaVersion:   "1",
	}

	msg, err := json.Marshal(env)
	if err != nil {
		panic(err)
	}

	opts := mqtt.NewClientOptions().
		AddBroker(broker).
		SetClientID("command-cli-" + *issuer).
		SetTLSConfig(tlsCfg).
		SetAutoReconnect(true)

	client := mqtt.NewClient(opts)
	if tok := client.Connect(); tok.Wait() && tok.Error() != nil {
		panic(tok.Error())
	}
	defer client.Disconnect(250)

	if tok := client.Publish(topic, 1, false, msg); tok.Wait() && tok.Error() != nil {
		panic(tok.Error())
	}

	fmt.Println("sent command to", topic)
	fmt.Println("issuer_pubkey_b64 =", pni.B64(id.Pub))
}
