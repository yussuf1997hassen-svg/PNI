package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	mrand "math/rand"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"

	"google.golang.org/grpc"
	"google.golang.org/grpc/backoff"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/keepalive"
	"google.golang.org/grpc/status"

	"pni/internal/pni"
	policypb "pni/proto/policy"
)

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func clamp01(x float64) float64 {
	if x < 0 {
		return 0
	}
	if x > 1 {
		return 1
	}
	return x
}

func simulateSensors(r *mrand.Rand) (acoustic, vib, emi float64) {
	gaussish := func(mu, sigma float64) float64 {
		s := 0.0
		for i := 0; i < 6; i++ {
			s += r.Float64()
		}
		z := (s - 3.0)
		return math.Abs(mu + sigma*z)
	}
	acoustic = gaussish(0.5, 0.12)
	vib = gaussish(0.3, 0.10)
	emi = gaussish(0.2, 0.08)
	return
}

func anomalyScore(acoustic, vib, emi float64) float64 {
	return clamp01((acoustic*0.9 + vib*0.7 + emi*0.8) / 2.0)
}

type runtimePolicy struct {
	commandTopics   []string
	allowedSigners  map[string]bool
	maxSkewMs       int64
	replayTTLms     int64
	registryVersion int64
}

type policyStore struct {
	mu          sync.RWMutex
	topics      map[string]bool
	allowed     map[string]bool
	maxSkewMs   int64
	replayTTLms int64
	replay      *pni.ReplayCache
	regVer      int64
}

func newPolicyStore() *policyStore {
	return &policyStore{
		topics:      map[string]bool{},
		allowed:     map[string]bool{},
		maxSkewMs:   600_000,
		replayTTLms: 600_000,
		replay:      pni.NewReplayCache(10 * time.Minute),
	}
}

func (ps *policyStore) update(rp *runtimePolicy) {
	ps.mu.Lock()
	defer ps.mu.Unlock()
	ps.allowed = rp.allowedSigners
	ps.maxSkewMs = rp.maxSkewMs
	ps.replayTTLms = rp.replayTTLms
	ps.replay = pni.NewReplayCache(time.Duration(rp.replayTTLms) * time.Millisecond)
	ps.regVer = rp.registryVersion
}

func (ps *policyStore) signerAllowed(pubB64 string) bool {
	ps.mu.RLock()
	defer ps.mu.RUnlock()
	return ps.allowed[pubB64]
}

func (ps *policyStore) getTiming() (maxSkewMs int64, replay *pni.ReplayCache) {
	ps.mu.RLock()
	defer ps.mu.RUnlock()
	return ps.maxSkewMs, ps.replay
}

func topicsToSet(topics []string) map[string]bool {
	out := map[string]bool{}
	for _, t := range topics {
		t = strings.TrimSpace(t)
		if t != "" {
			out[t] = true
		}
	}
	return out
}

func reconcileSubscriptions(client mqtt.Client, ps *policyStore, newTopics []string, handler mqtt.MessageHandler) {
	newSet := topicsToSet(newTopics)

	ps.mu.Lock()
	defer ps.mu.Unlock()

	for old := range ps.topics {
		if !newSet[old] {
			if tok := client.Unsubscribe(old); tok.Wait() && tok.Error() != nil {
				fmt.Println("unsubscribe error:", old, tok.Error())
			} else {
				fmt.Println("unsubscribed:", old)
			}
		}
	}

	for t := range newSet {
		if !ps.topics[t] {
			if tok := client.Subscribe(t, 1, handler); tok.Wait() && tok.Error() != nil {
				fmt.Println("subscribe error:", t, tok.Error())
			} else {
				fmt.Println("subscribed:", t)
			}
		}
	}

	ps.topics = newSet
}

func jitterDuration(base time.Duration, jitterPct float64, r *mrand.Rand) time.Duration {
	if base <= 0 {
		return 0
	}
	if jitterPct <= 0 {
		return base
	}
	j := (r.Float64()*2 - 1) * jitterPct
	d := float64(base) * (1 + j)
	if d < float64(250*time.Millisecond) {
		d = float64(250 * time.Millisecond)
	}
	return time.Duration(d)
}

func backoffDuration(base, max time.Duration, failures int) time.Duration {
	if failures <= 0 {
		return base
	}
	if failures > 10 {
		failures = 10
	}
	mult := 1 << failures
	d := time.Duration(int64(base) * int64(mult))
	if d > max {
		return max
	}
	if d < base {
		return base
	}
	return d
}

// Persistent policy gRPC client
type policyRPC struct {
	mu     sync.Mutex
	addr   string
	tlsCfg *credentials.TransportCredentials

	conn   *grpc.ClientConn
	client policypb.PolicyCheckClient
}

func newPolicyRPC(addr string, tlsCfg credentials.TransportCredentials) *policyRPC {
	return &policyRPC{addr: addr, tlsCfg: &tlsCfg}
}

func (p *policyRPC) Close() {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.conn != nil {
		_ = p.conn.Close()
		p.conn = nil
		p.client = nil
	}
}

func (p *policyRPC) ensureClient(ctx context.Context) (policypb.PolicyCheckClient, error) {
	p.mu.Lock()
	defer p.mu.Unlock()

	if p.client != nil {
		return p.client, nil
	}

	cp := grpc.ConnectParams{
		Backoff: backoff.Config{
			BaseDelay:  1 * time.Second,
			Multiplier: 1.6,
			Jitter:     0.2,
			MaxDelay:   20 * time.Second,
		},
		MinConnectTimeout: 5 * time.Second,
	}

	kp := keepalive.ClientParameters{
		Time:                30 * time.Second,
		Timeout:             10 * time.Second,
		PermitWithoutStream: true,
	}

	conn, err := grpc.DialContext(
		ctx,
		p.addr,
		grpc.WithTransportCredentials(*p.tlsCfg),
		grpc.WithConnectParams(cp),
		grpc.WithKeepaliveParams(kp),
		grpc.WithBlock(),
		grpc.WithDefaultCallOptions(grpc.CallContentSubtype("json")),
	)
	if err != nil {
		return nil, err
	}

	p.conn = conn
	p.client = policypb.NewPolicyCheckClient(conn)
	return p.client, nil
}

func isTransportish(err error) bool {
	st, ok := status.FromError(err)
	if !ok {
		return true
	}
	switch st.Code() {
	case codes.Unavailable, codes.DeadlineExceeded, codes.ResourceExhausted:
		return true
	default:
		return false
	}
}

func main() {
	deviceID := getenv("DEVICE_ID", "dre-001")
	seedHex := os.Getenv("DEVICE_SEED_HEX")
	broker := getenv("MQTT_BROKER", "ssl://127.0.0.1:8883")
	modelVer := getenv("MODEL_VER", "sim-v1")
	intervalMs, _ := strconv.Atoi(getenv("PUBLISH_INTERVAL_MS", "1000"))

	var runtimeMu sync.RWMutex

	id, err := pni.NewIdentity(deviceID, seedHex)
	if err != nil {
		panic(err)
	}

	// MQTT mTLS defaults
	mqttCA := getenv("MQTT_TLS_CA", "./certs/ca/ca.crt")
	mqttCert := getenv("MQTT_TLS_CERT", fmt.Sprintf("./certs/clients/%s.crt", deviceID))
	mqttKey := getenv("MQTT_TLS_KEY", fmt.Sprintf("./certs/clients/%s.key", deviceID))
	mqttServerName := getenv("MQTT_TLS_SERVER_NAME", "localhost")

	tlsCfg, err := pni.LoadTLSConfig(mqttCA, mqttCert, mqttKey, mqttServerName)
	if err != nil {
		panic(err)
	}

	topic := getenv("MQTT_TOPIC", fmt.Sprintf("pni/telemetry/%s", deviceID))

	opts := mqtt.NewClientOptions().
		AddBroker(broker).
		SetClientID("edge-" + deviceID).
		SetAutoReconnect(true).
		SetTLSConfig(tlsCfg)

	clientMqtt := mqtt.NewClient(opts)
	if token := clientMqtt.Connect(); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	defer clientMqtt.Disconnect(250)

	fmt.Println("edge-agent started",
		"device_id=", deviceID,
		"broker=", broker,
		"topic=", topic,
	)

	ps := newPolicyStore()

	// Command handler uses latest policyStore (signer set, timing, replay)
	commandHandler := func(_ mqtt.Client, msg mqtt.Message) {
		var env pni.CommandEnvelope
		if err := json.Unmarshal(msg.Payload(), &env); err != nil {
			fmt.Println("CMD bad envelope:", err)
			return
		}
		if env.TargetDeviceID != deviceID {
			fmt.Println("CMD deny target mismatch", env.TargetDeviceID)
			return
		}
		if env.SchemaVersion != "1" {
			fmt.Println("CMD deny bad schema_version", env.SchemaVersion)
			return
		}
		if !ps.signerAllowed(env.IssuerPubKeyB64) {
			fmt.Println("CMD deny signer not allowed")
			return
		}

		pub, err := pni.FromB64(env.IssuerPubKeyB64)
		if err != nil {
			fmt.Println("CMD bad pubkey:", err)
			return
		}
		sig, err := pni.FromB64(env.SignatureB64)
		if err != nil {
			fmt.Println("CMD bad sig:", err)
			return
		}
		if !pni.Verify(pub, []byte(env.Payload), sig) {
			fmt.Println("CMD deny signature fail")
			return
		}

		var cmd pni.CommandUnsigned
		if err := json.Unmarshal(env.Payload, &cmd); err != nil {
			fmt.Println("CMD bad payload:", err)
			return
		}
		if cmd.TargetDeviceID != deviceID {
			fmt.Println("CMD deny payload target mismatch")
			return
		}

		maxSkewMs, replay := ps.getTiming()

		nowMs := time.Now().UnixMilli()
		if replay.Seen(cmd.CommandID, nowMs) {
			fmt.Println("CMD deny replay", cmd.CommandID)
			return
		}
		if cmd.TsUnixMs != 0 {
			skew := nowMs - cmd.TsUnixMs
			if skew < 0 {
				skew = -skew
			}
			if skew > maxSkewMs {
				fmt.Println("CMD quarantine skew too large", skew)
				return
			}
		}

		switch cmd.Command {
		case "set_publish_interval_ms":
			v, ok := cmd.Params["value"]
			if !ok {
				fmt.Println("CMD missing value")
				return
			}
			ms, ok := v.(float64)
			if !ok || ms < 100 || ms > 60000 {
				fmt.Println("CMD invalid interval")
				return
			}
			runtimeMu.Lock()
			intervalMs = int(ms)
			runtimeMu.Unlock()
			fmt.Println("CMD applied publish interval:", int(ms))

		case "set_model_ver":
			v, ok := cmd.Params["value"]
			if !ok {
				fmt.Println("CMD missing value")
				return
			}
			sv, ok := v.(string)
			if !ok || sv == "" {
				fmt.Println("CMD invalid model_ver")
				return
			}
			runtimeMu.Lock()
			modelVer = sv
			runtimeMu.Unlock()
			fmt.Println("CMD applied model ver:", sv)

		default:
			fmt.Println("CMD unknown:", cmd.Command, cmd.Params)
		}
	}

	// policy-svc gRPC mTLS client (CN must match deviceID)
	policyAddr := getenv("POLICY_ADDR", "127.0.0.1:9443")
	policyServerName := getenv("POLICY_TLS_SERVER_NAME", "localhost")
	policyCA := getenv("POLICY_TLS_CA", "./certs/ca/ca.crt")
	policyCert := getenv("POLICY_TLS_CERT", fmt.Sprintf("./certs/clients/%s.crt", deviceID))
	policyKey := getenv("POLICY_TLS_KEY", fmt.Sprintf("./certs/clients/%s.key", deviceID))

	grpcTLSCfg, err := pni.LoadMTLSClientConfig(policyCA, policyCert, policyKey, policyServerName)
	if err != nil {
		panic(err)
	}
	prpc := newPolicyRPC(policyAddr, credentials.NewTLS(grpcTLSCfg))
	defer prpc.Close()

	policyMode := strings.ToLower(getenv("POLICY_MODE", "watch"))
	if policyMode != "watch" && policyMode != "poll" && policyMode != "both" {
		fmt.Println("invalid POLICY_MODE, defaulting to watch:", policyMode)
		policyMode = "watch"
	}
	fmt.Println("policy mode:", policyMode)

	applyRuntimePolicy := func(resp *policypb.GetDeviceRuntimePolicyResponse) {
		if resp == nil {
			return
		}
		if !resp.Allow {
			fmt.Println("policy deny:", resp.Reason)
			reconcileSubscriptions(clientMqtt, ps, nil, commandHandler)
			return
		}

		allowed := map[string]bool{}
		for _, s := range resp.AllowedCommandSignersB64 {
			s = strings.TrimSpace(s)
			if s != "" {
				allowed[s] = true
			}
		}

		rp := &runtimePolicy{
			commandTopics:   resp.CommandTopics,
			allowedSigners:  allowed,
			maxSkewMs:       resp.CommandMaxSkewMs,
			replayTTLms:     resp.ReplayTtlMs,
			registryVersion: resp.RegistryVersion,
		}

		ps.update(rp)
		reconcileSubscriptions(clientMqtt, ps, rp.commandTopics, commandHandler)

		fmt.Println("policy applied",
			"registry_version=", rp.registryVersion,
			"topics=", len(rp.commandTopics),
			"signers=", len(rp.allowedSigners),
		)
	}

	startPolicyPoll := func() {
		refreshSec, _ := strconv.Atoi(getenv("POLICY_REFRESH_SEC", "30"))
		if refreshSec < 5 {
			refreshSec = 5
		}
		maxBackoffSec, _ := strconv.Atoi(getenv("POLICY_BACKOFF_MAX_SEC", "300"))
		if maxBackoffSec < refreshSec {
			maxBackoffSec = refreshSec
		}
		jitterPct, _ := strconv.ParseFloat(getenv("POLICY_JITTER_PCT", "0.20"), 64)
		if jitterPct < 0 {
			jitterPct = 0
		}
		if jitterPct > 0.80 {
			jitterPct = 0.80
		}

		baseDelay := time.Duration(refreshSec) * time.Second
		maxDelay := time.Duration(maxBackoffSec) * time.Second

		go func() {
			r := mrand.New(mrand.NewSource(time.Now().UnixNano()))
			failures := 0
			delay := baseDelay

			for {
				time.Sleep(jitterDuration(delay, jitterPct, r))

				ctx, cancel := context.WithTimeout(context.Background(), 900*time.Millisecond)
				client, err := prpc.ensureClient(ctx)
				cancel()
				if err != nil {
					failures++
					delay = backoffDuration(baseDelay, maxDelay, failures)
					fmt.Println("policy poll dial failed", "failures=", failures, "next=", delay, "err=", err)
					continue
				}

				ctx2, cancel2 := context.WithTimeout(context.Background(), 900*time.Millisecond)
				resp, err := client.GetDeviceRuntimePolicy(ctx2, &policypb.GetDeviceRuntimePolicyRequest{DeviceId: deviceID})
				cancel2()
				if err != nil {
					if isTransportish(err) {
						prpc.Close()
					}
					failures++
					delay = backoffDuration(baseDelay, maxDelay, failures)
					fmt.Println("policy poll failed", "failures=", failures, "next=", delay, "err=", err)
					continue
				}

				failures = 0
				delay = baseDelay
				applyRuntimePolicy(resp)
			}
		}()
	}

	startPolicyWatch := func() {
		go func() {
			r := mrand.New(mrand.NewSource(time.Now().UnixNano()))
			failures := 0

			baseDelay := 2 * time.Second
			maxDelay := 2 * time.Minute
			jitterPct := 0.20

			for {
				if failures > 0 {
					d := backoffDuration(baseDelay, maxDelay, failures)
					time.Sleep(jitterDuration(d, jitterPct, r))
				}

				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				client, err := prpc.ensureClient(ctx)
				cancel()
				if err != nil {
					failures++
					fmt.Println("policy watch dial failed", "failures=", failures, "err=", err)
					continue
				}

				stream, err := client.WatchDeviceRuntimePolicy(context.Background(),
					&policypb.GetDeviceRuntimePolicyRequest{DeviceId: deviceID},
				)
				if err != nil {
					if isTransportish(err) {
						prpc.Close()
					}
					failures++
					fmt.Println("policy watch start failed", "failures=", failures, "err=", err)
					continue
				}

				fmt.Println("policy watch connected")
				failures = 0

				for {
					resp, err := stream.Recv()
					if err != nil {
						if isTransportish(err) {
							prpc.Close()
						}
						failures++
						fmt.Println("policy watch recv failed", "failures=", failures, "err=", err)
						break
					}
					applyRuntimePolicy(resp)
				}
			}
		}()
	}

	switch policyMode {
	case "watch":
		startPolicyWatch()
	case "poll":
		startPolicyPoll()
	case "both":
		startPolicyWatch()
		startPolicyPoll()
	}

	r := mrand.New(mrand.NewSource(time.Now().UnixNano()))

	for {
		ac, vb, em := simulateSensors(r)

		runtimeMu.RLock()
		curModelVer := modelVer
		curInterval := intervalMs
		runtimeMu.RUnlock()

		score := anomalyScore(ac, vb, em)
		eventType := "normal"
		if score > 0.75 {
			eventType = "anomaly"
		}

		unsigned := pni.TelemetryUnsigned{
			DeviceID:     deviceID,
			TsUnixMs:     time.Now().UnixMilli(),
			AcousticRMS:  ac,
			VibrationRMS: vb,
			EMIPower:     em,
			AnomalyScore: score,
			EventType:    eventType,
			ModelVer:     curModelVer,
		}

		payloadBytes, err := json.Marshal(unsigned)
		if err != nil {
			fmt.Println("marshal unsigned err:", err)
			time.Sleep(time.Duration(curInterval) * time.Millisecond)
			continue
		}

		sig := pni.Sign(id.Priv, payloadBytes)

		env := pni.Envelope{
			DeviceID:      deviceID,
			Payload:       json.RawMessage(payloadBytes),
			PubKeyB64:     pni.B64(id.Pub),
			SignatureB64:  pni.B64(sig),
			ContentType:   "pni.telemetry.v1",
			SchemaVersion: "1",
		}

		msgBytes, err := json.Marshal(env)
		if err != nil {
			fmt.Println("marshal envelope err:", err)
			time.Sleep(time.Duration(curInterval) * time.Millisecond)
			continue
		}

		token := clientMqtt.Publish(topic, 1, false, msgBytes)
		token.Wait()
		if token.Error() != nil {
			fmt.Println("publish err:", token.Error())
		}

		time.Sleep(time.Duration(curInterval) * time.Millisecond)
	}
}
