module pni

go 1.22

require (
	github.com/eclipse/paho.mqtt.golang v1.5.0
	google.golang.org/grpc v1.66.0
)
