package pni

import (
	"context"
	"errors"

	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/peer"
)

func PeerCommonNameFromContext(ctx context.Context) (string, error) {
	p, ok := peer.FromContext(ctx)
	if !ok {
		return "", errors.New("no peer in context")
	}
	ti, ok := p.AuthInfo.(credentials.TLSInfo)
	if !ok {
		return "", errors.New("no TLS auth info")
	}
	if len(ti.State.PeerCertificates) == 0 {
		return "", errors.New("no peer certificates")
	}
	cn := ti.State.PeerCertificates[0].Subject.CommonName
	if cn == "" {
		return "", errors.New("peer cert CN empty")
	}
	return cn, nil
}
