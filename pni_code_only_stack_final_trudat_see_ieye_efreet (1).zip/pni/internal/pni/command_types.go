package pni

import "encoding/json"

type CommandUnsigned struct {
	TargetDeviceID string         `json:"target_device_id"`
	TsUnixMs       int64          `json:"ts_unix_ms"`
	CommandID      string         `json:"command_id"`
	Command        string         `json:"command"`
	Params         map[string]any `json:"params,omitempty"`
	Issuer         string         `json:"issuer"`
	Schema         string         `json:"schema"` // pni.command.v1
}

type CommandEnvelope struct {
	TargetDeviceID  string          `json:"target_device_id"`
	Payload         json.RawMessage `json:"payload"`
	IssuerPubKeyB64 string          `json:"issuer_pubkey_b64"`
	SignatureB64    string          `json:"signature_b64"`
	SchemaVersion   string          `json:"schema_version"` // "1"
}
