package pni

import (
	"bufio"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

type QuarantineRecord struct {
	DeviceID       string `json:"device_id"`
	Topic          string `json:"topic"`
	Reason         string `json:"reason"`
	Action         string `json:"action"`
	ReceivedUnixMs int64  `json:"received_unix_ms"`
	PolicyVersion  int64  `json:"policy_version"`

	ContentType   string `json:"content_type,omitempty"`
	SchemaVersion string `json:"schema_version,omitempty"`
	PayloadSize   int    `json:"payload_size,omitempty"`
}

type QuarantineSink struct {
	Mode string // mqtt|file|both|off

	mqttClient    mqtt.Client
	mqttBaseTopic string

	mu   sync.Mutex
	file *os.File
	w    *bufio.Writer
}

func NewQuarantineSink(mode string) *QuarantineSink { return &QuarantineSink{Mode: mode} }

func (qs *QuarantineSink) InitFile(path string) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	qs.file = f
	qs.w = bufio.NewWriterSize(f, 64*1024)
	return nil
}

func (qs *QuarantineSink) InitMQTT(broker, clientID, baseTopic string, tlsCfg *tls.Config) error {
	opts := mqtt.NewClientOptions().
		AddBroker(broker).
		SetClientID(clientID).
		SetAutoReconnect(true).
		SetConnectRetry(true).
		SetConnectRetryInterval(2 * time.Second)

	if tlsCfg != nil {
		opts.SetTLSConfig(tlsCfg)
	}

	qs.mqttBaseTopic = baseTopic
	qs.mqttClient = mqtt.NewClient(opts)
	tok := qs.mqttClient.Connect()
	tok.Wait()
	return tok.Error()
}

func (qs *QuarantineSink) Close() {
	if qs.w != nil {
		qs.mu.Lock()
		_ = qs.w.Flush()
		qs.mu.Unlock()
	}
	if qs.file != nil {
		_ = qs.file.Close()
	}
	if qs.mqttClient != nil && qs.mqttClient.IsConnected() {
		qs.mqttClient.Disconnect(250)
	}
}

func (qs *QuarantineSink) Emit(rec QuarantineRecord) {
	if qs.Mode == "off" || qs.Mode == "" {
		return
	}
	b, _ := json.Marshal(rec)

	if qs.Mode == "file" || qs.Mode == "both" {
		if qs.w != nil {
			qs.mu.Lock()
			_, _ = qs.w.Write(b)
			_, _ = qs.w.WriteString("\n")
			_ = qs.w.Flush()
			qs.mu.Unlock()
		}
	}

	if qs.Mode == "mqtt" || qs.Mode == "both" {
		if qs.mqttClient != nil && qs.mqttClient.IsConnected() {
			topic := fmt.Sprintf("%s/%s", qs.mqttBaseTopic, rec.DeviceID)
			qs.mqttClient.Publish(topic, 1, false, b).Wait()
		}
	}
}
