package pni

import (
	"encoding/json"
	"fmt"
	"os"
	"sync/atomic"
	"time"
)

type DevicePolicy struct {
	AllowTopics        []string `json:"allow_topics,omitempty"`
	AllowTopicPatterns []string `json:"allow_topic_patterns,omitempty"`

	MaxMsgsPerMin  int      `json:"max_msgs_per_min"`
	AllowModelVers []string `json:"allow_model_versions,omitempty"`

	CommandTopicPatterns     []string `json:"command_topic_patterns,omitempty"`
	AllowedCommandSignersB64 []string `json:"allowed_command_signers_b64,omitempty"`

	CommandMaxSkewSec int `json:"command_max_skew_sec,omitempty"`
	ReplayTTLSec      int `json:"replay_ttl_sec,omitempty"`
}

type Registry struct {
	Version int64                   `json:"version"`
	Devices map[string]DevicePolicy `json:"devices"`
}

type RegistryManager struct {
	path      string
	pollEvery time.Duration
	lastMod   atomic.Int64
	current   atomic.Pointer[Registry]
}

func NewRegistryManager(path string, pollEvery time.Duration) *RegistryManager {
	return &RegistryManager{path: path, pollEvery: pollEvery}
}

func (rm *RegistryManager) LoadOnce() error {
	r, modUnix, err := loadRegistryFile(rm.path)
	if err != nil {
		return err
	}
	rm.current.Store(r)
	rm.lastMod.Store(modUnix)
	return nil
}

func (rm *RegistryManager) StartAutoReload(logf func(string, ...any)) {
	go func() {
		t := time.NewTicker(rm.pollEvery)
		defer t.Stop()

		for range t.C {
			r, modUnix, err := loadRegistryFile(rm.path)
			if err != nil {
				logf("registry reload failed: %v", err)
				continue
			}
			if modUnix == rm.lastMod.Load() {
				continue
			}
			rm.current.Store(r)
			rm.lastMod.Store(modUnix)
			logf("registry reloaded: version=%d", r.Version)
		}
	}()
}

func (rm *RegistryManager) Get() (*Registry, bool) {
	r := rm.current.Load()
	return r, r != nil
}

func loadRegistryFile(path string) (*Registry, int64, error) {
	st, err := os.Stat(path)
	if err != nil {
		return nil, 0, fmt.Errorf("stat registry: %w", err)
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, 0, fmt.Errorf("read registry: %w", err)
	}
	var r Registry
	if err := json.Unmarshal(b, &r); err != nil {
		return nil, 0, fmt.Errorf("decode registry: %w", err)
	}
	if r.Devices == nil {
		r.Devices = map[string]DevicePolicy{}
	}
	return &r, st.ModTime().Unix(), nil
}
