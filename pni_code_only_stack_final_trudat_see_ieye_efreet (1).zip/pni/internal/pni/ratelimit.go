package pni

import (
	"sync"
	"time"
)

type deviceWindow struct {
	windowStart time.Time
	count       int
}

type RateLimiter struct {
	mu sync.Mutex
	m  map[string]*deviceWindow
}

func NewRateLimiter() *RateLimiter { return &RateLimiter{m: make(map[string]*deviceWindow)} }

// AllowNPerMinute returns whether allowed and current count.
func (rl *RateLimiter) AllowNPerMinute(deviceID string, maxPerMin int) (bool, int) {
	if maxPerMin <= 0 {
		return false, 0
	}

	now := time.Now()
	rl.mu.Lock()
	defer rl.mu.Unlock()

	w, ok := rl.m[deviceID]
	if !ok {
		w = &deviceWindow{windowStart: now, count: 0}
		rl.m[deviceID] = w
	}

	if now.Sub(w.windowStart) >= time.Minute {
		w.windowStart = now
		w.count = 0
	}

	w.count++
	if w.count > maxPerMin {
		return false, w.count
	}
	return true, w.count
}
