package pni

import "encoding/json"

// TelemetryUnsigned is the payload the edge-agent signs and publishes.
type TelemetryUnsigned struct {
	DeviceID     string  `json:"device_id"`
	TsUnixMs     int64   `json:"ts_unix_ms"`
	AcousticRMS  float64 `json:"acoustic_rms"`
	VibrationRMS float64 `json:"vibration_rms"`
	EMIPower     float64 `json:"emi_power"`
	AnomalyScore float64 `json:"anomaly_score"`
	EventType    string  `json:"event_type"`
	ModelVer     string  `json:"model_ver"`
}

// Envelope wraps telemetry payload with signature and pubkey.
type Envelope struct {
	DeviceID      string          `json:"device_id"`
	Payload       json.RawMessage `json:"payload"`
	PubKeyB64     string          `json:"pubkey_b64"`
	SignatureB64  string          `json:"signature_b64"`
	ContentType   string          `json:"content_type"`
	SchemaVersion string          `json:"schema_version"`
}
