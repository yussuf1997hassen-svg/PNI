package pni

import (
	"sync"
	"time"
)

type ReplayCache struct {
	mu  sync.Mutex
	m   map[string]int64
	ttl time.Duration
}

func NewReplayCache(ttl time.Duration) *ReplayCache {
	return &ReplayCache{m: map[string]int64{}, ttl: ttl}
}

func (rc *ReplayCache) Seen(commandID string, nowMs int64) bool {
	rc.mu.Lock()
	defer rc.mu.Unlock()

	cutoff := nowMs - int64(rc.ttl/time.Millisecond)
	for k, ts := range rc.m {
		if ts < cutoff {
			delete(rc.m, k)
		}
	}

	if _, ok := rc.m[commandID]; ok {
		return true
	}
	rc.m[commandID] = nowMs
	return false
}
