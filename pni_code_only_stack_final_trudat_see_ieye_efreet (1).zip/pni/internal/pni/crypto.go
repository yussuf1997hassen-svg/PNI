package pni

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"errors"
)

type Identity struct {
	DeviceID string
	Priv     ed25519.PrivateKey
	Pub      ed25519.PublicKey
}

// NewIdentity creates an Ed25519 identity.
// If seedHex is set (>= 32 bytes hex), the key is deterministic (useful for sim/dev).
func NewIdentity(deviceID string, seedHex string) (*Identity, error) {
	if deviceID == "" {
		return nil, errors.New("deviceID required")
	}

	var pub ed25519.PublicKey
	var priv ed25519.PrivateKey

	if seedHex != "" {
		seed, err := hex.DecodeString(seedHex)
		if err != nil {
			return nil, err
		}
		if len(seed) < ed25519.SeedSize {
			return nil, errors.New("seedHex must be >= 32 bytes hex")
		}
		priv = ed25519.NewKeyFromSeed(seed[:ed25519.SeedSize])
		pub = priv.Public().(ed25519.PublicKey)
	} else {
		var err error
		pub, priv, err = ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
	}

	return &Identity{DeviceID: deviceID, Priv: priv, Pub: pub}, nil
}

func Sign(priv ed25519.PrivateKey, payload []byte) []byte {
	return ed25519.Sign(priv, payload)
}

func Verify(pub ed25519.PublicKey, payload []byte, sig []byte) bool {
	return ed25519.Verify(pub, payload, sig)
}

func B64(b []byte) string              { return base64.StdEncoding.EncodeToString(b) }
func FromB64(s string) ([]byte, error) { return base64.StdEncoding.DecodeString(s) }
