package pni

import "strings"

// TopicAllowed substitutes %u with deviceID, then matches MQTT filters (+ and #).
func TopicAllowed(deviceID string, topic string, exact []string, patterns []string) bool {
	for _, t := range exact {
		if t == topic {
			return true
		}
	}
	for _, p := range patterns {
		p = strings.ReplaceAll(p, "%u", deviceID)
		if mqttMatch(p, topic) {
			return true
		}
	}
	return false
}

// mqttMatch implements MQTT topic filter matching:
// '+' matches exactly one level, '#' matches remaining levels (must be last token).
func mqttMatch(filter, topic string) bool {
	f := strings.Split(filter, "/")
	t := strings.Split(topic, "/")

	for i := 0; i < len(f); i++ {
		if i >= len(t) {
			return i == len(f)-1 && f[i] == "#"
		}
		switch f[i] {
		case "#":
			return i == len(f)-1
		case "+":
			continue
		default:
			if f[i] != t[i] {
				return false
			}
		}
	}
	return len(t) == len(f)
}
