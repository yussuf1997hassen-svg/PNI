#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "[PNI] docker compose ps"
docker compose ps || true
echo

echo "[PNI] processes"
shopt -s nullglob
for f in run/*.pid; do
  pid="$(cat "$f" || true)"
  name="$(basename "$f")"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" >/dev/null 2>&1; then
    echo "  - $name: RUNNING pid=$pid"
  else
    echo "  - $name: NOT RUNNING (stale pidfile)"
  fi
done
echo

echo "[PNI] latest logs (tail 20)"
shopt -s nullglob
for log in run/logs/*.log; do
  echo "----- $log -----"
  tail -n 20 "$log"
done
