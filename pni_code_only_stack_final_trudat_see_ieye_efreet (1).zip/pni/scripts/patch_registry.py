#!/usr/bin/env python3
import json, sys
from pathlib import Path

if len(sys.argv) < 3:
    print("usage: patch_registry.py <registry.json> <pubkey_b64>")
    sys.exit(1)

path = Path(sys.argv[1])
pub = sys.argv[2].strip()

data = json.loads(path.read_text())
v = int(data.get("version", 0))
data["version"] = v + 1

devices = data.get("devices", {})
for _, dp in devices.items():
    arr = dp.get("allowed_command_signers_b64", [])
    arr = [pub if (isinstance(x, str) and "HUB_COMMAND_PUBKEY_B64_HERE" in x) else x for x in arr]
    dp["allowed_command_signers_b64"] = arr

path.write_text(json.dumps(data, indent=2) + "\n")
print(f"patched {path} version {v} -> {v+1}")
