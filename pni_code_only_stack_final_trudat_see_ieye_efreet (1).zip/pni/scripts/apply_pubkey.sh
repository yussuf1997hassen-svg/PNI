#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PUBKEY_B64="${1:-${PUBKEY_B64:-}}"
if [[ -z "${PUBKEY_B64:-}" ]]; then
  echo "[PNI] ERROR: provide pubkey as arg or env PUBKEY_B64"
  echo "  bash scripts/apply_pubkey.sh <PUBKEY_B64>"
  echo "  or: PUBKEY_B64=<PUBKEY_B64> bash scripts/apply_pubkey.sh"
  exit 1
fi

python3 scripts/patch_registry.py registry.json "$PUBKEY_B64"
echo "[PNI] registry patched. (Edge-agent in POLICY_MODE=watch will refresh automatically.)"
