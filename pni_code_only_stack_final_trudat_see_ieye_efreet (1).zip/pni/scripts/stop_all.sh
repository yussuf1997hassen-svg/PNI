#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

kill_pidfile () {
  local pidfile="$1"
  local name="$2"
  if [[ -f "$pidfile" ]]; then
    local pid
    pid="$(cat "$pidfile" || true)"
    if [[ -n "${pid:-}" ]] && kill -0 "$pid" >/dev/null 2>&1; then
      echo "[PNI] stopping $name (pid=$pid)"
      kill "$pid" || true
      sleep 0.3
      kill -9 "$pid" >/dev/null 2>&1 || true
    fi
    rm -f "$pidfile"
  fi
}

shopt -s nullglob
for f in run/*.pid; do
  kill_pidfile "$f" "$(basename "$f")"
done

echo "[PNI] stopping docker compose"
docker compose down || true
echo "[PNI] stopped."
