#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "[PNI] root: $ROOT"

if ! command -v go >/dev/null 2>&1; then
  echo "[PNI] ERROR: go not found. Install Go then retry:"
  echo "      brew install go"
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "[PNI] ERROR: docker not found. Install Docker Desktop."
  exit 1
fi

if ! docker info >/dev/null 2>&1; then
  echo "[PNI] ERROR: Docker daemon not running. Start Docker Desktop."
  exit 1
fi

mkdir -p run/bin run/logs

echo "[PNI] fetching deps + generating go.sum"
go mod tidy

echo "[PNI] generating certs (if missing)"
if [[ ! -f certs/ca/ca.crt ]]; then
  bash scripts/gen_certs.sh
fi

echo "[PNI] starting mosquitto (docker compose)"
docker compose up -d
docker compose ps

echo "[PNI] building binaries"
go build -o run/bin/policy-svc ./cmd/policy-svc
go build -o run/bin/hub-ingest ./cmd/hub-ingest
go build -o run/bin/edge-agent ./cmd/edge-agent
go build -o run/bin/command-cli ./cmd/command-cli

start_bg () {
  local name="$1"; shift
  local pidfile="run/${name}.pid"
  local logfile="run/logs/${name}.log"

  if [[ -f "$pidfile" ]]; then
    local oldpid
    oldpid="$(cat "$pidfile" || true)"
    if [[ -n "${oldpid:-}" ]] && kill -0 "$oldpid" >/dev/null 2>&1; then
      echo "[PNI] $name already running (pid=$oldpid)."
      return 0
    fi
  fi

  echo "[PNI] starting $name ..."
  nohup "$@" >"$logfile" 2>&1 &
  echo $! > "$pidfile"
  echo "[PNI] $name pid=$(cat "$pidfile") log=$logfile"
}

DEVICE_ID="${DEVICE_ID:-dre-001}"
POLICY_MODE="${POLICY_MODE:-watch}"

start_bg "policy-svc" run/bin/policy-svc
start_bg "hub-ingest" run/bin/hub-ingest
start_bg "edge-agent-${DEVICE_ID}" env DEVICE_ID="$DEVICE_ID" POLICY_MODE="$POLICY_MODE" run/bin/edge-agent

echo
echo "[PNI] done."
echo "  - tail logs: tail -f run/logs/*.log"
echo "  - status:    bash scripts/status.sh"
echo "  - stop:      bash scripts/stop_all.sh"
echo "  - patch pubkey: bash scripts/apply_pubkey.sh <PUBKEY_B64>"
