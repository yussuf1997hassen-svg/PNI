#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PUBKEY_B64="${1:-${PUBKEY_B64:-}}"
if [[ -z "${PUBKEY_B64:-}" ]]; then
  echo "[PNI] Completion requires your issuer pubkey (base64)."
  echo "Run:"
  echo "  bash scripts/complete.sh <PUBKEY_B64>"
  echo "or:"
  echo "  PUBKEY_B64=<PUBKEY_B64> bash scripts/complete.sh"
  exit 1
fi

bash scripts/run_all.sh
bash scripts/apply_pubkey.sh "$PUBKEY_B64"

echo
echo "[PNI] Completed. Now send a command:"
echo "ISSUER_SEED_HEX=0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef \"
echo "  ./run/bin/command-cli -device dre-001 -cmd set_publish_interval_ms -params '{"value":3000}'"
echo
echo "[PNI] Watching logs..."
tail -f run/logs/*.log
