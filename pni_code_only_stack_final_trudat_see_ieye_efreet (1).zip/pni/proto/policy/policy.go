package policy

import (
	"context"

	"google.golang.org/grpc"
)

// Messages (JSON codec)
type CheckRequest struct {
	Topic            string `json:"topic"`
	EnvelopeDeviceID string `json:"envelope_device_id"`
	ContentType      string `json:"content_type"`
	SchemaVersion    string `json:"schema_version"`
	PayloadJSON      []byte `json:"payload_json"`
	PubKey           []byte `json:"pubkey"`
	Signature        []byte `json:"signature"`
	ReceivedUnixMs   int64  `json:"received_unix_ms"`
}
type CheckResponse struct {
	Allow         bool   `json:"allow"`
	Reason        string `json:"reason"`
	Action        string `json:"action"`
	PolicyVersion int64  `json:"policy_version"`
}

type HealthRequest struct{}
type HealthResponse struct {
	Status string `json:"status"`
}

type GetDeviceRuntimePolicyRequest struct {
	DeviceId string `json:"device_id"`
}
type GetDeviceRuntimePolicyResponse struct {
	Allow                    bool     `json:"allow"`
	Reason                   string   `json:"reason"`
	RegistryVersion          int64    `json:"registry_version"`
	CommandTopics            []string `json:"command_topics"`
	AllowedCommandSignersB64 []string `json:"allowed_command_signers_b64"`
	CommandMaxSkewMs         int64    `json:"command_max_skew_ms"`
	ReplayTtlMs              int64    `json:"replay_ttl_ms"`
}

// Client
type PolicyCheckClient interface {
	Check(ctx context.Context, in *CheckRequest, opts ...grpc.CallOption) (*CheckResponse, error)
	Health(ctx context.Context, in *HealthRequest, opts ...grpc.CallOption) (*HealthResponse, error)
	GetDeviceRuntimePolicy(ctx context.Context, in *GetDeviceRuntimePolicyRequest, opts ...grpc.CallOption) (*GetDeviceRuntimePolicyResponse, error)
	WatchDeviceRuntimePolicy(ctx context.Context, in *GetDeviceRuntimePolicyRequest, opts ...grpc.CallOption) (PolicyCheck_WatchDeviceRuntimePolicyClient, error)
}

type policyCheckClient struct{ cc grpc.ClientConnInterface }

func NewPolicyCheckClient(cc grpc.ClientConnInterface) PolicyCheckClient {
	return &policyCheckClient{cc}
}

func (c *policyCheckClient) Check(ctx context.Context, in *CheckRequest, opts ...grpc.CallOption) (*CheckResponse, error) {
	out := new(CheckResponse)
	err := c.cc.Invoke(ctx, "/pni.policy.PolicyCheck/Check", in, out, opts...)
	if err != nil {
		return nil, err
	}
	return out, nil
}
func (c *policyCheckClient) Health(ctx context.Context, in *HealthRequest, opts ...grpc.CallOption) (*HealthResponse, error) {
	out := new(HealthResponse)
	err := c.cc.Invoke(ctx, "/pni.policy.PolicyCheck/Health", in, out, opts...)
	if err != nil {
		return nil, err
	}
	return out, nil
}
func (c *policyCheckClient) GetDeviceRuntimePolicy(ctx context.Context, in *GetDeviceRuntimePolicyRequest, opts ...grpc.CallOption) (*GetDeviceRuntimePolicyResponse, error) {
	out := new(GetDeviceRuntimePolicyResponse)
	err := c.cc.Invoke(ctx, "/pni.policy.PolicyCheck/GetDeviceRuntimePolicy", in, out, opts...)
	if err != nil {
		return nil, err
	}
	return out, nil
}
func (c *policyCheckClient) WatchDeviceRuntimePolicy(ctx context.Context, in *GetDeviceRuntimePolicyRequest, opts ...grpc.CallOption) (PolicyCheck_WatchDeviceRuntimePolicyClient, error) {
	stream, err := c.cc.NewStream(ctx, &PolicyCheck_ServiceDesc.Streams[0], "/pni.policy.PolicyCheck/WatchDeviceRuntimePolicy", opts...)
	if err != nil {
		return nil, err
	}
	x := &policyCheckWatchClient{stream}
	if err := x.ClientStream.SendMsg(in); err != nil {
		return nil, err
	}
	if err := x.ClientStream.CloseSend(); err != nil {
		return nil, err
	}
	return x, nil
}

type PolicyCheck_WatchDeviceRuntimePolicyClient interface {
	Recv() (*GetDeviceRuntimePolicyResponse, error)
	grpc.ClientStream
}
type policyCheckWatchClient struct{ grpc.ClientStream }

func (x *policyCheckWatchClient) Recv() (*GetDeviceRuntimePolicyResponse, error) {
	m := new(GetDeviceRuntimePolicyResponse)
	if err := x.ClientStream.RecvMsg(m); err != nil {
		return nil, err
	}
	return m, nil
}

// Server
type PolicyCheckServer interface {
	Check(context.Context, *CheckRequest) (*CheckResponse, error)
	Health(context.Context, *HealthRequest) (*HealthResponse, error)
	GetDeviceRuntimePolicy(context.Context, *GetDeviceRuntimePolicyRequest) (*GetDeviceRuntimePolicyResponse, error)
	WatchDeviceRuntimePolicy(*GetDeviceRuntimePolicyRequest, PolicyCheck_WatchDeviceRuntimePolicyServer) error
}

type UnimplementedPolicyCheckServer struct{}

func (UnimplementedPolicyCheckServer) Check(context.Context, *CheckRequest) (*CheckResponse, error) {
	return nil, grpc.ErrServerStopped
}
func (UnimplementedPolicyCheckServer) Health(context.Context, *HealthRequest) (*HealthResponse, error) {
	return nil, grpc.ErrServerStopped
}
func (UnimplementedPolicyCheckServer) GetDeviceRuntimePolicy(context.Context, *GetDeviceRuntimePolicyRequest) (*GetDeviceRuntimePolicyResponse, error) {
	return nil, grpc.ErrServerStopped
}
func (UnimplementedPolicyCheckServer) WatchDeviceRuntimePolicy(*GetDeviceRuntimePolicyRequest, PolicyCheck_WatchDeviceRuntimePolicyServer) error {
	return grpc.ErrServerStopped
}

func RegisterPolicyCheckServer(s *grpc.Server, srv PolicyCheckServer) {
	s.RegisterService(&PolicyCheck_ServiceDesc, srv)
}

type PolicyCheck_WatchDeviceRuntimePolicyServer interface {
	Send(*GetDeviceRuntimePolicyResponse) error
	grpc.ServerStream
}

type policyCheckWatchServer struct{ grpc.ServerStream }

func (x *policyCheckWatchServer) Send(m *GetDeviceRuntimePolicyResponse) error {
	return x.ServerStream.SendMsg(m)
}

func _PolicyCheck_Check_Handler(srv any, ctx context.Context, dec func(any) error, _ grpc.UnaryServerInterceptor) (any, error) {
	in := new(CheckRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	return srv.(PolicyCheckServer).Check(ctx, in)
}
func _PolicyCheck_Health_Handler(srv any, ctx context.Context, dec func(any) error, _ grpc.UnaryServerInterceptor) (any, error) {
	in := new(HealthRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	return srv.(PolicyCheckServer).Health(ctx, in)
}
func _PolicyCheck_GetDeviceRuntimePolicy_Handler(srv any, ctx context.Context, dec func(any) error, _ grpc.UnaryServerInterceptor) (any, error) {
	in := new(GetDeviceRuntimePolicyRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	return srv.(PolicyCheckServer).GetDeviceRuntimePolicy(ctx, in)
}

func _PolicyCheck_WatchDeviceRuntimePolicy_Handler(srv any, stream grpc.ServerStream) error {
	m := new(GetDeviceRuntimePolicyRequest)
	if err := stream.RecvMsg(m); err != nil {
		return err
	}
	return srv.(PolicyCheckServer).WatchDeviceRuntimePolicy(m, &policyCheckWatchServer{stream})
}

var PolicyCheck_ServiceDesc = grpc.ServiceDesc{
	ServiceName: "pni.policy.PolicyCheck",
	HandlerType: (*PolicyCheckServer)(nil),
	Methods: []grpc.MethodDesc{
		{MethodName: "Check", Handler: _PolicyCheck_Check_Handler},
		{MethodName: "Health", Handler: _PolicyCheck_Health_Handler},
		{MethodName: "GetDeviceRuntimePolicy", Handler: _PolicyCheck_GetDeviceRuntimePolicy_Handler},
	},
	Streams: []grpc.StreamDesc{
		{
			StreamName:    "WatchDeviceRuntimePolicy",
			Handler:       _PolicyCheck_WatchDeviceRuntimePolicy_Handler,
			ServerStreams: true,
		},
	},
	Metadata: "policy.proto",
}
