# PNI (Code-Only) — DRE Node + Network Digital Twin (Go)

This repo implements your two diagrams **purely as software**:
- **edge-agent** (node): sim sensors → features → anomaly score → signed telemetry → MQTT publish; and subscribes to signed commands.
- **hub-ingest** (hub): MQTT subscribe → verify → call policy-svc → accept/drop/quarantine.
- **policy-svc**: mTLS gRPC (JSON codec) policy engine with:
  - registry.json hot-reload
  - wildcard/pattern topic rules (supports `%u`, `+`, `#`)
  - per-device command topics and trusted command signers
  - QUARANTINE sink (file and/or MQTT)
  - device bootstrapping + **watch** streaming updates
  - `POLICY_MODE=watch|poll|both` on edge-agent

> Note: This uses real gRPC transport but a **JSON codec** (no `protoc` needed).

---

## 0) Prereqs
- Go (>= 1.22)
- Docker (for Mosquitto)
- OpenSSL (to generate TLS certs)

---

## 1) Generate TLS certs
```bash
bash scripts/gen_certs.sh
```

This creates:
- CA: `certs/ca/ca.crt`
- Mosquitto server cert: `certs/mosquitto/server.crt`
- Client certs: `certs/clients/dre-001.crt` etc
- Policy service server/client cert: `certs/policy/policy.crt` (CN=policy-svc)

---

## 2) Start Mosquitto (mTLS)
```bash
docker compose up -d
```

Mosquitto listens on **8883** (TLS + client cert required).

---

## 3) Put your command signer pubkey into registry.json
The devices will only accept commands signed by trusted Ed25519 pubkeys.

Generate a stable command signer pubkey (hub issuer) once:
```bash
export ISSUER_SEED_HEX=0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
go run ./cmd/command-cli -device dre-001 -cmd set_publish_interval_ms -params '{"value":1500}'
```

Copy the printed `issuer_pubkey_b64` into `registry.json` under:
`allowed_command_signers_b64`.

---

## 4) Run policy-svc
```bash
go run ./cmd/policy-svc
```

Defaults:
- gRPC mTLS addr: `127.0.0.1:9443`
- Registry path: `./registry.json`
- Quarantine: `file` → `./quarantine.log.jsonl`

---

## 5) Run hub-ingest
```bash
go run ./cmd/hub-ingest
```

Hub subscribes to `pni/telemetry/#`, verifies signatures, then asks policy-svc to accept/drop/quarantine.

---

## 6) Run a node (edge-agent)
```bash
export DEVICE_ID=dre-001
export POLICY_MODE=watch   # watch|poll|both
go run ./cmd/edge-agent
```

The node:
- publishes telemetry to `pni/telemetry/dre-001`
- bootstraps runtime policy from policy-svc (mTLS CN must match device_id)
- subscribes to command topics returned by policy-svc

---

## 7) Edit registry.json live (hot reload)
Change `registry.json` (and bump `"version": N`) while running.
- policy-svc hot reloads it
- edge-agent receives streamed updates immediately (watch mode)

---

## Useful env vars (summary)

### edge-agent
- `DEVICE_ID` (e.g. `dre-001`)
- `MQTT_BROKER` (default `ssl://127.0.0.1:8883`)
- `MQTT_TLS_CA` / `MQTT_TLS_CERT` / `MQTT_TLS_KEY` (defaults derive from DEVICE_ID)
- `POLICY_MODE` = `watch|poll|both` (default watch)
- `POLICY_ADDR` (default `127.0.0.1:9443`)
- `POLICY_TLS_CA` / `POLICY_TLS_CERT` / `POLICY_TLS_KEY` (defaults derive from DEVICE_ID)
- `POLICY_TLS_SERVER_NAME` (default `localhost`)

### policy-svc
- `POLICY_ADDR` (default `127.0.0.1:9443`)
- `REGISTRY_PATH` (default `./registry.json`)
- `REGISTRY_POLL_MS` (default `2000`)
- `QUARANTINE_MODE` = `off|file|mqtt|both` (default `file`)
- `QUARANTINE_FILE` (default `./quarantine.log.jsonl`)
- `QUARANTINE_MQTT_BROKER` (default `ssl://127.0.0.1:8883`)
- `WATCH_POLL_MS` (default `1000`)

---

## Files
- `docker-compose.yml`, `mosquitto.conf`, `mosquitto.acl` — mTLS broker + ACL policy
- `registry.json` — per-device policies, patterns, command signer trust
- `cmd/edge-agent` — node
- `cmd/hub-ingest` — hub
- `cmd/policy-svc` — policy engine
- `cmd/command-cli` — send signed commands over MQTT
