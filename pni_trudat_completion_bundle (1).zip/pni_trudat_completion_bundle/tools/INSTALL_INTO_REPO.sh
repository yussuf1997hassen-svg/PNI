\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"

# payload files you may want to copy into repo (non-destructive)
mkdir -p "$REPO_DIR/tools/payload"
cp -R "$SRC_DIR/payload/"* "$REPO_DIR/tools/payload/"

chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true
echo "Installed completion bundle into: $REPO_DIR"
echo "Run ONE GO:"
echo "  cd ~/Downloads/pni && bash tools/TRUDAT_COMPLETE_ONE_GO.sh"
