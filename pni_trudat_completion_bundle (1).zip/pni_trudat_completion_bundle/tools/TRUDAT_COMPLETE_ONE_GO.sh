\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_common.sh

need docker

DEVICE_ID="${DEVICE_ID:-truDat}"

say "A) PNI: verify stack + signed command apply (truDat → device truDat)"
# If compose exists, bring up
if [ -f docker-compose.yml ] || [ -f docker-compose.yaml ]; then
  COMPOSE_FILE="docker-compose.yml"; [ -f docker-compose.yaml ] && COMPOSE_FILE="docker-compose.yaml"
  say "A1) docker compose up -d"
  docker compose -f "$COMPOSE_FILE" up -d
else
  warn "No docker-compose.yml found in repo root. Skipping docker compose up."
fi

say "A2) Check mosquitto + policy-svc ports"
# best-effort: these checks do not fail the whole script, but report status
if have lsof; then
  lsof -nP -iTCP:8883 -sTCP:LISTEN || true
  lsof -nP -iTCP:9443 -sTCP:LISTEN || true
fi

say "A3) Hub ingest telemetry OK lines (best-effort)"
# Try docker logs in common ways
( docker logs --tail=200 pni-hub-ingest 2>/dev/null || true ) | grep -Ei 'telemetry|ingest|accepted|ok' | tail -n 30 || true
( docker compose logs --tail=200 hub-ingest 2>/dev/null || true ) | grep -Ei 'telemetry|ingest|accepted|ok' | tail -n 30 || true

say "A4) Build command-cli (if present)"
if [ -d cmd/command-cli ]; then
  need go
  mkdir -p bin logs
  go build -o ./bin/command-cli ./cmd/command-cli
else
  warn "cmd/command-cli not found; skipping publish test."
fi

say "A5) Publish test command (issuer truDat → device truDat)"
if [ -x ./bin/command-cli ]; then
  MQTT_URL="${MQTT_URL:-tls://127.0.0.1:8883}"
  POLICY_URL="${POLICY_URL:-https://127.0.0.1:9443}"
  export MQTT_URL POLICY_URL POLICY_SVC_URL="${POLICY_SVC_URL:-$POLICY_URL}" TLS_INSECURE_SKIP_VERIFY=true INSECURE_SKIP_VERIFY=true
  ./bin/command-cli -issuer truDat -device "$DEVICE_ID" -cmd set_publish_interval_ms -params '{"value":1000}' || true
else
  warn "bin/command-cli not executable; skipping publish."
fi

say "A6) Edge-agent applied logs (best-effort)"
( docker logs --tail=250 pni-edge-agent 2>/dev/null || true ) | grep -Ei 'apply|applied|command|signature|policy' | tail -n 60 || true
( docker compose logs --tail=250 edge-agent 2>/dev/null || true ) | grep -Ei 'apply|applied|command|signature|policy' | tail -n 60 || true

say "B) TOKEN: deploy + mint equal balances to 2 wallets on LOCAL devnet (hardhat)"
# Requirements: a token-evm folder (your stablecoin package) or skip
if [ -d token-evm ]; then
  need node
  need npm

  # Require wallet addresses; do NOT accept private keys in this script
  : "${WALLET1:?Set WALLET1=0x... (public address)}"
  : "${WALLET2:?Set WALLET2=0x... (public address)}"
  : "${MINT_TOKENS:?Set MINT_TOKENS e.g. 1000000}"

  say "B1) Install deps (token-evm)"
  cd token-evm
  if [ -f package-lock.json ]; then npm ci; else npm install; fi

  say "B2) Ensure scripts/deploy_and_mint.ts exists"
  mkdir -p scripts
  cp -f "$ROOT/tools/payload/deploy_and_mint.ts" scripts/deploy_and_mint.ts

  say "B3) Start hardhat node (background) if 8545 not listening"
  if have lsof && lsof -nP -iTCP:8545 -sTCP:LISTEN >/dev/null 2>&1; then
    echo "Hardhat node already listening on 8545"
  else
    mkdir -p "$ROOT/logs"
    (npx hardhat node > "$ROOT/logs/hardhat_node.log" 2>&1 & echo $! > "$ROOT/logs/hardhat_node.pid")
    sleep 2
  fi

  say "B4) Deploy + mint equal balances"
  # Allow CONTRACT_NAME override; TOKEN_DECIMALS default 18; token metadata optional
  npx hardhat run scripts/deploy_and_mint.ts --network localhost | tee "$ROOT/logs/deploy_and_mint.out"

  say "B5) Stop hardhat node if we started it"
  if [ -f "$ROOT/logs/hardhat_node.pid" ]; then
    kill "$(cat "$ROOT/logs/hardhat_node.pid")" >/dev/null 2>&1 || true
    rm -f "$ROOT/logs/hardhat_node.pid"
  fi

  say "B6) Extract receipt JSON into dist/mint_receipt.json"
  cd "$ROOT"
  mkdir -p dist
  python3 - <<'PY'
import re, json, pathlib
p = pathlib.Path("logs/deploy_and_mint.out")
out = pathlib.Path("dist/mint_receipt.json")
txt = p.read_text(errors="ignore") if p.exists() else ""
m = re.search(r"RECEIPT_JSON_BEGIN\s*(\{.*?\})\s*RECEIPT_JSON_END", txt, flags=re.S)
if not m:
    raise SystemExit("Could not find receipt JSON in logs/deploy_and_mint.out")
obj = json.loads(m.group(1))
out.write_text(json.dumps(obj, indent=2))
print("WROTE:", out)
PY

else
  warn "token-evm folder not found in this repo. Skipping token mint step."
fi

say "DONE: Technical completion achieved if:"
echo " - hub-ingest shows telemetry accepted/ok lines"
echo " - edge-agent shows apply/applied lines after publish"
echo " - dist/mint_receipt.json exists and both wallets have equal balances"
