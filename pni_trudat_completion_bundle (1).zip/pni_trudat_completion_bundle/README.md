# PNI + TruDAT Completion Bundle

This bundle gives you the **technical completion** run:

- PNI end-to-end: mosquitto + policy-svc + hub-ingest + edge-agent (DEVICE_ID=truDat) +
  publish as truDat and confirm edge applies.

- Token end-to-end (local devnet): deploy your token in `token-evm/` and mint the **same amount**
  to **two wallet addresses**.

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_trudat_completion_bundle
unzip -o ~/Downloads/pni_trudat_completion_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_trudat_completion_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO (single line)
Replace WALLET1/WALLET2 with your two **public** addresses:

```bash
cd ~/Downloads/pni && WALLET1=0xYOUR_PUBLIC_ADDRESS_1 WALLET2=0xYOUR_PUBLIC_ADDRESS_2 MINT_TOKENS=1000000 bash tools/TRUDAT_COMPLETE_ONE_GO.sh
```

Notes:
- Do NOT paste private keys into terminal.
- If your token contract has a specific name, you can set: CONTRACT_NAME=SEEStablecoin (example).
