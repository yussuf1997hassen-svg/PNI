\
import { ethers } from "hardhat";

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v || !v.trim()) throw new Error(`Missing env ${name}`);
  return v.trim();
}

function toUnits(amount: string, decimals: number) {
  // accept integer or decimal strings
  return ethers.parseUnits(amount, decimals);
}

async function findContractName(candidates: string[]): Promise<string> {
  for (const c of candidates) {
    try {
      await ethers.getContractFactory(c);
      return c;
    } catch (_) {}
  }
  throw new Error(
    `Could not find a deployable contract factory. Set CONTRACT_NAME env (e.g. CONTRACT_NAME=SEEStablecoin). Tried: ${candidates.join(", ")}`
  );
}

async function main() {
  const wallet1 = requireEnv("WALLET1");
  const wallet2 = requireEnv("WALLET2");
  const mintTokens = requireEnv("MINT_TOKENS"); // in human units, e.g. "1000000"
  const decimals = parseInt(process.env.TOKEN_DECIMALS || "18", 10);

  const issuerLabel = process.env.ISSUER_LABEL || "truDat";
  const symbol = process.env.TOKEN_SYMBOL || "TDAT";
  const name = process.env.TOKEN_NAME || "TruDAT Token";

  // If your project already has a specific contract name, set CONTRACT_NAME explicitly.
  const contractName =
    process.env.CONTRACT_NAME ||
    (await findContractName([
      "SEEStablecoin",
      "TruDAT",
      "TDAT",
      "EfreetToken",
      "Token",
      "MyToken",
      "ERC20Mock",
    ]));

  const [deployer] = await ethers.getSigners();
  console.log(`Deployer: ${deployer.address}`);
  console.log(`Contract: ${contractName}`);

  // Deploy with best-effort constructor args
  let token: any;
  try {
    const Factory = await ethers.getContractFactory(contractName);
    // Try common constructors: (name, symbol) or () or (name, symbol, decimals)
    try {
      token = await Factory.deploy(name, symbol);
    } catch (e1) {
      try {
        token = await Factory.deploy(name, symbol, decimals);
      } catch (e2) {
        token = await Factory.deploy();
      }
    }
    await token.waitForDeployment();
  } catch (e) {
    console.error(e);
    throw new Error(`Deploy failed for ${contractName}. Set CONTRACT_NAME and ensure constructor matches.`);
  }

  const addr = await token.getAddress();
  console.log(`Deployed at: ${addr}`);

  const amount = toUnits(mintTokens, decimals);

  // mint if available, otherwise transfer from deployer
  const iface = token.interface;
  const hasMint = iface.fragments.some((f: any) => f.type === "function" && f.name === "mint");
  const hasOwnerMint = iface.fragments.some((f: any) => f.type === "function" && f.name === "ownerMint");

  if (hasMint) {
    console.log(`Minting ${mintTokens} to ${wallet1} and ${wallet2} via mint()`);
    await (await token.mint(wallet1, amount)).wait();
    await (await token.mint(wallet2, amount)).wait();
  } else if (hasOwnerMint) {
    console.log(`Minting ${mintTokens} to ${wallet1} and ${wallet2} via ownerMint()`);
    await (await token.ownerMint(wallet1, amount)).wait();
    await (await token.ownerMint(wallet2, amount)).wait();
  } else {
    console.log(`No mint() found; attempting transfer from deployer balance.`);
    const bal = await token.balanceOf(deployer.address);
    if (bal < amount * 2n) {
      throw new Error(`Deployer balance too low to transfer. Add mint function or pre-mint supply.`);
    }
    await (await token.transfer(wallet1, amount)).wait();
    await (await token.transfer(wallet2, amount)).wait();
  }

  const b1 = await token.balanceOf(wallet1);
  const b2 = await token.balanceOf(wallet2);

  console.log(`Wallet1 balance: ${ethers.formatUnits(b1, decimals)}`);
  console.log(`Wallet2 balance: ${ethers.formatUnits(b2, decimals)}`);

  // Write receipt
  const receipt = {
    deployedContract: contractName,
    tokenAddress: addr,
    decimals,
    tokenName: name,
    tokenSymbol: symbol,
    issuerLabel,
    mintedTo: [wallet1, wallet2],
    amountEach: mintTokens,
  };
  console.log("RECEIPT_JSON_BEGIN");
  console.log(JSON.stringify(receipt, null, 2));
  console.log("RECEIPT_JSON_END");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
