# PNI — Completion (issuer pubkey already in hand)

## Single command “completion”
Replace `<PUBKEY_B64>` with the issuer pubkey you already got:

```bash
cd ~/Downloads
unzip -o pni_code_only_stack_final.zip
cd pni
bash scripts/complete.sh <PUBKEY_B64>
```

## What “complete” means here
- policy-svc, hub-ingest, edge-agent all running
- MQTT broker running via Docker
- registry patched so **signed commands are accepted**
- edge-agent auto-refreshes policy via POLICY_MODE=watch

## Named identities (truDat / sEE / iEye / efreet)
These are additional client certificate identities (CNs) and device_ids already pre-registered.

To run a simulated node as one of them:
```bash
DEVICE_ID=truDat POLICY_MODE=watch go run ./cmd/edge-agent
DEVICE_ID=sEE   POLICY_MODE=watch go run ./cmd/edge-agent
DEVICE_ID=iEye  POLICY_MODE=watch go run ./cmd/edge-agent
DEVICE_ID=efreet POLICY_MODE=watch go run ./cmd/edge-agent
```

## Command issuer
- MQTT ACL: only **truDat** can publish to `pni/commands/#` and `pni/config/#`.
- `command-cli` uses the truDat client cert by default.
