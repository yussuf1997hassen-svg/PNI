# PNI ENDGAME Bundle

This bundle finishes the project with a single **proof zip**.
It avoids Hardhat/Node version issues by running token minting inside Docker (Node 20).

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_endgame_bundle
unzip -o ~/Downloads/pni_endgame_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_endgame_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO (copy/paste)
```bash
cd ~/Downloads/pni && ISSUER_PUBKEY_B64='mMnyXVv3w1sodDq7xskHzoOHZ3KCSUqxb1NewwdFkKQ=' MINT_TOKENS=1000000 bash tools/ENDGAME_ONE_GO.sh
```

## Outputs
- dist/mint_receipt.json
- dist/ENDGAME_PROOF_<timestamp>.zip
- secrets/evm_wallet*_priv.hex (DO NOT COMMIT)
