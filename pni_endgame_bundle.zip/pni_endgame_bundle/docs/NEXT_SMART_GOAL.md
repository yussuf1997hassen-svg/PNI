# Next SMART goal (true completion)

## What you have
- A PNI signing identity: `issuer_pubkey_b64` (base64 pubkey) for truDat.
- A running Docker stack (mosquitto/hub/edge/policy).

## What completes the project (measurable)
1) **PNI proof**: truDat publishes → policy allows → edge applies (log evidence).
2) **Token proof**: two EVM wallets receive the exact same amount (receipt saved).
3) **Single portable proof artifact**: one zip in `dist/` that contains receipts/logs.

## Important clarification
- `issuer_pubkey_b64` is NOT an EVM wallet address.
- To hold ERC-20 tokens you need `0x...` EVM addresses.
- This bundle generates two EVM wallets locally and mints equal amounts on a local devnet.
