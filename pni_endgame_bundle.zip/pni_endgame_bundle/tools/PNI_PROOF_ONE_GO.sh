\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/tools/_eg_common.sh"

: "${ISSUER_PUBKEY_B64:?Set ISSUER_PUBKEY_B64='base64...' (public)}"
DEVICE_ID="${DEVICE_ID:-truDat}"
CMD_NAME="${CMD_NAME:-set_publish_interval_ms}"
CMD_VALUE="${CMD_VALUE:-1000}"

say "PNI 1) Run final publish proof (if script exists)"
if [ -x "$ROOT/tools/TRUDAT_FINAL_ONE_GO.sh" ]; then
  ISSUER_PUBKEY_B64="$ISSUER_PUBKEY_B64" DEVICE_ID="$DEVICE_ID" CMD_NAME="$CMD_NAME" CMD_VALUE="$CMD_VALUE" \
  bash "$ROOT/tools/TRUDAT_FINAL_ONE_GO.sh"
else
  warn "tools/TRUDAT_FINAL_ONE_GO.sh missing; skipping PNI publish proof."
fi

say "PNI DONE ✅"
