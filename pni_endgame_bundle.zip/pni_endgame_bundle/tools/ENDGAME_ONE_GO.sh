\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_eg_common.sh

: "${ISSUER_PUBKEY_B64:?Set ISSUER_PUBKEY_B64='base64...' }"
MINT_TOKENS="${MINT_TOKENS:-1000000}"

say "0) Completion goal"
echo "We finish when we have proof artifacts:"
echo " - PNI publish/apply evidence (best-effort)"
echo " - Token equal mint receipt (dist/mint_receipt.json)"
echo " - One final zipped proof bundle (dist/ENDGAME_PROOF_<ts>.zip)"

say "1) PNI proof"
ISSUER_PUBKEY_B64="$ISSUER_PUBKEY_B64" bash tools/PNI_PROOF_ONE_GO.sh || true

say "2) Token equal distribution (dockerized hardhat, avoids local Node version issues)"
MINT_TOKENS="$MINT_TOKENS" bash tools/TOKEN_EQUALIZE_ONE_GO.sh

say "3) Produce ENDGAME proof zip"
mkdir -p dist logs
TS="$(date +%Y%m%d_%H%M%S)"
OUT="dist/ENDGAME_PROOF_${TS}.zip"
TMP="dist/.endgame_${TS}"
rm -rf "$TMP"
mkdir -p "$TMP"
cp -f dist/mint_receipt.json "$TMP/" 2>/dev/null || true
cp -f logs/token_deploy_and_mint.log "$TMP/" 2>/dev/null || true
# include any go-live or done zips if present
ls -1t dist/GO_LIVE_BUNDLE_*.zip 2>/dev/null | head -n 1 | xargs -I{} cp -f {} "$TMP/" 2>/dev/null || true
ls -1t dist/pni_DONE_*.zip 2>/dev/null | head -n 1 | xargs -I{} cp -f {} "$TMP/" 2>/dev/null || true

cat > "$TMP/README.txt" <<EOF
ENDGAME PROOF BUNDLE
- mint_receipt.json: equal mint proof
- token_deploy_and_mint.log: deploy/mint run log
- optional: GO_LIVE_BUNDLE_*.zip, pni_DONE_*.zip if present
EOF

( cd "$TMP" && zip -r "$ROOT/$OUT" . >/dev/null )
rm -rf "$TMP"
echo "OK: $OUT"
echo "SHA256:"
shasum -a 256 "$OUT" || true

say "DONE ✅"
