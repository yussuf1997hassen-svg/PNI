\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/dist" "$REPO_DIR/logs" "$REPO_DIR/secrets"
chmod 700 "$REPO_DIR/secrets" 2>/dev/null || true

cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo "Installed ENDGAME bundle into: $REPO_DIR"
echo "Run ONE GO:"
echo "  cd ~/Downloads/pni && ISSUER_PUBKEY_B64='...' bash tools/ENDGAME_ONE_GO.sh"
