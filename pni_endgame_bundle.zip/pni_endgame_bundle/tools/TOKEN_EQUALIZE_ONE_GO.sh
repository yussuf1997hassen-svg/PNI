\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/tools/_eg_common.sh"

MINT_TOKENS="${MINT_TOKENS:-1000000}"
TOKEN_DIR="$ROOT/token-local"
SECRETS="$ROOT/secrets"
DIST="$ROOT/dist"
LOGS="$ROOT/logs"

say "TOKEN 1) Create local token workspace at token-local/ (idempotent)"
mkdir -p "$TOKEN_DIR/contracts" "$TOKEN_DIR/scripts" "$TOKEN_DIR/hardhat"
mkdir -p "$SECRETS" "$DIST" "$LOGS"
chmod 700 "$SECRETS" 2>/dev/null || true

# package.json
cat > "$TOKEN_DIR/package.json" <<'JSON'
{
  "name": "trudat-token-local",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "node": "hardhat node --hostname 0.0.0.0 --port 8545",
    "deploy:mint": "hardhat run scripts/deploy_and_mint.js --network localhost"
  },
  "devDependencies": {
    "hardhat": "^2.22.12",
    "@nomicfoundation/hardhat-toolbox": "^5.0.0",
    "@openzeppelin/contracts": "^5.0.2",
    "dotenv": "^16.4.5"
  }
}
JSON

# hardhat.config.js
cat > "$TOKEN_DIR/hardhat.config.js" <<'JS'
require("@nomicfoundation/hardhat-toolbox");
module.exports = {
  solidity: "0.8.24",
  networks: {
    localhost: { url: "http://127.0.0.1:8545" }
  }
};
JS

# Contract
cat > "$TOKEN_DIR/contracts/TruDATToken.sol" <<'SOL'
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract TruDATToken is ERC20, Ownable {
    constructor(address initialOwner) ERC20("TruDAT", "TDAT") Ownable(initialOwner) {}

    function mint(address to, uint256 amount) external onlyOwner {
        _mint(to, amount);
    }
}
SOL

# Deploy+mint script
cat > "$TOKEN_DIR/scripts/deploy_and_mint.js" <<'JS'
const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");

async function main() {
  const mintTokens = process.env.MINT_TOKENS || "1000000";
  const wallet1 = process.env.WALLET1;
  const wallet2 = process.env.WALLET2;
  if (!wallet1 || !wallet2) throw new Error("WALLET1/WALLET2 env required");

  const [deployer] = await ethers.getSigners();
  const Token = await ethers.getContractFactory("TruDATToken");
  const token = await Token.deploy(deployer.address);
  await token.waitForDeployment();
  const addr = await token.getAddress();

  const decimals = 18n;
  const amountWei = BigInt(mintTokens) * (10n ** decimals);

  const tx1 = await token.mint(wallet1, amountWei);
  await tx1.wait();
  const tx2 = await token.mint(wallet2, amountWei);
  await tx2.wait();

  const b1 = await token.balanceOf(wallet1);
  const b2 = await token.balanceOf(wallet2);

  const out = {
    contract: addr,
    symbol: "TDAT",
    decimals: 18,
    wallet1,
    wallet2,
    amountEach: mintTokens,
    amountEachWei: amountWei.toString(),
    balance1Wei: b1.toString(),
    balance2Wei: b2.toString()
  };

  const distDir = path.resolve(__dirname, "..", "..", "dist");
  fs.mkdirSync(distDir, { recursive: true });
  fs.writeFileSync(path.join(distDir, "mint_receipt.json"), JSON.stringify(out, null, 2));
  console.log("OK: dist/mint_receipt.json written");
  console.log(out);
}
main().catch((e) => { console.error(e); process.exit(1); });
JS

say "TOKEN 2) Generate TWO EVM wallets locally (stored in secrets/, never printed with private keys)"
# Use node inside container to avoid local node version issues.
need docker

docker run --rm -v "$SECRETS:/out" node:20-bullseye bash -lc '
  set -e
  node - << "NODE"
  const fs = require("fs");
  const crypto = require("crypto");
  function mk() {
    const priv = "0x" + crypto.randomBytes(32).toString("hex");
    // compute address with ethers (install minimal)
    return priv;
  }
  const priv1 = mk(), priv2 = mk();
  fs.writeFileSync("/out/evm_wallet1_priv.hex", priv1 + "\n", { mode: 0o600 });
  fs.writeFileSync("/out/evm_wallet2_priv.hex", priv2 + "\n", { mode: 0o600 });
  NODE
  '

# Derive addresses using ethers in the same container (install ethers temporarily)
docker run --rm -v "$SECRETS:/out" node:20-bullseye bash -lc '
  set -e
  npm -s i ethers@6 >/dev/null
  node - << "NODE"
  const fs = require("fs");
  const { Wallet } = require("ethers");
  const p1 = fs.readFileSync("/out/evm_wallet1_priv.hex","utf8").trim();
  const p2 = fs.readFileSync("/out/evm_wallet2_priv.hex","utf8").trim();
  const w1 = new Wallet(p1);
  const w2 = new Wallet(p2);
  fs.writeFileSync("/out/evm_wallet1_addr.txt", w1.address + "\n", { mode: 0o600 });
  fs.writeFileSync("/out/evm_wallet2_addr.txt", w2.address + "\n", { mode: 0o600 });
  NODE
  '

chmod 600 "$SECRETS"/evm_wallet*_*.txt "$SECRETS"/evm_wallet*_priv.hex 2>/dev/null || true

W1="$(cat "$SECRETS/evm_wallet1_addr.txt")"
W2="$(cat "$SECRETS/evm_wallet2_addr.txt")"
echo "Wallet1 address: $W1"
echo "Wallet2 address: $W2"
echo "NOTE: Private keys saved locally in secrets/ (DO NOT COMMIT)."

say "TOKEN 3) Start dockerized hardhat node"
# Remove old container if exists
docker rm -f trudat-evm >/dev/null 2>&1 || true

# Install deps once (inside a one-off container)
docker run --rm -v "$TOKEN_DIR:/app" -w /app node:20-bullseye bash -lc 'npm -s install >/dev/null'

# Start hardhat node as detached container
docker run -d --name trudat-evm -p 8545:8545 -v "$TOKEN_DIR:/app" -w /app node:20-bullseye bash -lc 'npx hardhat node --hostname 0.0.0.0 --port 8545' >/dev/null

# Wait for port
say "TOKEN 4) Wait for 8545 ready"
for i in $(seq 1 40); do
  if nc -z 127.0.0.1 8545 >/dev/null 2>&1; then echo "OK: 8545 up"; break; fi
  sleep 0.25
  if [ "$i" = "40" ]; then die "Hardhat node did not open 8545"; fi
done

say "TOKEN 5) Deploy + mint equal amounts"
docker exec -e WALLET1="$W1" -e WALLET2="$W2" -e MINT_TOKENS="$MINT_TOKENS" trudat-evm bash -lc 'npx hardhat compile >/dev/null && npx hardhat run scripts/deploy_and_mint.js --network localhost' | tee "$LOGS/token_deploy_and_mint.log"

say "TOKEN 6) Stop hardhat node container"
docker rm -f trudat-evm >/dev/null 2>&1 || true

say "TOKEN DONE ✅"
echo "Receipt: $DIST/mint_receipt.json"
