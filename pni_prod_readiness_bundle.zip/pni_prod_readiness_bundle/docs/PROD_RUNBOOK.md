# Production runbook (next SMART goal)

You are “production-complete” when you have:
1) Testnet receipts proving equal balances on-chain.
2) A release bundle zip (PROD_RELEASE_*.zip) that excludes secrets.
3) A target runtime environment + ops plan.

## Recommended next SMART goal
Deploy PNI stack to a real environment (staging) + monitoring.

### Minimum staging checklist
- Choose runtime: (A) single VM with docker compose OR (B) Kubernetes.
- Secrets: store issuer private key in a secret manager (1Password, AWS/GCP secret manager, Vault).
- Monitoring: container health + log shipping + alerting for “publish failed / apply failed”.

### What code cannot guarantee
Market value/price is not programmable. What you can ship:
- fixed supply / mint policy
- governance (ACL + signatures)
- utility & adoption path
