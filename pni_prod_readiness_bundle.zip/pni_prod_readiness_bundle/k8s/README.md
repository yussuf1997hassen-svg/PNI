# Kubernetes templates (placeholders)

Templates only. You must set:
- image registry + tags
- secrets via Kubernetes Secret (not committed)
- ingress / service types

Use as a starting point for staging.
