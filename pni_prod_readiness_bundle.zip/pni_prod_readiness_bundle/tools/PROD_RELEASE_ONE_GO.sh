\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pr_common.sh

say "0) Goal: create production-ready release artifact (no secrets)"
say "1) Validate testnet equal-mint receipts"
bash tools/VERIFY_TESTNET_RECEIPTS.sh

say "2) Capture PNI snapshot (docker ps + logs)"
bash tools/PNI_SNAPSHOT.sh || true

say "3) Build PROD release zip"
bash tools/MAKE_PROD_RELEASE_ZIP.sh

say "DONE ✅"
echo "Next milestone after this zip:"
echo " - Deploy PNI stack to staging (VM/k8s)"
echo " - Put issuer private key into a secret manager (NOT in repo)"
echo " - Monitoring + alerting + CI to re-run proof tests"
