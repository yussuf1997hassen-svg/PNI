\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pr_common.sh
need docker

TS="$(date +%Y%m%d_%H%M%S)"
OUT="dist/pni_snapshot_${TS}.txt"

say "Capture docker status + filtered logs snapshot"
{
  echo "=== docker ps ==="
  docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
  echo
  for c in pni-edge-agent edge-agent pni-hub-ingest hub-ingest pni-policy policy-svc pni-mosquitto mosquitto; do
    if docker ps --format '{{.Names}}' | grep -qx "$c"; then
      echo "---- $c (last 200 filtered) ----"
      docker logs --tail=200 "$c" 2>&1 | grep -Ei 'telemetry|accepted|ok|apply|applied|command|policy|issuer|truDat' || true
      echo
    fi
  done
} > "$OUT" || true

echo "OK: $OUT"
