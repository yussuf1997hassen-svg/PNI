\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pr_common.sh

say "Verify testnet receipts exist + equal balances"
python3 - <<'PY'
import glob,json,sys,os
files=sorted(glob.glob("dist/testnet_receipt_*.json"))
if not files:
    raise SystemExit("ERROR: No dist/testnet_receipt_*.json found. Run tools/TESTNET_DEPLOY_ONE_GO.sh first.")
ok=True
for f in files:
    d=json.load(open(f,'r'))
    b1=int(d.get("balance1Wei","0")); b2=int(d.get("balance2Wei","0"))
    if b1<=0 or b2<=0 or b1!=b2:
        ok=False
        print("FAIL", os.path.basename(f), "b1", b1, "b2", b2)
    else:
        print("OK ", os.path.basename(f), "chainId", d.get("chainId"), "contract", d.get("contract"))
if not ok: sys.exit(1)
PY
say "OK: testnet receipts validated ✅"
