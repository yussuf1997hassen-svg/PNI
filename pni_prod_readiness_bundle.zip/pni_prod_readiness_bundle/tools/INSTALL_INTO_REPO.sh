\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }
mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/dist" "$REPO_DIR/ci" "$REPO_DIR/k8s"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
cp -R "$SRC_DIR/ci/"* "$REPO_DIR/ci/" 2>/dev/null || true
cp -R "$SRC_DIR/k8s/"* "$REPO_DIR/k8s/" 2>/dev/null || true
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true
echo "Installed PROD READINESS bundle into: $REPO_DIR"
echo "Run ONE GO:"
echo "  cd ~/Downloads/pni && bash tools/PROD_RELEASE_ONE_GO.sh"
