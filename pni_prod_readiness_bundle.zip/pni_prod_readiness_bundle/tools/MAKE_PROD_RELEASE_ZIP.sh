\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_pr_common.sh

need zip
mkdir -p dist
TS="$(date +%Y%m%d_%H%M%S)"
TMP="dist/.prod_release_${TS}"
OUT="dist/PROD_RELEASE_${TS}.zip"
rm -rf "$TMP"
mkdir -p "$TMP"

say "Assemble release payload (no secrets)"
cp -f dist/testnet_receipt_*.json "$TMP/" 2>/dev/null || true
cp -f dist/mint_receipt.json "$TMP/" 2>/dev/null || true
cp -f dist/DONE_DELIVERABLE_*.zip "$TMP/" 2>/dev/null || true
cp -f dist/ENDGAME_PROOF_*.zip "$TMP/" 2>/dev/null || true
cp -f dist/GO_LIVE_BUNDLE_*.zip "$TMP/" 2>/dev/null || true
cp -f dist/pni_snapshot_*.txt "$TMP/" 2>/dev/null || true

mkdir -p "$TMP/docs" "$TMP/k8s" "$TMP/ci"
cp -R docs/PROD_RUNBOOK.md "$TMP/docs/" 2>/dev/null || true
cp -R k8s/* "$TMP/k8s/" 2>/dev/null || true
cp -R ci/* "$TMP/ci/" 2>/dev/null || true

cat > "$TMP/README.txt" <<EOF
PROD RELEASE BUNDLE
- Includes: receipts + proof zips + snapshots + runbook + templates
- EXCLUDES: secrets/, .env files, private keys
EOF

( cd "$TMP" && zip -r "$ROOT/$OUT" . >/dev/null )
rm -rf "$TMP"
echo "OK: $OUT"
echo "SHA256:"
shasum -a 256 "$OUT" || true
