# PROD READINESS bundle

Install then run tools/PROD_RELEASE_ONE_GO.sh
