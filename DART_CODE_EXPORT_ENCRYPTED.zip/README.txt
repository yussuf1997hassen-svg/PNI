DART Handbook — Code Export

Source: DART_handbook.pdf
Format: Encrypted symbolic code
Encryption basis: User-provided DAT pattern

To decode: reverse pattern mapping and ASCII values.
