# PNI Docker Portable Release Bundle (the real “next step” after Dockerize)

You already:
- run mosquitto + policy-svc + hub-ingest + edge-agent
- dockerized the services

**Next step = make it portable and “done”**
Meaning: one command creates a **single portable zip** that can be moved to another machine and run with Docker,
including the built images (as a tar) + compose files + run script.

This bundle adds:

- `tools/DOCKER_PORTABLE_ONE_GO.sh`
  - brings up the docker stack (base compose + override)
  - checks hub-ingest for telemetry OK (best-effort pattern)
  - publishes a signed command as `truDat`
  - checks edge-agent logs for apply/accepted (best-effort pattern)
  - exports docker images to `dist/docker_images_<ts>.tar`
  - packages a portable zip: `dist/pni_docker_portable_<ts>.zip`

The portable zip contains:
- compose files
- `.env.example`
- `RUN_PORTABLE.sh` (loads images + starts compose + tails logs)

## Install into your repo (one paste)
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_docker_portable_release_bundle
unzip -o ~/Downloads/pni_docker_portable_release_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_docker_portable_release_bundle/tools/INSTALL_INTO_REPO.sh
```

## Create the portable docker release (ONE command)
```bash
cd ~/Downloads/pni
bash tools/DOCKER_PORTABLE_ONE_GO.sh
```

Outputs:
- `dist/pni_docker_portable_<timestamp>.zip`  (this is the “entirety-of-entirety” for Docker)
- also copies it to `~/Downloads/` for easy upload

## Run portable zip on another machine
Unzip it and run:
```bash
bash RUN_PORTABLE.sh
```
