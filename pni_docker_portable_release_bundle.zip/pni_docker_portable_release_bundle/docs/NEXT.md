# What is “next” after Dockerize?

1) Prove it runs *as containers* (done by DOCKER_PORTABLE_ONE_GO).
2) Export images + compose into a portable zip.
3) Run the portable zip on another machine (or your Linux edge boxes).

That’s the “done-done” state for Docker.
