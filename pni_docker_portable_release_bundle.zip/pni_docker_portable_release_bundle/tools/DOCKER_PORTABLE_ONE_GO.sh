\
#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

source tools/_docker_portable_common.sh

need docker
need go
need zip
need python3
need grep
need sed

docker version >/dev/null 2>&1 || die "Docker not running (start Docker Desktop)"
docker compose version >/dev/null 2>&1 || die "docker compose missing"

STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p dist bin logs

BASE="$(detect_compose_base)"
[ -n "${BASE:-}" ] || die "No base compose file found in repo root."
OVR="$(detect_override)"
[ -n "${OVR:-}" ] || die "No override compose found. Run your dockerize step first (it creates docker-compose.pni-services.yml)."

MOSQ="$(detect_mosquitto_service "$BASE")"

say "0) Bring up stack (build + run)"
docker compose -f "$BASE" -f "$OVR" up -d --build "$MOSQ" policy-svc hub-ingest edge-agent
docker compose -f "$BASE" -f "$OVR" ps

say "1) Logs check: telemetry (best-effort)"
if docker compose -f "$BASE" -f "$OVR" logs --tail=400 hub-ingest 2>/dev/null | grep -Eqi 'telemetry.*ok|telemetry_ok|telemetry ok|telemetry.*accepted|telemetry.*ingest'; then
  echo "OK: telemetry line(s):"
  docker compose -f "$BASE" -f "$OVR" logs --tail=400 hub-ingest | grep -Eni 'telemetry.*ok|telemetry_ok|telemetry ok|telemetry.*accepted|telemetry.*ingest' | tail -n 15
else
  warn "No telemetry success match; showing last 120 hub-ingest lines:"
  docker compose -f "$BASE" -f "$OVR" logs --tail=120 hub-ingest || true
fi

say "2) Publish test command as truDat (from host)"
if [ -d cmd/command-cli ]; then
  go build -o ./bin/command-cli ./cmd/command-cli
  MQTT_URL="tls://127.0.0.1:8883" POLICY_URL="https://127.0.0.1:9443" POLICY_SVC_URL="https://127.0.0.1:9443" \
    ./bin/command-cli -issuer truDat -device truDat -cmd set_publish_interval_ms -params '{"value":1000}' || true
else
  warn "cmd/command-cli not present; skipping publish step."
fi

say "3) Verify apply/accepted in edge-agent logs (best-effort)"
if docker compose -f "$BASE" -f "$OVR" logs --tail=500 edge-agent 2>/dev/null | grep -Eqi 'applied|apply|accepted|command.*ok|command.*accepted|signature.*ok|policy.*allow'; then
  echo "OK: apply/accepted line(s):"
  docker compose -f "$BASE" -f "$OVR" logs --tail=500 edge-agent | grep -Eni 'applied|apply|accepted|command.*ok|command.*accepted|signature.*ok|policy.*allow' | tail -n 30
else
  warn "No apply/accepted match; showing last 160 edge-agent lines:"
  docker compose -f "$BASE" -f "$OVR" logs --tail=160 edge-agent || true
fi

say "4) Export docker images used by this compose into a tar"
# Extract images from rendered compose config (includes built images + pulled images)
IMAGES="$(docker compose -f "$BASE" -f "$OVR" config 2>/dev/null | awk '/image:/{print $2}' | tr -d '"' | sort -u || true)"
if [ -z "${IMAGES:-}" ]; then
  warn "No images detected from compose config; skipping docker save."
else
  echo "Images:"
  echo "$IMAGES"
  TAR="dist/docker_images_${STAMP}.tar"
  # ensure images exist locally (build/pull best-effort)
  while read -r img; do
    [ -z "$img" ] && continue
    docker image inspect "$img" >/dev/null 2>&1 || docker pull "$img" >/dev/null 2>&1 || true
  done <<< "$IMAGES"
  docker save -o "$TAR" $IMAGES
  echo "OK: saved images -> $TAR"
fi

say "5) Create portable zip (compose + env + run script + images tar)"
PORTDIR="dist/.portable_${STAMP}"
rm -rf "$PORTDIR"
mkdir -p "$PORTDIR"

cp -f "$BASE" "$PORTDIR/compose.base.yml"
cp -f "$OVR" "$PORTDIR/compose.override.yml"
[ -f .env.example ] && cp -f .env.example "$PORTDIR/.env.example" || true
[ -f dist/docker_images_${STAMP}.tar ] && cp -f "dist/docker_images_${STAMP}.tar" "$PORTDIR/" || true

cat > "$PORTDIR/RUN_PORTABLE.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
need(){ command -v "$1" >/dev/null 2>&1 || { echo "ERROR: missing $1"; exit 1; }; }
need docker
docker version >/dev/null 2>&1 || { echo "ERROR: start Docker first"; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "ERROR: docker compose missing"; exit 1; }

if ls -1 docker_images_*.tar >/dev/null 2>&1; then
  TAR="$(ls -1t docker_images_*.tar | head -n 1)"
  echo "==> Loading images: $TAR"
  docker load -i "$TAR" >/dev/null
fi

echo "==> Starting stack"
docker compose -f compose.base.yml -f compose.override.yml up -d
docker compose -f compose.base.yml -f compose.override.yml ps

echo "==> Tail logs (Ctrl+C to stop tail)"
docker compose -f compose.base.yml -f compose.override.yml logs -f --tail=120 hub-ingest edge-agent policy-svc
EOF
chmod +x "$PORTDIR/RUN_PORTABLE.sh"

OUT="dist/pni_docker_portable_${STAMP}.zip"
( cd "$PORTDIR" && zip -r "$ROOT/$OUT" . >/dev/null )
rm -rf "$PORTDIR"

echo "OK: created $OUT"
cp -f "$OUT" "$HOME/Downloads/" 2>/dev/null || true
echo "COPIED TO: $HOME/Downloads/$(basename "$OUT")"

say "DONE"
echo "Portable run: unzip on another machine -> bash RUN_PORTABLE.sh"
