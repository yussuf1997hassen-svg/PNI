\
#!/usr/bin/env bash
set -euo pipefail
say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }
die(){ printf "\nERROR: %s\n" "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

detect_compose_base(){
  ls -1 docker-compose.yml docker-compose.yaml compose.yml compose.yaml 2>/dev/null | head -n 1 || true
}

detect_override(){
  # from earlier dockerize step
  if [ -f docker-compose.pni-services.yml ]; then echo "docker-compose.pni-services.yml"; return 0; fi
  if [ -f docker-compose.pni_services.yml ]; then echo "docker-compose.pni_services.yml"; return 0; fi
  echo ""
}

detect_mosquitto_service(){
  local compose="$1"
  local svc
  svc="$(docker compose -f "$compose" config --services 2>/dev/null | grep -i mosquitto | head -n 1 || true)"
  [ -n "${svc:-}" ] && { echo "$svc"; return 0; }
  echo "mosquitto"
}
