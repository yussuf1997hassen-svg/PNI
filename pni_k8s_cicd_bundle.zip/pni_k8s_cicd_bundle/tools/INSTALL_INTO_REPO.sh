\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/deploy" "$REPO_DIR/.github/workflows"

cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
rsync -a "$SRC_DIR/deploy/" "$REPO_DIR/deploy/"
cp -R "$SRC_DIR/.github/workflows/"* "$REPO_DIR/.github/workflows/"

chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo "Installed k8s+ci/cd bundle into: $REPO_DIR"
echo "Next: cd ~/Downloads/pni && bash tools/KIND_ONE_GO.sh"
