\
#!/usr/bin/env bash
set -euo pipefail
say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }
die(){ printf "\nERROR: %s\n" "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }
