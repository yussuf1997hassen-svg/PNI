\
#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_k8s_common.sh

need docker
need kubectl
need kind
need go

CLUSTER="${CLUSTER:-pni}"
NS="${NS:-pni}"
DEVICE_ID="${DEVICE_ID:-truDat}"

say "0) Create kind cluster (if missing)"
if ! kind get clusters | grep -qx "$CLUSTER"; then
  kind create cluster --name "$CLUSTER"
else
  echo "kind cluster exists: $CLUSTER"
fi

say "1) Build local images (docker)"
OWNER="${OWNER:-local}"
TAG="${TAG:-dev}"
POL_IMG="pni-policy-svc:${TAG}"
HUB_IMG="pni-hub-ingest:${TAG}"
EDGE_IMG="pni-edge-agent:${TAG}"
MOSQ_IMG="eclipse-mosquitto:2"

# Generic Go build image via docker build args
cat > Dockerfile.pni-service.k8s <<'EOF'
# syntax=docker/dockerfile:1
ARG GO_VERSION=1.22
FROM golang:${GO_VERSION}-alpine AS builder
RUN apk add --no-cache git ca-certificates
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY . .
ARG SERVICE
RUN CGO_ENABLED=0 GOOS=linux go build -o /out/app ./cmd/${SERVICE}

FROM alpine:3.20
RUN apk add --no-cache ca-certificates tzdata
WORKDIR /app
COPY --from=builder /out/app /app/app
USER 65532:65532
ENTRYPOINT ["/app/app"]
EOF

docker build -f Dockerfile.pni-service.k8s --build-arg SERVICE=policy-svc -t "$POL_IMG" .
docker build -f Dockerfile.pni-service.k8s --build-arg SERVICE=hub-ingest -t "$HUB_IMG" .
docker build -f Dockerfile.pni-service.k8s --build-arg SERVICE=edge-agent -t "$EDGE_IMG" .

say "2) Load images into kind"
kind load docker-image --name "$CLUSTER" "$POL_IMG" "$HUB_IMG" "$EDGE_IMG" "$MOSQ_IMG" || true

say "3) Apply Kubernetes manifests"
# Patch images + device id into a temp overlay
TMP="$(mktemp -d)"
cp -R deploy/k8s/base "$TMP/base"
python3 - <<PY
import os, re
base = os.path.join("$TMP","base")
repls = {
  "__POLICY_IMAGE__": "$POL_IMG",
  "__HUB_IMAGE__": "$HUB_IMG",
  "__EDGE_IMAGE__": "$EDGE_IMG",
  "__DEVICE_ID__": "$DEVICE_ID",
}
for fn in os.listdir(base):
  p=os.path.join(base,fn)
  if not os.path.isfile(p): 
    continue
  s=open(p,"r",encoding="utf-8").read()
  for k,v in repls.items():
    s=s.replace(k,v)
  open(p,"w",encoding="utf-8").write(s)
PY

kubectl create namespace "$NS" >/dev/null 2>&1 || true
kubectl -n "$NS" apply -f "$TMP/base"

say "4) Wait for pods ready"
kubectl -n "$NS" rollout status deploy/pni-mosquitto --timeout=180s
kubectl -n "$NS" rollout status deploy/pni-policy-svc --timeout=180s
kubectl -n "$NS" rollout status deploy/pni-hub-ingest --timeout=180s
kubectl -n "$NS" rollout status deploy/pni-edge-agent --timeout=180s

say "5) Logs checks (best-effort)"
kubectl -n "$NS" logs deploy/pni-hub-ingest --tail=200 | grep -Eni 'telemetry.*ok|telemetry|ingest|accepted' | tail -n 20 || true
kubectl -n "$NS" logs deploy/pni-edge-agent --tail=200 | grep -Eni 'applied|apply|accepted|command|signature|policy' | tail -n 30 || true

say "6) Publish command (runs from your Mac -> cluster via port-forward)"
if [ -d cmd/command-cli ]; then
  mkdir -p bin
  go build -o ./bin/command-cli ./cmd/command-cli
  # Port-forward mosquitto and policy-svc to localhost
  kubectl -n "$NS" port-forward svc/pni-mosquitto 8883:8883 >/dev/null 2>&1 & echo $! > logs/pf_mosq.pid
  kubectl -n "$NS" port-forward svc/pni-policy-svc 9443:9443 >/dev/null 2>&1 & echo $! > logs/pf_pol.pid
  sleep 2
  MQTT_URL="tls://127.0.0.1:8883" POLICY_URL="https://127.0.0.1:9443" POLICY_SVC_URL="https://127.0.0.1:9443" \
    ./bin/command-cli -issuer truDat -device "$DEVICE_ID" -cmd set_publish_interval_ms -params '{"value":1000}' || true
  # cleanup port-forwards
  kill "$(cat logs/pf_mosq.pid)" "$(cat logs/pf_pol.pid)" >/dev/null 2>&1 || true
fi

say "DONE (k8s)"
echo "Inspect: kubectl -n $NS get pods -o wide"
