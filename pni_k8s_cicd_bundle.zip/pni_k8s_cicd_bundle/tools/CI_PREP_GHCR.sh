\
#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
==> GHCR CI setup (one time)

1) Make your repo public OR (recommended) keep private and enable:
   Settings → Actions → General → Workflow permissions → Read and write permissions
   Settings → Actions → General → Allow GitHub Actions to create and approve pull requests (optional)
   Settings → Packages → Ensure GHCR is enabled

2) Ensure your workflow can push to GHCR:
   - The included workflow uses GITHUB_TOKEN with packages:write
   - No extra secrets needed for GHCR in the same org/user

3) Optional image signing (cosign):
   - Set secret: COSIGN_PRIVATE_KEY (base64 key) and COSIGN_PASSWORD
   - Or use keyless signing (OIDC) with cosign (advanced)

4) Push a commit. CI will publish images to:
   ghcr.io/<owner>/<repo>-policy-svc:sha-<...>
   ghcr.io/<owner>/<repo>-hub-ingest:sha-<...>
   ghcr.io/<owner>/<repo>-edge-agent:sha-<...>

EOF
