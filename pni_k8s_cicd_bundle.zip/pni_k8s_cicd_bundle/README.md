# PNI K8S + CI/CD Bundle (the actual “next step” after Docker-portable)

You already have:
- dockerized services
- a portable docker zip (compose + images tar + RUN_PORTABLE.sh)

Next step = “production-grade done”:
1) **CI builds & publishes images** (GHCR) + SBOM + optional signing
2) **Kubernetes deploy** (kind for local, then any cluster)
3) One-go local k8s smoke deploy with log checks

This bundle adds:
- GitHub Actions workflows for build/push (GHCR) and deploy
- Kubernetes manifests (base) + a minimal Helm chart
- One-go scripts:
  - `tools/KIND_ONE_GO.sh` (local k8s run)
  - `tools/CI_PREP_GHCR.sh` (prints the exact repo settings you need)
  - `tools/INSTALL_INTO_REPO.sh`

## Install into your repo
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_k8s_cicd_bundle
unzip -o ~/Downloads/pni_k8s_cicd_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_k8s_cicd_bundle/tools/INSTALL_INTO_REPO.sh
```

## Local Kubernetes “done” (one command)
```bash
cd ~/Downloads/pni
bash tools/KIND_ONE_GO.sh
```

## CI/CD “done” (GHCR)
- Commit + push: workflows build and publish images to GHCR
- Deploy via Helm or kubectl apply using your cluster credentials

See docs in `docs/`.
