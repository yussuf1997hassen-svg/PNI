# What is “next” after Docker portable?

This is the production “done” checklist:

1) **Kubernetes** deployment (local kind first, then any cluster)
2) **CI builds and publishes images** to a registry (GHCR)
3) Optional hardening:
   - SBOM (syft) + vulnerability scanning (trivy)
   - Image signing (cosign)
   - Observability (Prometheus/Grafana)
   - Secret management (sealed-secrets / external-secrets)

This bundle gives you (1) and (2) immediately.
