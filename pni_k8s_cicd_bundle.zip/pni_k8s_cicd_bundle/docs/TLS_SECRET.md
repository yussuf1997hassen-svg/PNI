# TLS secret for mosquitto in Kubernetes

The k8s manifests expect a Secret named `pni-mosquitto-tls` with:
- ca.crt
- server.crt
- server.key

Create it from your local cert directory (example):

```bash
kubectl -n pni create secret generic pni-mosquitto-tls   --from-file=ca.crt=/path/to/ca.crt   --from-file=server.crt=/path/to/server.crt   --from-file=server.key=/path/to/server.key
```

If your base repo already has mosquitto TLS assets, point to those file paths.
