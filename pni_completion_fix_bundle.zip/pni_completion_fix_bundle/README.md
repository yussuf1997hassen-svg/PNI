PNI Completion Fix Bundle (Mac + Docker Desktop)

Purpose
- Fix Docker Desktop "error while creating mount source path" by removing host bind-mounts for policy-svc registry.
- Start the full stack (mosquitto + policy-svc + hub-ingest + edge-agent) with DEVICE_ID=truDat.
- Publish a signed command as issuer truDat via command-cli and confirm edge-agent sees it.

How to use (copy/paste only the NON-comment lines)
1) Unzip:
   unzip ~/Downloads/pni_completion_fix_bundle.zip -d ~/Downloads

2) Install tools into your repo root:
   cd ~/Downloads/pni
   bash ~/Downloads/pni_completion_fix_bundle/tools/INSTALL_INTO_REPO.sh

3) Run everything (one command):
   bash tools/ONE_GO_FIX_RUN_PUBLISH.sh

Notes
- This does NOT change your existing source code; it only adds/updates Docker helper files:
  - Dockerfile.pni-service
  - docker-compose.pni-services.yml
  - tools/ONE_GO_FIX_RUN_PUBLISH.sh
