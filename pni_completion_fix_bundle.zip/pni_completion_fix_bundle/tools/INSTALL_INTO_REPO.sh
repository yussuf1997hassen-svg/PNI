#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="$(pwd)"

if [ ! -f "$REPO_DIR/go.mod" ]; then
  echo "ERROR: Run this from your repo root (where go.mod is)."
  echo "Example:"
  echo "  cd ~/Downloads/pni"
  echo "  bash $SRC_DIR/tools/INSTALL_INTO_REPO.sh"
  exit 1
fi

mkdir -p "$REPO_DIR/tools"
cp -f "$SRC_DIR/tools/ONE_GO_FIX_RUN_PUBLISH.sh" "$REPO_DIR/tools/ONE_GO_FIX_RUN_PUBLISH.sh"
chmod +x "$REPO_DIR/tools/ONE_GO_FIX_RUN_PUBLISH.sh"
echo "OK: installed tools/ONE_GO_FIX_RUN_PUBLISH.sh into $(pwd)"
