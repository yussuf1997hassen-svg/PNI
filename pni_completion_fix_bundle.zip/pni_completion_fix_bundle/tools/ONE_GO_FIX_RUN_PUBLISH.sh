\
#!/usr/bin/env bash
set -euo pipefail

say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }
die(){ printf "\nERROR: %s\n" "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

need docker
need go
need python3
need sed
need awk

docker version >/dev/null 2>&1 || die "Docker not running (start Docker Desktop)"
docker compose version >/dev/null 2>&1 || die "docker compose missing"

# You MUST run from repo root (go.mod present)
[ -f go.mod ] || die "Run from repo root (where go.mod is)."

# Detect compose base file
COMPOSE_BASE="$(ls -1 docker-compose.yml docker-compose.yaml compose.yml compose.yaml 2>/dev/null | head -n 1 || true)"
[ -n "${COMPOSE_BASE:-}" ] || die "No compose file found in repo root (docker-compose.yml)."

# Detect mosquitto service name
MOSQ_SVC="$(docker compose -f "$COMPOSE_BASE" config --services 2>/dev/null | grep -i mosquitto | head -n 1 || true)"
[ -z "${MOSQ_SVC:-}" ] && MOSQ_SVC="mosquitto"

say "0) Clean up old containers for this stack"
docker compose -f "$COMPOSE_BASE" down --remove-orphans >/dev/null 2>&1 || true
docker rm -f "$(docker ps -aq --filter "name=trudat-mosquitto" 2>/dev/null)" >/dev/null 2>&1 || true
docker rm -f "$(docker ps -aq --filter "name=pni-" 2>/dev/null)" >/dev/null 2>&1 || true

say "1) Sanity check required files"
[ -f registry.json ] || die "registry.json missing in repo root."
echo "OK: registry.json present"
grep -q "truDat" registry.json && echo "OK: registry mentions truDat" || warn "registry.json does NOT mention truDat (issuer ACL may block publish)."

# Ensure mosquitto folders exist if compose uses them
mkdir -p mosquitto mosquitto/config mosquitto/data mosquitto/log mosquitto/certs >/dev/null 2>&1 || true

say "2) Ensure Dockerfile.pni-service exists (builds Go cmd/<service>)"
if [ ! -f Dockerfile.pni-service ]; then
cat > Dockerfile.pni-service <<'EOF'
# syntax=docker/dockerfile:1
ARG GO_VERSION=1.22
FROM golang:${GO_VERSION}-alpine AS builder
RUN apk add --no-cache git ca-certificates
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY . .
ARG SERVICE
RUN CGO_ENABLED=0 GOOS=linux go build -o /out/app ./cmd/${SERVICE}

FROM alpine:3.20
RUN apk add --no-cache ca-certificates tzdata
WORKDIR /app
COPY --from=builder /out/app /app/app
COPY registry.json /app/registry.json
USER 65532:65532
ENTRYPOINT ["/app/app"]
EOF
fi

# Patch Dockerfile to ALWAYS include registry.json in runtime stage (avoids bind mount)
if ! grep -q '^COPY registry\.json /app/registry\.json$' Dockerfile.pni-service; then
  say "Patch Dockerfile.pni-service to embed registry.json (no host mount)"
  # Insert right before USER line (or append if missing)
  if grep -q '^USER ' Dockerfile.pni-service; then
    python3 - <<'PY'
import re
p="Dockerfile.pni-service"
s=open(p,"r",encoding="utf-8").read().splitlines()
out=[]
inserted=False
for line in s:
    if (not inserted) and line.startswith("USER "):
        out.append("COPY registry.json /app/registry.json")
        inserted=True
    out.append(line)
if not inserted:
    out.append("COPY registry.json /app/registry.json")
open(p,"w",encoding="utf-8").write("\n".join(out)+"\n")
PY
  else
    echo "COPY registry.json /app/registry.json" >> Dockerfile.pni-service
  fi
fi

say "3) Create/patch docker-compose.pni-services.yml (no host bind mounts)"
POLICY_FLAG=""
POLICY_HELP="$((go run ./cmd/policy-svc --help 2>/dev/null || true); (go run ./cmd/policy-svc -h 2>/dev/null || true)) | head -n 200 || true"
if echo "$POLICY_HELP" | grep -Eq -- "-addr(\s|$)"; then
  POLICY_FLAG="-addr 0.0.0.0:9443"
elif echo "$POLICY_HELP" | grep -Eq -- "-listen(\s|$)"; then
  POLICY_FLAG="-listen 0.0.0.0:9443"
else
  warn "Could not detect policy-svc bind flag; proceeding without explicit bind (might listen 127.0.0.1 inside container)."
fi

cat > docker-compose.pni-services.yml <<EOF
services:
  policy-svc:
    build:
      context: .
      dockerfile: Dockerfile.pni-service
      args:
        SERVICE: policy-svc
    working_dir: /app
    environment:
      - DEVICE_ID=truDat
      - MQTT_URL=tls://${MOSQ_SVC}:8883
      - POLICY_URL=https://policy-svc:9443
      - POLICY_SVC_URL=https://policy-svc:9443
    ports:
      - "9443:9443"
    restart: unless-stopped

  hub-ingest:
    build:
      context: .
      dockerfile: Dockerfile.pni-service
      args:
        SERVICE: hub-ingest
    working_dir: /app
    environment:
      - DEVICE_ID=truDat
      - MQTT_URL=tls://${MOSQ_SVC}:8883
      - POLICY_URL=https://policy-svc:9443
      - POLICY_SVC_URL=https://policy-svc:9443
    depends_on:
      - policy-svc
    restart: unless-stopped

  edge-agent:
    build:
      context: .
      dockerfile: Dockerfile.pni-service
      args:
        SERVICE: edge-agent
    working_dir: /app
    environment:
      - DEVICE_ID=truDat
      - MQTT_URL=tls://${MOSQ_SVC}:8883
      - POLICY_URL=https://policy-svc:9443
      - POLICY_SVC_URL=https://policy-svc:9443
    depends_on:
      - policy-svc
    restart: unless-stopped
EOF

# Insert policy bind command if detectable
if [ -n "${POLICY_FLAG:-}" ]; then
  say "Inject policy-svc bind command: $POLICY_FLAG"
  python3 - <<PY
p="docker-compose.pni-services.yml"
a,b = "$POLICY_FLAG".split()
lines=open(p,"r",encoding="utf-8").read().splitlines()
out=[]
in_policy=False
inserted=False
for l in lines:
    if l.strip()=="policy-svc:":
        in_policy=True
    if in_policy and l.strip().startswith("working_dir:") and (not inserted):
        out.append(l)
        out.append(f'    command: ["/app/app", "{a}", "{b}"]')
        inserted=True
        continue
    out.append(l)
open(p,"w",encoding="utf-8").write("\n".join(out)+"\n")
PY
fi

say "4) Bring up full stack in Docker (build if needed)"
set +e
docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml up -d --build "$MOSQ_SVC" policy-svc hub-ingest edge-agent
RC=$?
set -e
if [ "$RC" -ne 0 ]; then
  warn "docker compose up failed (RC=$RC). Showing last 120 lines of daemon logs + compose config hints:"
  docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml config | sed -n '1,220p' || true
  die "Compose failed. The common cause on Mac is missing bind-mount sources in your *base* compose (mosquitto config/certs paths). Ensure ./mosquitto/... paths exist."
fi

docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml ps

say "5) Wait for ports 8883 and 9443 locally"
for i in $(seq 1 40); do
  if nc -z 127.0.0.1 9443 >/dev/null 2>&1; then break; fi
  sleep 0.25
done
nc -z 127.0.0.1 9443 >/dev/null 2>&1 && echo "OK: policy-svc port 9443 open" || warn "policy-svc port 9443 not open (yet)"

for i in $(seq 1 40); do
  if nc -z 127.0.0.1 8883 >/dev/null 2>&1; then break; fi
  sleep 0.25
done
nc -z 127.0.0.1 8883 >/dev/null 2>&1 && echo "OK: mosquitto port 8883 open" || warn "mosquitto port 8883 not open (yet)"

say "6) Show logs (look for telemetry OK and command apply)"
docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml logs --tail=120 policy-svc hub-ingest edge-agent || true

say "7) Build command-cli (if present) and publish as truDat"
if [ -d cmd/command-cli ]; then
  mkdir -p bin
  go build -o ./bin/command-cli ./cmd/command-cli

  echo "command-cli --help:"
  ./bin/command-cli --help | sed -n '1,120p' || true

  # Try common env vars. Extra env vars won't hurt if unused.
  MQTT_URL="tls://127.0.0.1:8883" \
  POLICY_URL="https://127.0.0.1:9443" \
  POLICY_SVC_URL="https://127.0.0.1:9443" \
  TLS_INSECURE_SKIP_VERIFY="true" \
  INSECURE_SKIP_VERIFY="true" \
  ISSUER="truDat" \
  DEVICE_ID="truDat" \
  ./bin/command-cli -issuer truDat -device truDat -cmd set_publish_interval_ms -params '{"value":1000}' || true
else
  warn "cmd/command-cli not found; skipping publish test."
fi

say "8) Confirm edge-agent received/applied (best-effort grep)"
docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml logs --tail=220 edge-agent | egrep -i "apply|applied|command|set_publish_interval|interval|ack|accepted|ok" || true

say "DONE"
echo "If publish was rejected, open registry.json and confirm issuer 'truDat' pubkey is registered + allowed for device 'truDat' topics."
