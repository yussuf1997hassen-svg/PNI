Docker Desktop mount source path errors (Mac)
- If you see: "error while creating mount source path ..."
  It almost always means Docker is trying to bind-mount a host path that does not exist or is not shared.

What this bundle changes
- policy-svc no longer bind-mounts ./registry.json.
- registry.json is embedded into the policy-svc image at build time.

If you STILL see mount errors
- They are coming from your base docker-compose.yml (usually mosquitto bind mounts).
- Ensure these exist in your repo root (create folders if missing):
  - ./mosquitto/config
  - ./mosquitto/certs
  - ./mosquitto/data
  - ./mosquitto/log

Then run again:
  bash tools/ONE_GO_FIX_RUN_PUBLISH.sh
