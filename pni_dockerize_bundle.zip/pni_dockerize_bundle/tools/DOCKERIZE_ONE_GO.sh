#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }
die(){ printf "\nERROR: %s\n" "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

need docker
need go
need python3

docker version >/dev/null 2>&1 || die "Docker not running (start Docker Desktop)"
docker compose version >/dev/null 2>&1 || die "docker compose missing"

COMPOSE_BASE="$(ls -1 docker-compose.yml docker-compose.yaml compose.yml compose.yaml 2>/dev/null | head -n 1 || true)"
[ -n "${COMPOSE_BASE:-}" ] || die "No compose file found in repo root."

MOSQ_SVC="$(docker compose -f "$COMPOSE_BASE" config --services 2>/dev/null | grep -i mosquitto | head -n 1 || true)"
[ -z "${MOSQ_SVC:-}" ] && MOSQ_SVC="mosquitto"

POLICY_FLAG=""
POLICY_HELP="$((go run ./cmd/policy-svc --help 2>/dev/null || true); (go run ./cmd/policy-svc -h 2>/dev/null || true) ) | head -n 200 || true"
if echo "$POLICY_HELP" | grep -Eq -- "-addr(\s|$)"; then
  POLICY_FLAG="-addr 0.0.0.0:9443"
elif echo "$POLICY_HELP" | grep -Eq -- "-listen(\s|$)"; then
  POLICY_FLAG="-listen 0.0.0.0:9443"
else
  warn "Could not detect policy-svc bind flag. If it binds to 127.0.0.1 inside container, it will be unreachable."
fi

say "Generate Dockerfile.pni-service + docker-compose.pni-services.yml"
python3 - <<'PY'
import textwrap

dockerfile = textwrap.dedent("""# syntax=docker/dockerfile:1
ARG GO_VERSION=1.22
FROM golang:${GO_VERSION}-alpine AS builder
RUN apk add --no-cache git ca-certificates
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY . .
ARG SERVICE
RUN CGO_ENABLED=0 GOOS=linux go build -o /out/app ./cmd/${SERVICE}

FROM alpine:3.20
RUN apk add --no-cache ca-certificates tzdata
WORKDIR /app
COPY --from=builder /out/app /app/app
USER 65532:65532
ENTRYPOINT ["/app/app"]
""")
open("Dockerfile.pni-service","w",encoding="utf-8").write(dockerfile)

compose = textwrap.dedent("""services:
  policy-svc:
    build:
      context: .
      dockerfile: Dockerfile.pni-service
      args:
        SERVICE: policy-svc
    working_dir: /app
    volumes:
      - ./registry.json:/app/registry.json:ro
    environment:
      - DEVICE_ID=truDat
      - MQTT_URL=tls://mosquitto:8883
      - POLICY_URL=https://policy-svc:9443
      - POLICY_SVC_URL=https://policy-svc:9443
    ports:
      - "9443:9443"
    restart: unless-stopped

  hub-ingest:
    build:
      context: .
      dockerfile: Dockerfile.pni-service
      args:
        SERVICE: hub-ingest
    working_dir: /app
    environment:
      - DEVICE_ID=truDat
      - MQTT_URL=tls://mosquitto:8883
      - POLICY_URL=https://policy-svc:9443
      - POLICY_SVC_URL=https://policy-svc:9443
    depends_on:
      - policy-svc
    restart: unless-stopped

  edge-agent:
    build:
      context: .
      dockerfile: Dockerfile.pni-service
      args:
        SERVICE: edge-agent
    working_dir: /app
    environment:
      - DEVICE_ID=truDat
      - MQTT_URL=tls://mosquitto:8883
      - POLICY_URL=https://policy-svc:9443
      - POLICY_SVC_URL=https://policy-svc:9443
    depends_on:
      - policy-svc
    restart: unless-stopped
""")
open("docker-compose.pni-services.yml","w",encoding="utf-8").write(compose)
PY

if [ "$MOSQ_SVC" != "mosquitto" ]; then
  say "Patch override MQTT_URL host from mosquitto -> $MOSQ_SVC"
  python3 - <<PY
p="docker-compose.pni-services.yml"
s=open(p,"r",encoding="utf-8").read().replace("tls://mosquitto:8883","tls://$MOSQ_SVC:8883")
open(p,"w",encoding="utf-8").write(s)
PY
fi

if [ -n "${POLICY_FLAG:-}" ]; then
  say "Insert policy-svc command: $POLICY_FLAG"
  python3 - <<PY
p="docker-compose.pni-services.yml"
lines=open(p,"r",encoding="utf-8").read().splitlines()
out=[]
inserted=False
in_policy=False
for l in lines:
  if l.strip()=="policy-svc:":
    in_policy=True
  if in_policy and (l.strip()=="hub-ingest:" or l.strip()=="edge-agent:"):
    in_policy=False
  if in_policy and l.strip().startswith("ports:") and not inserted:
    a,b = "$POLICY_FLAG".split()
    out.append(f'    command: ["/app/app", "{a}", "{b}"]')
    inserted=True
  out.append(l)
open(p,"w",encoding="utf-8").write("\n".join(out)+"\n")
PY
fi

say "Build + run full stack in Docker"
docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml up -d --build "$MOSQ_SVC" policy-svc hub-ingest edge-agent
docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml ps

say "Show logs (last 120 lines)"
docker compose -f "$COMPOSE_BASE" -f docker-compose.pni-services.yml logs --tail=120 hub-ingest edge-agent policy-svc || true

say "Publish test command (command-cli locally -> containers via published ports)"
if [ -d cmd/command-cli ]; then
  mkdir -p bin
  go build -o ./bin/command-cli ./cmd/command-cli
  MQTT_URL="tls://127.0.0.1:8883" POLICY_URL="https://127.0.0.1:9443" POLICY_SVC_URL="https://127.0.0.1:9443" \
    ./bin/command-cli -issuer truDat -device truDat -cmd set_publish_interval_ms -params '{"value":1000}' || true
fi

say "DONE"
echo "If policy-svc is unreachable, edit docker-compose.pni-services.yml and set policy-svc command to bind 0.0.0.0:9443."
