#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }
mkdir -p "$REPO_DIR/tools"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true
echo "Installed into: $REPO_DIR"
echo "Run: cd ~/Downloads/pni && bash tools/DOCKERIZE_ONE_GO.sh"
