# PNI Dockerize Bundle (run policy-svc + hub-ingest + edge-agent in Docker)

You do not “unzip into Docker”.
You unzip on your Mac, then you build Docker images from your repo and run them with docker compose.

This bundle adds a single script that:
- generates a generic Go-service Dockerfile
- generates a compose override for policy-svc, hub-ingest, edge-agent
- tries to auto-detect the policy-svc bind flag (-addr or -listen)
- starts the full stack in Docker and prints logs

Install into your repo:
1) unzip this zip to ~/Downloads
2) run the installer
3) run DOCKERIZE_ONE_GO.sh

Commands:

```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_dockerize_bundle
unzip -o ~/Downloads/pni_dockerize_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_dockerize_bundle/tools/INSTALL_INTO_REPO.sh
bash tools/DOCKERIZE_ONE_GO.sh
```
