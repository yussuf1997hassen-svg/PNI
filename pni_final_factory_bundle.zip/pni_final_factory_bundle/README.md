# PNI FINAL FACTORY Bundle (one command produces the single “DONE.zip” that contains everything)

You asked for:
- “the end of the steps … all at once … in one zip containing the entirety.”

I can’t directly package your private repo from here, so this bundle gives you ONE command that **builds the final all-in-one zip on your Mac**.

What the final zip contains (best-effort):
- Latest repo export zip (TOTAL_EXPORT)  -> dist/pni_total_export_*.zip
- Latest docker portable zip (DOCKER_PORTABLE_ONE_GO) -> dist/pni_docker_portable_*.zip
- Kubernetes manifests (deploy/k8s) + Helm chart (deploy/helm) if present
- CI workflows (.github/workflows) if present
- Tools + docs directories
- A MANIFEST.json with SHA256 sums

## Install into your repo
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_final_factory_bundle
unzip -o ~/Downloads/pni_final_factory_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_final_factory_bundle/tools/INSTALL_INTO_REPO.sh
```

## Produce the single final zip (ONE command)
```bash
cd ~/Downloads/pni
bash tools/FINAL_FACTORY_ONE_GO.sh
```

Output:
- dist/pni_DONE_<timestamp>.zip
- also copied to ~/Downloads/pni_DONE_<timestamp>.zip
