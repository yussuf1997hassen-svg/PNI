\
#!/usr/bin/env bash
set -euo pipefail

say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }
die(){ printf "\nERROR: %s\n" "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

need zip
need shasum
need python3

STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p dist logs

say "0) Create latest repo export zip (if TOTAL_EXPORT exists)"
if [ -f tools/TOTAL_EXPORT.sh ]; then
  bash tools/TOTAL_EXPORT.sh
else
  warn "tools/TOTAL_EXPORT.sh not found; skipping repo export."
fi

say "1) Create latest docker portable zip (if DOCKER_PORTABLE exists)"
if [ -f tools/DOCKER_PORTABLE_ONE_GO.sh ]; then
  bash tools/DOCKER_PORTABLE_ONE_GO.sh
else
  warn "tools/DOCKER_PORTABLE_ONE_GO.sh not found; skipping docker portable."
fi

say "2) Collect latest artifacts"
LATEST_EXPORT="$(ls -1t dist/pni_total_export_*.zip 2>/dev/null | head -n 1 || true)"
LATEST_DOCKER_PORTABLE="$(ls -1t dist/pni_docker_portable_*.zip 2>/dev/null | head -n 1 || true)"

OUTDIR="dist/.done_${STAMP}"
rm -rf "$OUTDIR"
mkdir -p "$OUTDIR/artifacts" "$OUTDIR/repo_meta"

if [ -n "${LATEST_EXPORT:-}" ]; then cp -f "$LATEST_EXPORT" "$OUTDIR/artifacts/" || true; fi
if [ -n "${LATEST_DOCKER_PORTABLE:-}" ]; then cp -f "$LATEST_DOCKER_PORTABLE" "$OUTDIR/artifacts/" || true; fi

# Copy deploy + workflows + docs + tools
[ -d deploy ] && rsync -a deploy/ "$OUTDIR/deploy/" 2>/dev/null || true
[ -d .github/workflows ] && rsync -a .github/workflows/ "$OUTDIR/.github/workflows/" 2>/dev/null || true
[ -d docs ] && rsync -a docs/ "$OUTDIR/docs/" 2>/dev/null || true
[ -d tools ] && rsync -a tools/ "$OUTDIR/tools/" 2>/dev/null || true

# Add basic repo info
git rev-parse HEAD > "$OUTDIR/repo_meta/git_commit.txt" 2>/dev/null || echo "no-git" > "$OUTDIR/repo_meta/git_commit.txt"
date > "$OUTDIR/repo_meta/built_at.txt"

say "3) Build MANIFEST.json with sha256 sums"
python3 - <<'PY'
import os, json, hashlib, pathlib, time
outdir = os.environ.get("OUTDIR")
def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

files=[]
for base, _, fs in os.walk(outdir):
    for fn in fs:
        p=os.path.join(base, fn)
        rel=os.path.relpath(p, outdir)
        # skip manifest itself (will compute later if desired)
        if rel=="MANIFEST.json":
            continue
        files.append({"path": rel, "sha256": sha256(p), "bytes": os.path.getsize(p)})
manifest = {
    "name": "pni_DONE",
    "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "files": sorted(files, key=lambda x:x["path"]),
}
with open(os.path.join(outdir, "MANIFEST.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)
PY

say "4) Create the single DONE zip"
OUTZIP="dist/pni_DONE_${STAMP}.zip"
( cd "$OUTDIR" && zip -r "$ROOT/$OUTZIP" . >/dev/null )
rm -rf "$OUTDIR"

cp -f "$OUTZIP" "$HOME/Downloads/" 2>/dev/null || true

echo "OK: $OUTZIP"
echo "COPIED: $HOME/Downloads/$(basename "$OUTZIP")"
echo "SHA256:"
shasum -a 256 "$OUTZIP"
