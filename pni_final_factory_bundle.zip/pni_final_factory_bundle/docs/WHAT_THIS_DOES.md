This bundle produces a single dist/pni_DONE_<timestamp>.zip by composing other artifacts and repo config.
