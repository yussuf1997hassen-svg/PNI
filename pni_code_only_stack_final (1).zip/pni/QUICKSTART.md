# PNI — Completion (issuer pubkey already in hand)

## Single command “completion”
Replace `<PUBKEY_B64>` with the issuer pubkey you already got:

```bash
cd ~/Downloads
unzip -o pni_code_only_stack_final.zip
cd pni
bash scripts/complete.sh <PUBKEY_B64>
```

## What “complete” means here
- policy-svc, hub-ingest, edge-agent all running
- MQTT broker running via Docker
- registry patched so **signed commands are accepted**
- edge-agent auto-refreshes policy via POLICY_MODE=watch
