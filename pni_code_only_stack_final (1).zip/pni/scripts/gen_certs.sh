#!/usr/bin/env bash
set -euo pipefail

mkdir -p certs/ca certs/mosquitto certs/clients certs/policy

echo "[1/5] CA"
if [[ ! -f certs/ca/ca.key ]]; then
  openssl genrsa -out certs/ca/ca.key 4096
fi
if [[ ! -f certs/ca/ca.crt ]]; then
  openssl req -x509 -new -nodes -key certs/ca/ca.key -sha256 -days 3650     -subj "/CN=pni-ca"     -out certs/ca/ca.crt
fi

echo "[2/5] Mosquitto server cert (SAN localhost/127.0.0.1)"
openssl genrsa -out certs/mosquitto/server.key 2048
openssl req -new -key certs/mosquitto/server.key -subj "/CN=localhost" -out certs/mosquitto/server.csr

openssl x509 -req -in certs/mosquitto/server.csr -CA certs/ca/ca.crt -CAkey certs/ca/ca.key -CAcreateserial   -out certs/mosquitto/server.crt -days 825 -sha256   -extfile <(printf "subjectAltName=DNS:localhost,IP:127.0.0.1")

rm -f certs/mosquitto/server.csr

make_client () {
  local name="$1"
  echo "  - client cert: $name"
  openssl genrsa -out "certs/clients/${name}.key" 2048
  openssl req -new -key "certs/clients/${name}.key" -subj "/CN=${name}" -out "certs/clients/${name}.csr"
  openssl x509 -req -in "certs/clients/${name}.csr" -CA certs/ca/ca.crt -CAkey certs/ca/ca.key -CAcreateserial     -out "certs/clients/${name}.crt" -days 825 -sha256
  rm -f "certs/clients/${name}.csr"
}

echo "[3/5] MQTT client certs"
make_client "dre-001"
make_client "dre-002"
make_client "hub"

echo "[4/5] Policy service cert (CN=policy-svc, SAN localhost/127.0.0.1)"
openssl genrsa -out certs/policy/policy.key 2048
openssl req -new -key certs/policy/policy.key -subj "/CN=policy-svc" -out certs/policy/policy.csr
openssl x509 -req -in certs/policy/policy.csr   -CA certs/ca/ca.crt -CAkey certs/ca/ca.key -CAcreateserial   -out certs/policy/policy.crt -days 825 -sha256   -extfile <(printf "subjectAltName=DNS:localhost,IP:127.0.0.1")
rm -f certs/policy/policy.csr

echo "[5/5] Done"
echo "CA: certs/ca/ca.crt"
echo "Mosquitto server: certs/mosquitto/server.crt"
echo "Clients: certs/clients/*.crt"
echo "Policy svc: certs/policy/policy.crt"
