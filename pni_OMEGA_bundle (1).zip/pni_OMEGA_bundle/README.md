# PNI OMEGA Bundle (the final “entirety” pack)

This contains ALL bundles (including TOTAL_EXPORT) and provides:
- **INSTALL_ALL_INTO_REPO.sh**: merges everything into `~/Downloads/pni/tools/`
- **RUN_OMEGA_ONE_GO.sh**: runs end-to-end and then creates your *actual repo export zip*

Included bundles (9):
- bundles/pni_onego_bundle.zip
- bundles/pni_ultimate_bundle.zip
- bundles/pni_everything_bundle.zip
- bundles/pni_super_ultimate_bundle.zip
- bundles/pni_master_bundle.zip
- bundles/pni_release_factory_bundle.zip
- bundles/pni_ops_deploy_bundle.zip
- bundles/pni_total_export_bundle.zip
- bundles/pni_MEGA_bundle.zip

## 1) Install everything into your repo (one paste)
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_OMEGA_bundle
unzip -o ~/Downloads/pni_OMEGA_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_OMEGA_bundle/tools/INSTALL_ALL_INTO_REPO.sh
```

## 2) Run EVERYTHING + produce the true “entirety-of-entirety” zip (one command)
```bash
cd ~/Downloads/pni
bash tools/RUN_OMEGA_ONE_GO.sh
```

Output you will end with:
- `dist/pni_total_export_<timestamp>.zip`  (your full repo snapshot, built on your Mac)
