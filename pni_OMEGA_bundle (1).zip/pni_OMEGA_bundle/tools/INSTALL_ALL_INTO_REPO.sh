#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
OMEGA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUNDLES_DIR="$OMEGA_DIR/bundles"

[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }
[ -d "$BUNDLES_DIR" ] || { echo "ERROR: bundles dir not found at $BUNDLES_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/deploy" "$REPO_DIR/.github/workflows" "$REPO_DIR/dist" "$REPO_DIR/bin" "$REPO_DIR/logs"

tmp="$(mktemp -d)"
cleanup(){ rm -rf "$tmp" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "==> Installing ALL bundle contents into: $REPO_DIR"

for z in "$BUNDLES_DIR"/*.zip; do
  echo ""
  echo "==> Unpacking: $(basename "$z")"
  rm -rf "$tmp/unz" && mkdir -p "$tmp/unz"
  unzip -o "$z" -d "$tmp/unz" >/dev/null

  top="$(find "$tmp/unz" -maxdepth 1 -type d ! -path "$tmp/unz" | head -n 1 || true)"
  [ -z "${top:-}" ] && continue

  if [ -f "$top/tools/INSTALL_INTO_REPO.sh" ]; then
    REPO_DIR="$REPO_DIR" bash "$top/tools/INSTALL_INTO_REPO.sh" || true
    continue
  fi

  [ -d "$top/tools" ] && cp -R "$top/tools/"* "$REPO_DIR/tools/" 2>/dev/null || true
  [ -d "$top/docs" ] && cp -R "$top/docs/"* "$REPO_DIR/docs/" 2>/dev/null || true
  [ -d "$top/deploy" ] && rsync -a "$top/deploy/" "$REPO_DIR/deploy/" 2>/dev/null || true
  if [ -d "$top/.github/workflows" ]; then
    mkdir -p "$REPO_DIR/.github/workflows"
    cp -R "$top/.github/workflows/"* "$REPO_DIR/.github/workflows/" 2>/dev/null || true
  fi
  [ -f "$top/Makefile" ] && cp "$top/Makefile" "$REPO_DIR/Makefile" 2>/dev/null || true
  [ -f "$top/.env.example" ] && cp "$top/.env.example" "$REPO_DIR/.env.example" 2>/dev/null || true
done

chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo ""
echo "OK: installed. Next:"
echo "  cd ~/Downloads/pni"
echo "  bash tools/RUN_OMEGA_ONE_GO.sh"
