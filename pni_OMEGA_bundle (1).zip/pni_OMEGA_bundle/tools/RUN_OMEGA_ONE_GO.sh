#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }

say "0) Clean slate"
[ -f tools/STOP_ALL.sh ] && bash tools/STOP_ALL.sh || true

say "1) Run full stack + publish + verify"
if [ -f tools/DO_IT_ALL.sh ]; then
  bash tools/DO_IT_ALL.sh
elif [ -f tools/ONE_GO.sh ]; then
  bash tools/ONE_GO.sh
elif [ -f tools/ONE_GO_EVERYTHING.sh ]; then
  bash tools/ONE_GO_EVERYTHING.sh
elif [ -f tools/01_RUN_ALL.sh ]; then
  bash tools/01_RUN_ALL.sh
else
  warn "No runner found. Something didn't install to tools/."
fi

say "2) Ops (launchd + smoke)"
[ -f tools/OPS_ONE_GO.sh ] && bash tools/OPS_ONE_GO.sh || true

say "3) Produce the true “entirety” zip of your repo"
if [ -f tools/TOTAL_EXPORT.sh ]; then
  bash tools/TOTAL_EXPORT.sh
  Z="$(ls -1t dist/pni_total_export_*.zip 2>/dev/null | head -n 1 || true)"
  if [ -n "${Z:-}" ]; then
    cp -f "$Z" "$HOME/Downloads/" || true
    echo "FINAL ZIP: $HOME/Downloads/$(basename "$Z")"
    shasum -a 256 "$Z" | sed 's/^/SHA256: /'
  else
    warn "TOTAL_EXPORT ran but no dist/pni_total_export_*.zip found."
  fi
else
  warn "tools/TOTAL_EXPORT.sh not found (install total export bundle)."
fi

say "DONE"
