\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/token-testnet"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
cp -R "$SRC_DIR/token-testnet/"* "$REPO_DIR/token-testnet/"
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo "Installed STAGING+TESTNET bundle into: $REPO_DIR"
echo "Run ONE GO (no private keys pasted; use env vars):"
echo "  cd ~/Downloads/pni && ARBITRUM_SEPOLIA_RPC_URL='...' BASE_SEPOLIA_RPC_URL='...' DEPLOYER_PRIVATE_KEY='0x...' MINT_TOKENS=1000000 bash tools/TESTNET_DEPLOY_ONE_GO.sh"
