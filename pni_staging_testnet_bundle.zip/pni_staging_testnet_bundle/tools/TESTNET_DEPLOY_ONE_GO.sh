\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_st_common.sh

: "${ARBITRUM_SEPOLIA_RPC_URL:?Set ARBITRUM_SEPOLIA_RPC_URL}"
: "${BASE_SEPOLIA_RPC_URL:?Set BASE_SEPOLIA_RPC_URL}"
: "${DEPLOYER_PRIVATE_KEY:?Set DEPLOYER_PRIVATE_KEY (0x...)}"
MINT_TOKENS="${MINT_TOKENS:-1000000}"

say "0) Determine mint wallets (prefer dist/mint_receipt.json if present, else secrets/evm_wallet*_addr.txt)"
WALLET1="${WALLET1:-}"
WALLET2="${WALLET2:-}"

if [ -z "${WALLET1}" ] || [ -z "${WALLET2}" ]; then
  if [ -f dist/mint_receipt.json ]; then
    WALLET1="$(python3 - <<'PY'
import json
d=json.load(open("dist/mint_receipt.json"))
print(d.get("wallet1",""))
PY
)"
    WALLET2="$(python3 - <<'PY'
import json
d=json.load(open("dist/mint_receipt.json"))
print(d.get("wallet2",""))
PY
)"
  elif [ -f secrets/evm_wallet1_addr.txt ] && [ -f secrets/evm_wallet2_addr.txt ]; then
    WALLET1="$(cat secrets/evm_wallet1_addr.txt)"
    WALLET2="$(cat secrets/evm_wallet2_addr.txt)"
  fi
fi

[ -n "${WALLET1}" ] || die "Missing WALLET1 (0x...)"
[ -n "${WALLET2}" ] || die "Missing WALLET2 (0x...)"
echo "WALLET1=$WALLET1"
echo "WALLET2=$WALLET2"

say "1) Install deps inside Docker (Node 20)"
need docker
docker run --rm -v "$ROOT/token-testnet:/app" -w /app node:20-bullseye bash -lc 'npm -s install >/dev/null'

say "2) Compile"
docker run --rm -v "$ROOT/token-testnet:/app" -w /app node:20-bullseye bash -lc 'npx hardhat compile >/dev/null'

say "3) Deploy + mint on Arbitrum Sepolia (chainId 421614)"
docker run --rm \
  -e ARBITRUM_SEPOLIA_RPC_URL="$ARBITRUM_SEPOLIA_RPC_URL" \
  -e BASE_SEPOLIA_RPC_URL="$BASE_SEPOLIA_RPC_URL" \
  -e DEPLOYER_PRIVATE_KEY="$DEPLOYER_PRIVATE_KEY" \
  -e WALLET1="$WALLET1" -e WALLET2="$WALLET2" -e MINT_TOKENS="$MINT_TOKENS" \
  -v "$ROOT/token-testnet:/app" -v "$ROOT/dist:/app/../dist" \
  -w /app node:20-bullseye bash -lc 'npx hardhat run scripts/deploy_and_mint.js --network arbitrumSepolia'

say "4) Deploy + mint on Base Sepolia (chainId 84532)"
docker run --rm \
  -e ARBITRUM_SEPOLIA_RPC_URL="$ARBITRUM_SEPOLIA_RPC_URL" \
  -e BASE_SEPOLIA_RPC_URL="$BASE_SEPOLIA_RPC_URL" \
  -e DEPLOYER_PRIVATE_KEY="$DEPLOYER_PRIVATE_KEY" \
  -e WALLET1="$WALLET1" -e WALLET2="$WALLET2" -e MINT_TOKENS="$MINT_TOKENS" \
  -v "$ROOT/token-testnet:/app" -v "$ROOT/dist:/app/../dist" \
  -w /app node:20-bullseye bash -lc 'npx hardhat run scripts/deploy_and_mint.js --network baseSepolia'

say "5) Validate receipts show equal balances"
python3 - <<'PY'
import json,glob,sys
ok=True
for f in sorted(glob.glob("dist/testnet_receipt_*.json")):
  d=json.load(open(f))
  b1=int(d["balance1Wei"]); b2=int(d["balance2Wei"])
  if b1!=b2 or b1<=0:
    ok=False
    print("FAIL", f, "b1", b1, "b2", b2)
  else:
    print("OK", f, "contract", d["contract"])
if not ok: sys.exit(1)
PY

say "DONE ✅"
echo "Receipts:"
ls -1 dist/testnet_receipt_*.json
echo "Explorers:"
echo " - Arbitrum Sepolia: https://sepolia.arbiscan.io"
echo " - Base Sepolia: https://sepolia.basescan.org"
