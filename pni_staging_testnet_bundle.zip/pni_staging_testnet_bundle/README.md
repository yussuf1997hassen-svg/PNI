# STAGING + TESTNET next-step bundle

This is the *next SMART goal* after local DONE proofs:
- Deploy TruDAT token to **Arbitrum Sepolia** and **Base Sepolia**
- Mint equal amounts to your two 0x wallets
- Save receipts in `dist/`

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_staging_testnet_bundle
unzip -o ~/Downloads/pni_staging_testnet_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_staging_testnet_bundle/tools/INSTALL_INTO_REPO.sh
```

## ONE GO
```bash
cd ~/Downloads/pni
cp -n token-testnet/.env.example .env.testnet || true
# Fill .env.testnet with RPC URLs + DEPLOYER_PRIVATE_KEY (KEEP SECRET)
set -a; source .env.testnet; set +a
bash tools/TESTNET_DEPLOY_ONE_GO.sh
```
