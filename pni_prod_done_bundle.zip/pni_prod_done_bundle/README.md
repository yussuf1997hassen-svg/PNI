# PNI PROD-DONE Bundle (the actual final “done” layer)

You now have:
- Docker (compose + portable zip)
- Kubernetes (kind + base manifests)
- CI/CD (GHCR build/push)

**Next step = Production DONE:**
1) Observability (metrics + dashboards + alerts) via Prometheus/Grafana
2) Security hardening: SBOM + vuln scan + optional image signing
3) Automated smoke checks in CI

This bundle adds:
- `tools/PROD_DONE_ONE_GO.sh` : installs monitoring stack in your k8s cluster (kind or real), and runs checks
- GitHub Actions:
  - `security-scan.yml` : trivy scan + (optional) syft SBOM
  - `cosign-sign.yml` : optional image signing (keyless OIDC or key-based)

## Install into your repo
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_prod_done_bundle
unzip -o ~/Downloads/pni_prod_done_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_prod_done_bundle/tools/INSTALL_INTO_REPO.sh
```

## Run production-done setup (ONE command)
```bash
cd ~/Downloads/pni
bash tools/PROD_DONE_ONE_GO.sh
```

Notes:
- This uses `helm` to install `kube-prometheus-stack` and `loki-stack` into a `monitoring` namespace.
- If helm is missing, the script tells you the exact `brew install helm` line.
