\
#!/usr/bin/env bash
set -euo pipefail

say(){ printf "\n==> %s\n" "$*"; }
warn(){ printf "\nWARN: %s\n" "$*" >&2; }
die(){ printf "\nERROR: %s\n" "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "Missing: $1"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

need kubectl
need docker
# helm is required for the “prod-done” monitoring stack
if ! command -v helm >/dev/null 2>&1; then
  echo "ERROR: helm is missing."
  echo "Install (Mac): brew install helm"
  exit 1
fi

CLUSTER="${CLUSTER:-pni}"
PNS="${PNS:-pni}"
MNS="${MNS:-monitoring}"

say "0) Confirm cluster reachable"
kubectl version --client >/dev/null
kubectl get ns >/dev/null

say "1) Ensure namespaces exist"
kubectl get ns "$PNS" >/dev/null 2>&1 || kubectl create ns "$PNS" >/dev/null
kubectl get ns "$MNS" >/dev/null 2>&1 || kubectl create ns "$MNS" >/dev/null

say "2) Confirm PNI is running (best-effort)"
kubectl -n "$PNS" get deploy >/dev/null 2>&1 || warn "PNI namespace has no deployments yet (ok if you haven't run KIND_ONE_GO)"
kubectl -n "$PNS" get pods -o wide || true

say "3) Add helm repos (idempotent)"
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts >/dev/null 2>&1 || true
helm repo add grafana https://grafana.github.io/helm-charts >/dev/null 2>&1 || true
helm repo update >/dev/null

say "4) Install kube-prometheus-stack (Prometheus + Grafana)"
helm upgrade --install pni-kps prometheus-community/kube-prometheus-stack \
  -n "$MNS" \
  --set grafana.enabled=true \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false \
  --wait

say "5) Install Loki + Promtail (logs)"
helm upgrade --install pni-loki grafana/loki-stack \
  -n "$MNS" \
  --set promtail.enabled=true \
  --set grafana.enabled=false \
  --wait

say "6) Quick health checks"
kubectl -n "$MNS" get pods -o wide
kubectl -n "$MNS" rollout status deploy/pni-kps-grafana --timeout=240s || true
kubectl -n "$MNS" get svc | sed -n '1,120p'

say "7) Port-forward Grafana (optional)"
# This runs in background; you can stop with: kill $(cat logs/pf_grafana.pid)
mkdir -p logs
GRAF_SVC="$(kubectl -n "$MNS" get svc -o name | grep -E 'pni-kps-grafana$' | head -n 1 | cut -d/ -f2 || true)"
if [ -n "${GRAF_SVC:-}" ]; then
  (kubectl -n "$MNS" port-forward "svc/${GRAF_SVC}" 3000:80 >/dev/null 2>&1 & echo $! > logs/pf_grafana.pid)
  echo "Grafana: http://localhost:3000"
  echo "Get admin password:"
  echo "  kubectl -n $MNS get secret pni-kps-grafana -o jsonpath='{.data.admin-password}' | base64 -d; echo"
else
  warn "Grafana service not found (chart naming differs). Run: kubectl -n $MNS get svc"
fi

say "DONE (prod)"
echo "Next optional hardening:"
echo "  - enable ServiceMonitors for your services"
echo "  - add Alertmanager routes"
echo "  - turn on cosign signing + enforce with admission policies"
