# Final next steps after this bundle

If you want “done” in the real-world sense, here’s the remaining checklist:

1) **Edge deployment**:
   - Decide target OS: Ubuntu/Debian
   - Use your portable docker zip or k8s manifests on the edge box
   - Set systemd/launchd for auto-start

2) **Observability wiring**:
   - Add ServiceMonitors / scrape configs for policy-svc/hub-ingest/edge-agent
   - Add key dashboards and alerts

3) **Security**:
   - CI: SBOM + vulnerability scan
   - Optional: image signing (cosign)
   - Optional: admission policy: only allow signed images

This bundle implements (2) base stack + (3) CI scaffolding.
