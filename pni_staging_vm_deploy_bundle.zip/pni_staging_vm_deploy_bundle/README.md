# PNI Staging VM Deploy Bundle

This is the next step after PROD_RELEASE: deploy the stack to a staging VM with one script.

## Install
```bash
cd ~/Downloads/pni
rm -rf ~/Downloads/pni_staging_vm_deploy_bundle
unzip -o ~/Downloads/pni_staging_vm_deploy_bundle.zip -d ~/Downloads
bash ~/Downloads/pni_staging_vm_deploy_bundle/tools/INSTALL_INTO_REPO.sh
```

## One-go deploy (from your Mac)
```bash
cd ~/Downloads/pni
STAGING_HOST=YOUR_VM_IP_OR_DNS STAGING_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 REMOTE_DIR=/home/ubuntu/pni ISSUER_PUBKEY_B64='mMnyXVv3w1sodDq7xskHzoOHZ3KCSUqxb1NewwdFkKQ=' bash tools/STAGING_DEPLOY_ONE_GO.sh
```

## Check
```bash
STAGING_HOST=... STAGING_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 bash tools/STAGING_STATUS.sh
STAGING_HOST=... STAGING_USER=ubuntu SSH_KEY=~/.ssh/id_ed25519 bash tools/STAGING_TAIL_LOGS.sh
```
