\
#!/usr/bin/env bash
set -euo pipefail
source tools/_svm_common.sh
: "${STAGING_HOST:?Set STAGING_HOST}"
STAGING_USER="${STAGING_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new"
need ssh
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'"
