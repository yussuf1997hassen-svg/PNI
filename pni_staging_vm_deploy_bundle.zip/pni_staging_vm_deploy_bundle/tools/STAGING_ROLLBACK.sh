\
#!/usr/bin/env bash
set -euo pipefail
source tools/_svm_common.sh
: "${STAGING_HOST:?Set STAGING_HOST}"
STAGING_USER="${STAGING_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
REMOTE_DIR="${REMOTE_DIR:-/home/${STAGING_USER}/pni}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new"
need ssh
say "Rollback: docker compose down"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "cd '${REMOTE_DIR}' && docker compose down --remove-orphans || true"
say "OK"
