\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_svm_common.sh

# REQUIRED:
: "${STAGING_HOST:?Set STAGING_HOST (IP or DNS)}"
STAGING_USER="${STAGING_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
REMOTE_DIR="${REMOTE_DIR:-/home/${STAGING_USER}/pni}"
ISSUER_PUBKEY_B64="${ISSUER_PUBKEY_B64:-mMnyXVv3w1sodDq7xskHzoOHZ3KCSUqxb1NewwdFkKQ=}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=15 -o ServerAliveCountMax=3"

say "0) Preconditions (Mac -> VM)"
need ssh
need rsync
[ -f "$SSH_KEY" ] || die "SSH key not found: $SSH_KEY"
echo "Target: ${STAGING_USER}@${STAGING_HOST}"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "echo OK: connected; uname -a" >/dev/null

say "1) Ensure Docker is installed on the VM (best-effort)"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "command -v docker >/dev/null 2>&1 && echo OK: docker already installed || (curl -fsSL https://get.docker.com | sh && sudo usermod -aG docker ${STAGING_USER} && echo OK: docker installed)"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "docker --version && docker compose version" || warn "If compose missing, re-login and retry. Some distros need: sudo apt-get install -y docker-compose-plugin"

say "2) Create remote dir"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "mkdir -p '${REMOTE_DIR}' '${REMOTE_DIR}/dist' '${REMOTE_DIR}/logs' '${REMOTE_DIR}/secrets' && chmod 700 '${REMOTE_DIR}/secrets' || true"

say "3) Upload repo to VM (EXCLUDES secrets + .env files)"
# Exclude secrets/private material
rsync -az --delete \
  --exclude '.git/' \
  --exclude 'node_modules/' \
  --exclude 'secrets/' \
  --exclude '.env*' \
  --exclude 'dist/' \
  --exclude 'logs/' \
  ./ "${STAGING_USER}@${STAGING_HOST}:${REMOTE_DIR}/"

say "4) Write truDat issuer pubkey (public only) on VM"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "printf '%s\n' '${ISSUER_PUBKEY_B64}' > '${REMOTE_DIR}/secrets/trudat_issuer_pubkey.b64' && chmod 600 '${REMOTE_DIR}/secrets/trudat_issuer_pubkey.b64' || true"

say "5) Best-effort patch registry.json on VM so truDat is allowed"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "python3 - <<'PY' '${REMOTE_DIR}' '${ISSUER_PUBKEY_B64}'
import json,sys,os
root=sys.argv[1]; pub=sys.argv[2]
cands=[
  os.path.join(root,'registry.json'),
  os.path.join(root,'cmd','policy-svc','registry.json'),
  os.path.join(root,'config','registry.json'),
  os.path.join(root,'config','registry.local.json')
]
reg=None
for f in cands:
  if os.path.exists(f):
    reg=f; break
if not reg:
  print('WARN: registry.json not found; skipping'); raise SystemExit(0)
d=json.load(open(reg))
changed=False
ap=d.get('allowed_publishers')
if isinstance(ap,dict):
  cur=ap.get('truDat')
  if cur is None:
    ap['truDat']=[pub]; changed=True
  elif isinstance(cur,list) and pub not in cur:
    cur.append(pub); changed=True
issuers=d.get('issuers')
if isinstance(issuers,dict):
  it=issuers.get('truDat')
  if it is None:
    issuers['truDat']={'pubkeys_b64':[pub]}; changed=True
  elif isinstance(it,dict):
    lst=it.get('pubkeys_b64')
    if lst is None:
      it['pubkeys_b64']=[pub]; changed=True
    elif isinstance(lst,list) and pub not in lst:
      lst.append(pub); changed=True
if (ap is None) and (issuers is None) and ('publishers' not in d):
  d['allowed_publishers']={'truDat':[pub]}; changed=True
if changed:
  json.dump(d,open(reg,'w'),indent=2,sort_keys=True)
  print('OK: registry patched:', reg)
else:
  print('OK: registry already ok:', reg)
PY" || true

say "6) Bring up stack on VM (docker compose)"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "cd '${REMOTE_DIR}' && (docker compose down --remove-orphans || true) && docker compose up -d --build"

say "7) Checks (containers + ports)"
ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' | (head -n 1; grep -Ei 'mosquit|hub|ingest|edge|policy' || true)"

say "DONE ✅"
echo "Next: run status + tail logs:"
echo "  STAGING_HOST=${STAGING_HOST} STAGING_USER=${STAGING_USER} SSH_KEY=${SSH_KEY} bash tools/STAGING_STATUS.sh"
echo "  STAGING_HOST=${STAGING_HOST} STAGING_USER=${STAGING_USER} SSH_KEY=${SSH_KEY} bash tools/STAGING_TAIL_LOGS.sh"
echo ""
echo "Important: Keep issuer PRIVATE key off the VM. Publish commands from your Mac as truDat."
