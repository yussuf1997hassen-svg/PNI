\
#!/usr/bin/env bash
set -euo pipefail
source tools/_svm_common.sh
: "${STAGING_HOST:?Set STAGING_HOST}"
STAGING_USER="${STAGING_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new"
need ssh

for c in pni-edge-agent edge-agent pni-hub-ingest hub-ingest pni-policy policy-svc pni-mosquitto mosquitto; do
  if ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "docker ps --format '{{.Names}}' | grep -qx '$c'"; then
    echo "---- $c ----"
    ssh $SSH_OPTS "${STAGING_USER}@${STAGING_HOST}" "docker logs --tail=200 '$c' | grep -Ei 'telemetry|accepted|ok|apply|applied|command|policy|issuer|truDat' || docker logs --tail=80 '$c'"
    echo
  fi
done
