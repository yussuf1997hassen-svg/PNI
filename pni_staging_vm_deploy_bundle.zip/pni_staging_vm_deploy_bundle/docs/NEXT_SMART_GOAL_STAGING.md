# Next SMART goal: Staging deployment (real-world completion)

You are finished **for real** when the stack runs on a machine that is **not your laptop**, with repeatable ops.

## SMART goal
- **Specific:** Deploy PNI (mosquitto + policy-svc + hub-ingest + edge-agent) to a staging VM.
- **Measurable:** `docker ps` shows all services healthy; log lines show telemetry + applied commands.
- **Achievable:** One script from your Mac.
- **Relevant:** This is the “go-live rehearsal” for production.
- **Time-bound:** One run.

## Security rule
- DO NOT place truDat issuer private key on the VM.
- VM only needs the **public** key for verification/ACL.
- Publishing commands stays on your Mac.
