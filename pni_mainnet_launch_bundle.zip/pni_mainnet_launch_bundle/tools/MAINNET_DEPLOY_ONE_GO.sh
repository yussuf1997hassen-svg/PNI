\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_ml_common.sh

need docker
need python3

: "${ARBITRUM_ONE_RPC_URL:?Set ARBITRUM_ONE_RPC_URL}"
: "${BASE_MAINNET_RPC_URL:?Set BASE_MAINNET_RPC_URL}"
: "${DEPLOYER_PRIVATE_KEY:?Set DEPLOYER_PRIVATE_KEY (0x...)}"
: "${WALLET1:?Set WALLET1 (0x...)}"
: "${WALLET2:?Set WALLET2 (0x...)}"
MINT_TOKENS="${MINT_TOKENS:-1000000}"
RENOUNCE_OWNER="${RENOUNCE_OWNER:-false}"

say "0) Safety checks"
python3 - <<'PY'
import os,re,sys
w1=os.environ["WALLET1"]; w2=os.environ["WALLET2"]
if not re.fullmatch(r"0x[0-9a-fA-F]{40}", w1): raise SystemExit("ERROR: WALLET1 invalid")
if not re.fullmatch(r"0x[0-9a-fA-F]{40}", w2): raise SystemExit("ERROR: WALLET2 invalid")
if w1.lower()==w2.lower(): raise SystemExit("ERROR: WALLET1 and WALLET2 must be different")
print("OK: wallet formats look valid")
PY
echo "RENOUNCE_OWNER=$RENOUNCE_OWNER"
echo "MINT_TOKENS=$MINT_TOKENS"

say "1) Install deps in Docker (Node 20)"
docker run --rm -v "$ROOT/token-mainnet:/app" -w /app node:20-bullseye bash -lc 'npm -s install >/dev/null'

say "2) Compile"
docker run --rm -v "$ROOT/token-mainnet:/app" -w /app node:20-bullseye bash -lc 'npx hardhat compile >/dev/null'

say "3) Deploy + mint on Arbitrum One (chainId 42161)"
docker run --rm \
  -e ARBITRUM_ONE_RPC_URL="$ARBITRUM_ONE_RPC_URL" \
  -e BASE_MAINNET_RPC_URL="$BASE_MAINNET_RPC_URL" \
  -e DEPLOYER_PRIVATE_KEY="$DEPLOYER_PRIVATE_KEY" \
  -e WALLET1="$WALLET1" -e WALLET2="$WALLET2" -e MINT_TOKENS="$MINT_TOKENS" -e RENOUNCE_OWNER="$RENOUNCE_OWNER" \
  -v "$ROOT/token-mainnet:/app" -v "$ROOT/dist:/app/../dist" \
  -w /app node:20-bullseye bash -lc 'npx hardhat run scripts/deploy_mint_optional_renounce.js --network arbitrumOne'

say "4) Deploy + mint on Base (chainId 8453)"
docker run --rm \
  -e ARBITRUM_ONE_RPC_URL="$ARBITRUM_ONE_RPC_URL" \
  -e BASE_MAINNET_RPC_URL="$BASE_MAINNET_RPC_URL" \
  -e DEPLOYER_PRIVATE_KEY="$DEPLOYER_PRIVATE_KEY" \
  -e WALLET1="$WALLET1" -e WALLET2="$WALLET2" -e MINT_TOKENS="$MINT_TOKENS" -e RENOUNCE_OWNER="$RENOUNCE_OWNER" \
  -v "$ROOT/token-mainnet:/app" -v "$ROOT/dist:/app/../dist" \
  -w /app node:20-bullseye bash -lc 'npx hardhat run scripts/deploy_mint_optional_renounce.js --network base'

say "5) Validate receipts show equal balances + expected supply"
python3 - <<'PY'
import json,glob,sys
files=sorted(glob.glob("dist/mainnet_receipt_*.json"))
if not files: raise SystemExit("ERROR: no dist/mainnet_receipt_*.json found")
ok=True
for f in files:
  d=json.load(open(f))
  b1=int(d["balance1Wei"]); b2=int(d["balance2Wei"]); ts=int(d["totalSupplyWei"]); a=int(d["amountEachWei"])
  if b1!=b2 or b1!=a or ts!=(2*a):
    ok=False
    print("FAIL", f, "b1", b1, "b2", b2, "a", a, "ts", ts)
  else:
    print("OK ", f, "contract", d["contract"], "renounced", d.get("renounced"))
if not ok: sys.exit(1)
PY

say "DONE ✅"
echo "Receipts written:"
ls -1 dist/mainnet_receipt_*.json
