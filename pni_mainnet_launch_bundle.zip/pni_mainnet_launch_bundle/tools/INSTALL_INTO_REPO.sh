\
#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="${REPO_DIR:-$HOME/Downloads/pni}"
[ -d "$REPO_DIR" ] || { echo "ERROR: repo not found at $REPO_DIR"; exit 1; }

mkdir -p "$REPO_DIR/tools" "$REPO_DIR/docs" "$REPO_DIR/token-mainnet" "$REPO_DIR/dist"
cp -R "$SRC_DIR/tools/"* "$REPO_DIR/tools/"
cp -R "$SRC_DIR/docs/"* "$REPO_DIR/docs/"
cp -R "$SRC_DIR/token-mainnet/"* "$REPO_DIR/token-mainnet/"
chmod +x "$REPO_DIR/tools/"*.sh 2>/dev/null || true

echo "Installed MAINNET LAUNCH bundle into: $REPO_DIR"
echo "NEXT (no private keys pasted into chat):"
echo "  cd ~/Downloads/pni"
echo "  cp -n token-mainnet/.env.example .env.mainnet"
echo "  # edit .env.mainnet with RPC URLs + DEPLOYER_PRIVATE_KEY + WALLET1/WALLET2"
echo "  set -a; source .env.mainnet; set +a"
echo "  bash tools/MAINNET_DEPLOY_ONE_GO.sh"
