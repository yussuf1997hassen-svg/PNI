# MAINNET LAUNCH bundle (next SMART goal)

This is the “final completion” step for token distribution:
- Deploy TruDAT (TDAT) to Arbitrum One + Base mainnets
- Mint equal amounts to WALLET1 and WALLET2
- (Optional) Renounce ownership to freeze minting forever
- Writes receipts in dist/

## IMPORTANT
- You must have gas funds on each chain (ETH on Arbitrum + ETH on Base).
- Never paste private keys into chat. Use local env file only.
- Code cannot guarantee market price/value. It can guarantee rules, governance, and provable distribution.
