# Mainnet readiness checklist (SMART)

## Specific & measurable
1) ✅ Staging/prod PNI stack running outside laptop (done)
2) ✅ Ops hardening (watchdog + backups + firewall) (done)
3) ✅ Testnet token receipts equal balances (done)
4) ⏭ MAINNET token deploy + equal mint receipts (this bundle)
   Output: dist/mainnet_receipt_arbitrumOne.json, dist/mainnet_receipt_base.json
5) ⏭ Public documentation + transparency
   - publish receipts (without secrets)
   - publish contract addresses + token metadata
6) ⏭ Optional: audit + multisig ownership (recommended)
   - replace single EOA owner with Safe multisig, then mint, then renounce (or keep controlled)
