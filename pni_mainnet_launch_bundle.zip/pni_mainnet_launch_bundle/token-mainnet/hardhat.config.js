require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

const PK = process.env.DEPLOYER_PRIVATE_KEY || "";

// Chain IDs: Arbitrum One = 42161, Base = 8453
module.exports = {
  solidity: "0.8.24",
  networks: {
    arbitrumOne: {
      url: process.env.ARBITRUM_ONE_RPC_URL || "",
      accounts: PK ? [PK] : [],
      chainId: 42161
    },
    base: {
      url: process.env.BASE_MAINNET_RPC_URL || "",
      accounts: PK ? [PK] : [],
      chainId: 8453
    }
  }
};
