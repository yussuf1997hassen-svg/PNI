# Ops runbook

## What this adds
1) Watchdog cron (every 2 minutes):
   - checks critical containers are running
   - checks hub-ingest logs contain recent telemetry OK / applied signals
   - if failed: `docker compose restart` and writes to dist/ops_watchdog.log

2) Backup cron (daily at 02:17):
   - archives compose files + registry + config + dist receipts (no secrets)
   - best-effort volume backup to dist/backups/

3) Firewall baseline (UFW, best-effort):
   - allows: 22/tcp, 80/tcp, 443/tcp, 8883/tcp
   - denies: everything else

## Completion definition
You are “operationally complete” when:
- watchdog keeps writing OK lines continuously
- backups exist for 3 consecutive days
- firewall is enabled and only required ports are open
- you can reboot the VM and the stack comes back up automatically (docker restart unless-stopped)

## Alerting (optional)
- Replace the placeholder in ops/watchdog.sh to send a Slack webhook / email.
- Do NOT hardcode tokens in repo; use server-side env or secret manager.
