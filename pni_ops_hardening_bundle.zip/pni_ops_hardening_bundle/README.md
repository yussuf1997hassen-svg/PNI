# PNI Ops Hardening Bundle (next SMART goal)

This is the post-go-live “finish it for real” package:
- Watchdog (log-based checks + self-heal + alert file)
- Backups (daily tarball of configs + docker volumes)
- Firewall baseline (SSH + HTTPS + MQTT-TLS)

It does NOT touch your issuer PRIVATE key.
