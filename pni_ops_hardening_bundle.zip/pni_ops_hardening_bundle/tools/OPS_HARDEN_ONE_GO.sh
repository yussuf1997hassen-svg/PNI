\
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
source tools/_ops_common.sh

: "${PROD_HOST:?Set PROD_HOST (IP/DNS)}"
PROD_USER="${PROD_USER:-ubuntu}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
REMOTE_DIR="${REMOTE_DIR:-/home/${PROD_USER}/pni}"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=15 -o ServerAliveCountMax=3"

say "0) Preflight"
need ssh
need rsync
[ -f "$SSH_KEY" ] || die "SSH key not found: $SSH_KEY"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "echo OK: connected; uname -a" >/dev/null

say "1) Upload ops scripts to server"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "mkdir -p '${REMOTE_DIR}/ops' '${REMOTE_DIR}/dist' '${REMOTE_DIR}/logs'"
rsync -az --delete ./ops/ "${PROD_USER}@${PROD_HOST}:${REMOTE_DIR}/ops/"

say "2) Install watchdog (self-heal + alert log)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "bash -lc 'cd ${REMOTE_DIR} && sudo bash ops/install_watchdog.sh || bash ops/install_watchdog.sh'"

say "3) Install backups (daily tarball of configs + docker volumes)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "bash -lc 'cd ${REMOTE_DIR} && sudo bash ops/install_backups.sh || bash ops/install_backups.sh'"

say "4) Tighten firewall (best-effort; SSH + HTTPS + MQTT-TLS)"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "bash -lc 'cd ${REMOTE_DIR} && sudo bash ops/install_firewall.sh || echo WARN: firewall step skipped (no sudo)'"

say "5) Verify cron jobs installed"
ssh $SSH_OPTS "${PROD_USER}@${PROD_HOST}" "crontab -l 2>/dev/null | grep -E 'pni_watchdog|pni_backup' || true"

say "DONE ✅"
echo "Next checks:"
echo "  ssh -i ${SSH_KEY} ${PROD_USER}@${PROD_HOST} 'tail -n 50 ${REMOTE_DIR}/dist/ops_watchdog.log || true'"
echo "  ssh -i ${SSH_KEY} ${PROD_USER}@${PROD_HOST} 'ls -lt ${REMOTE_DIR}/dist/backups | head'"
