\
#!/usr/bin/env bash
set -euo pipefail
REMOTE_DIR="${REMOTE_DIR:-$PWD}"
LOG="${REMOTE_DIR}/dist/ops_watchdog.log"
NOW="$(date +%Y-%m-%dT%H:%M:%S%z)"

cd "${REMOTE_DIR}"

need_container() {
  local name="$1"
  docker ps --format '{{.Names}}' | grep -qx "$name"
}

# Names we commonly see
CANDIDATES=(pni-mosquitto mosquitto pni-policy policy-svc pni-hub-ingest hub-ingest pni-edge-agent edge-agent)

missing=()
for n in "${CANDIDATES[@]}"; do
  # only require those that exist in compose; if none exist, it's still a failure.
  if docker ps -a --format '{{.Names}}' | grep -qx "$n"; then
    if ! need_container "$n"; then
      missing+=("$n")
    fi
  fi
done

# If any required container is missing -> fail
if [ "${#missing[@]}" -gt 0 ]; then
  echo "$NOW FAIL missing_containers=${missing[*]}" | tee -a "$LOG"
  echo "$NOW ACTION restarting compose" | tee -a "$LOG"
  docker compose restart || true
  exit 0
fi

# Log freshness check (hub-ingest telemetry)
# If we find any of these within last 200 lines, consider OK.
ok=0
for n in pni-hub-ingest hub-ingest; do
  if docker ps --format '{{.Names}}' | grep -qx "$n"; then
    if docker logs --tail=200 "$n" 2>/dev/null | grep -Eiq 'telemetry.*OK|telemetry OK|applied|apply ok|accepted'; then
      ok=1
    fi
  fi
done

if [ "$ok" -eq 1 ]; then
  echo "$NOW OK telemetry_seen=1" >> "$LOG"
  exit 0
fi

echo "$NOW WARN telemetry_not_seen restarting_compose=1" | tee -a "$LOG"
docker compose restart || true

# OPTIONAL: send alert here (Slack/email). Keep secrets off repo.
exit 0
