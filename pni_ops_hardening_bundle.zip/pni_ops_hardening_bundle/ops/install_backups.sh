\
#!/usr/bin/env bash
set -euo pipefail
REMOTE_DIR="${REMOTE_DIR:-$PWD}"
mkdir -p "${REMOTE_DIR}/dist/backups"
chmod +x "${REMOTE_DIR}/ops/backup.sh"

CRON="17 2 * * * cd ${REMOTE_DIR} && REMOTE_DIR=${REMOTE_DIR} bash ops/backup.sh >> /dev/null 2>&1 # pni_backup"
( crontab -l 2>/dev/null | grep -v "pni_backup" || true; echo "$CRON" ) | crontab -
echo "OK: backup cron installed"
