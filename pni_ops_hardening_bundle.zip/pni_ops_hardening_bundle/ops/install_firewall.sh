\
#!/usr/bin/env bash
set -euo pipefail
# UFW baseline (Ubuntu/Debian). Best-effort.
if ! command -v ufw >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update -y
    sudo apt-get install -y ufw
  else
    echo "WARN: ufw not available; skipping"
    exit 0
  fi
fi

sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 8883/tcp
sudo ufw --force enable
sudo ufw status verbose
echo "OK: firewall applied"
