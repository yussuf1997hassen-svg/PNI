\
#!/usr/bin/env bash
set -euo pipefail
REMOTE_DIR="${REMOTE_DIR:-$PWD}"
TS="$(date +%Y%m%d_%H%M%S)"
OUTDIR="${REMOTE_DIR}/dist/backups"
mkdir -p "$OUTDIR"

# Backup configs (exclude secrets)
tar -czf "${OUTDIR}/pni_cfg_${TS}.tgz" \
  --exclude='secrets' \
  --exclude='.env*' \
  docker-compose*.yml config docs cmd dist registry.json 2>/dev/null || true

# Best-effort volume backup (may be large)
# If you know exact volume names, replace with explicit list.
docker volume ls --format '{{.Name}}' | grep -E 'pni|mosquit|caddy' | while read -r v; do
  docker run --rm \
    -v "${v}:/v:ro" \
    -v "${OUTDIR}:/out" \
    alpine:3.20 sh -lc "tar -czf /out/vol_${v}_${TS}.tgz -C /v . || true" || true
done

# Keep last 14 days (optional)
find "$OUTDIR" -type f -mtime +14 -name '*.tgz' -delete 2>/dev/null || true

echo "$(date +%Y-%m-%dT%H:%M:%S%z) OK backup_written=${OUTDIR}" >> "${REMOTE_DIR}/dist/ops_watchdog.log"
