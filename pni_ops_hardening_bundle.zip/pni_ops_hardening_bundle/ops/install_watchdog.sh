\
#!/usr/bin/env bash
set -euo pipefail
REMOTE_DIR="${REMOTE_DIR:-$PWD}"
mkdir -p "${REMOTE_DIR}/dist"
chmod +x "${REMOTE_DIR}/ops/watchdog.sh"

# Install cron (every 2 minutes)
CRON="*/2 * * * * cd ${REMOTE_DIR} && REMOTE_DIR=${REMOTE_DIR} docker ps >/dev/null 2>&1 && bash ops/watchdog.sh >> /dev/null 2>&1 # pni_watchdog"
( crontab -l 2>/dev/null | grep -v "pni_watchdog" || true; echo "$CRON" ) | crontab -
echo "OK: watchdog cron installed"
